import React, { useState, useEffect } from "react";
import "./App.css";
import { Route, Routes, Navigate, useLocation } from "react-router-dom";
import { ToastContainer } from "react-toastify";
import jwtDecode from "jwt-decode";
import interceptor from "./services/Interceptors/interceptor";
import Breadcrumb from "./components/common/breadcrumb";
import TopBar from "./components/common/topBar";
import Sidebar from "./components/common/Sidebar";
import { getRoutes } from "./components/common/routes";
import LoginForm from "./components/loginForm";
import PreviewForm from "./components/previewForm";
import NewsPreview from "./components/NewsFormPreview";
import HeadToHeadPreview from "./components/headtoheadPreview";

interceptor.setupInterceptors();
function App() {
  const [breadCrumbs, setBreadCrumbs] = useState([]);

  const isLoggedIn = localStorage.getItem("token");
  let decodedToken = null;

  if (isLoggedIn) {
    decodedToken = jwtDecode(isLoggedIn);
  }
  const dateNow = new Date();

  const user = {
    id: isLoggedIn ? decodedToken?._id : null,
    name: isLoggedIn ? decodedToken?.name : null,
    userRole: isLoggedIn ? decodedToken?.userRole : null,
    iat: isLoggedIn ? decodedToken?.iat : null,
    exp: isLoggedIn ? decodedToken?.exp : null,
  };
  // abc
  if (decodedToken?.exp * 1000 < dateNow.getTime()) {
    localStorage.removeItem("token");
  }

  const location = useLocation();

  useEffect(() => {
    const arr = window?.location?.pathname?.split("/")?.slice(1) || [];
    if (arr.includes("head-to-head")) {
      //directly mutate array

      const temp = [];
      temp[0] = "league";
      temp[1] = `league/${arr[1]}/head-to-head`;
      // if(arr.length > 2){
      // temp[2] = `league/${arr[1]}/head-to-head`;
      // }
      setBreadCrumbs(temp);
    } else {
      setBreadCrumbs(arr);
    }
  }, [location]);

  if (window.location.pathname.includes("news-preview")) {
    return (
      <>
        <Routes>
          <Route path="news-preview" element={<NewsPreview />} />
        </Routes>
      </>
    );
  }
  if (window.location.pathname.includes("head-to-head-preview")) {
    return (
      <>
        <Routes>
          <Route path="head-to-head-preview" element={<HeadToHeadPreview />} />
        </Routes>
      </>
    );
  }
  return (
    <main className="d-flex">
      {user.name && <Sidebar user={user} />}
      <section className="w-100">
        {user?.name && (
          <div className="px-5 py-3 mb-2 top-bar">
            <TopBar user={user} />
          </div>
        )}
        <div className="px-5">
          {user?.name && <Breadcrumb breadCrumbs={breadCrumbs} />}

          <Routes>
            {!!isLoggedIn ? (
              <>
                {getRoutes(user)?.map((route, i) => (
                  <Route key={i++} path={route?.path} element={route.element} />
                ))}
              </>
            ) : (
              <Route path="/login" element={<LoginForm />} />
            )}
            <Route
              path="*"
              element={<Navigate to={user?.name ? "/not-found" : "/login"} />}
            />
          </Routes>

          <ToastContainer
            position="top-right"
            autoClose={2000}
            hideProgressBar
            newestOnTop={false}
            closeOnClick
            rtl={false}
            pauseOnFocusLoss
            draggable
            pauseOnHover
          />
        </div>
      </section>
    </main>
  );
}

export default App;
