import React from "react";

const AdBanner = () => {
  return (
    <div
      className="my-4 container-fluid border border-info p-2 rounded"
      style={{ cursor: "all-scroll" }}
    >
      <img src="/adBanner.png" width="100%" alt="" />
    </div>
  );
};

export default AdBanner;
