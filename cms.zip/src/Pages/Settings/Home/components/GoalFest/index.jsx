import React from "react";

export default function GoalFest({
  heading,
  description,
  goalbanner,
  goalhero,
  getgoalHeading,
  getgoalDescripation,
}) {
  return (
    <div
      className="my-3 border border-secondary p-2 rounded "
      style={{ cursor: "all-scroll" }}>
      <h5 className="ml-2">Team USA </h5>
      <div className="bg-black">
        <div className="d-flex align-items-center justify-content-between ">
          <div></div>
          {/* <div className="d-flex m-1">
            <div className="">
              <input
                onChange={goalbanner}
                type="file"
                id="banner3"
                accept="image/png, image/gif, image/jpeg"
                className="d-none"
              />
              <label
                htmlFor="banner3"
                className="border px-2 rounded clickable d-block">
                <i className="fa fa-plus white-color"></i>
              </label>
            </div>
          </div> */}
        </div>
        <div className="row">
          <div className="col-md-6">
            <div className="container">
              <div className="form-group mt-10">
                <input
                  className="form-control form-control-lg"
                  type="text"
                  placeholder="Enter Banner Heading Here...."
                  id="header"
                  defaultValue={heading}
                  onChange={getgoalHeading}
                />
              </div>
              <div className="form-group mt-1">
                <input
                  className="form-control form-control"
                  type="text"
                  placeholder="Enter Banner discription"
                  id="header"
                  defaultValue={description}
                  onChange={getgoalDescripation}
                />
              </div>
            </div>
          </div>
          <div className="col-md-6" style={{ position: "relative" }}>
            <div
              className="d-flex m-1"
              style={{ position: "absolute", top: 0, right: 15 }}>
              <div className="">
                <input
                  onChange={goalbanner}
                  type="file"
                  id="banner3"
                  accept="image/png, image/gif, image/jpeg"
                  className="d-none"
                />
                <label
                  htmlFor="banner3"
                  className="border px-2 rounded clickable d-block">
                  <i className="fa fa-plus white-color"></i>
                </label>
              </div>
            </div>
            <div>
              <img src={goalhero} width="100%" height="350px" alt="goalfest" />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// import React from "react";

// const index = () => {
//   return (
//     <div
//       className="my-4 container-fluid border border-info p-2 rounded"
//       style={{ cursor: "all-scroll" }}
//     >
//       <img src="/goalFest.png" width="100%" alt="" />
//     </div>
//   );
// };

// export default index;
