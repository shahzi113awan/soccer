import React from "react";

const index = () => {
  return (
    <div
      className="my-4 container-fluid border border-info p-2 rounded"
      style={{ cursor: "all-scroll" }}
    >
      <img src="/module3.png" width="100%" alt="" />
    </div>
  );
};

export default index;
