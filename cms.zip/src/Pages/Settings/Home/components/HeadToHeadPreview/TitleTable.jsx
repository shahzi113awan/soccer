import React from "react";

const TitleTable = ({ title, width, fontSize, fontWeight }) => {
  const styleBox = { width: width, fontSize: fontSize, fontWeight: fontWeight };
  return title?.length ? (
    <div className="py-1">
      <div className="d-flex text-white">
        {title
          ?.split(" ")?.[0]
          ?.toUpperCase()
          ?.split("")
          ?.map((r1, i) => (
            <Tile styleBox={styleBox} r={r1} key={`__firstTileRow${i}`} />
          ))}
      </div>
      <div className="d-flex text-white">
        <div className={`tile-columns middle-row-h2h`} style={styleBox}></div>
        <div
          className={`tile-columns text-center font-weight-bold middle-row-h2h `}
          style={styleBox}>
          {title?.split(" ")?.[1]?.toUpperCase()}
        </div>
        <div className={`tile-columns middle-row-h2h`} style={styleBox}></div>
      </div>
      <div className="d-flex text-white">
        {title
          ?.split(" ")?.[2]
          ?.toUpperCase()
          ?.split("")
          ?.map((r2, i) => (
            <Tile styleBox={styleBox} r={r2} key={`__thirdTileRow${i}`} />
          ))}
      </div>
    </div>
  ) : (
    <></>
  );
};

export default TitleTable;

export function Tile({ r, styleBox }) {
  const tileStyle = {
    width: styleBox.width,
    fontSize: styleBox.fontSize,
    fontWeight: styleBox.fontWeight,
  };
  return (
    <div
      className={`tile-columns text-center font-weight-bold array-border-h2h`}
      style={tileStyle}>
      {r}
    </div>
  );
}
