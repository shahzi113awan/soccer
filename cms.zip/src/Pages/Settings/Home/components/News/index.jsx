import React, { useEffect, useState } from "react";
import { ReactSortable } from "react-sortablejs";
import { calls } from "../../../../../services/promiseHandler/promiseHandler";

const News = () => {
  const [news, setNews] = useState([]);
  useEffect(() => {
    (async () => {
      const news = await calls("news", "get");
      setNews(news.data);
    })();
  }, []);

  return (
    <div
      className="container-fluid my-2 border border-info p-2 rounded"
      style={{ cursor: "all-scroll" }}>
      <h5 className="ml-2"> News </h5>
      <div className="row">
        <div className="col-md-6">
          <img
            width="100%"
            style={{ maxHeight: "350px", objectFit: "cover" }}
            src={news?.[0]?.featuredImage}
            alt=""
          />
          <h5
            className="mt-3 text-uppercase"
            style={{ fontSize: "32px", fontWeight: "900" }}>
            {news?.[0]?.title}
          </h5>
          <p className="mt-3">{news?.[0]?.excerpt}</p>
          <p
            className="mt-3 text-muted"
            style={{
              fontSize: "12px",
            }}>
            {news?.[0]?.author?.name}
          </p>
        </div>
        <div className="col-md-6">
          <div className="row">
            <div className="col-md-6">
              <div>
                <ReactSortable
                  dragClass="dragingItem"
                  animation={500}
                  list={news}
                  setList={setNews}
                  scroll={true}>
                  {news?.slice(0, 4)?.map((item) => (
                    <div
                      key={item?._id}
                      className={`d-flex ${item !== 0 && "my-2"}`}>
                      <img
                        style={{ objectFit: "cover" }}
                        width={100}
                        height={100}
                        src={item?.featuredImage}
                        alt=""
                      />
                      <h5
                        className="text-capitalize ml-2 "
                        style={{
                          fontSize: "15px",
                          fontWeight: "bold",
                          textAlign: "left",
                        }}>
                        {item?.title}
                      </h5>
                    </div>
                  ))}
                </ReactSortable>
              </div>
            </div>
            <div className="col-md-6">
              <h5
                className=""
                style={{
                  fontSize: "15px",
                  fontWeight: "bold",
                  textAlign: "left",
                }}>
                HEADLINES
              </h5>
              <ReactSortable
                dragClass="dragingItem"
                animation={500}
                list={news}
                setList={setNews}
                scroll={true}>
                {news?.slice(0, 4)?.map((item) => (
                  <div
                    key={item?._id}
                    className="my-1"
                    style={{ overflow: "hidden" }}>
                    <p>{item?.excerpt}</p>
                  </div>
                ))}
              </ReactSortable>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default News;
