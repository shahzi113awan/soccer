import React from "react";

const HeroBanner = ({
  handleAddBanner,
  // handleDeleteBanner,
  getData,
  Text,
  
  heroBannerImage,
}) => {
  return (
    <div className="my-3 border border-secondary p-2 rounded">
      <div className="d-flex align-items-center justify-content-between ">
        <div></div>
        <div className="d-flex my-1">
          <div>
            <input
              onChange={handleAddBanner}
              type="file"
              id="banner1"
              accept="image/png, image/gif, image/jpeg"
              className="d-none"
            />
            <label
              htmlFor="banner1"
              className="border px-2 rounded clickable d-block">
              <i className="fa fa-plus"></i>
            </label>
          </div>
        </div>
      </div>

      <div>
        <img src={heroBannerImage} alt="" width="100%" height="auto" />
      </div>

      <div className="form-group mt-1">
        <input
          minlength="5"
          maxlength="15"
          className="form-control form-control-lg"
          type="text"
          placeholder="Enter Banner Heading Here...."
          id="header"
          defaultValue={Text}
          onChange={getData}
        />
      </div>
    </div>

    // <div className="my-3 border border-secondary p-2 rounded">
    //   <div className="d-flex align-items-center justify-content-between ">
    //     <div></div>
    //     <div className="d-flex my-1">
    //       <div>
    //         <input
    //           onChange={handleAddBanner}
    //           type="file"
    //           id="banner1"
    //           accept="image/png, image/gif, image/jpeg"
    //           className="d-none"
    //         />
    //         <div></div>
    //         <label
    //           htmlFor="banner1"
    //           className="border px-2 rounded clickable d-block">
    //           upload/change
    //         </label>
    //         <input
    //           type="text"
    //           placeholder="add title here...."
    //           id="header"
    //           onChange={getData}
    //         />
    //       </div>
    //     </div>
    //   </div>

    //   <div>
    //     <img src={heroBannerImage} alt="" width="100%" height="auto" />
    //   </div>
    // </div>
  );
};

export default HeroBanner;
