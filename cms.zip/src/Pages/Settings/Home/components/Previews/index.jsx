import React, { useEffect, useState } from "react";
import { calls } from "../../../../../services/promiseHandler/promiseHandler";
import { ReactSortable } from "react-sortablejs";
import TitleTable from "../TitleTable/TitleTable";
// { previews, setPreviews }
const Previews = ({ leagueMatches, LeagueTitile }) => {
  const [previews, setPreviews] = useState([]);
  useEffect(() => {
    (async () => {
      const previews = leagueMatches;
      setPreviews(previews);
    })();
  }, []);
  const handleSort = (e) => {
    const { oldIndex, newIndex } = e;
    const updatedPreviews = [...previews];

    // Update order field of the moved item
    updatedPreviews[oldIndex].order = newIndex + 1;

    // Update order fields of affected items
    if (oldIndex < newIndex) {
      // Item moved downwards
      for (let i = oldIndex + 1; i <= newIndex; i++) {
        updatedPreviews[i].order = updatedPreviews[i].order - 1;
      }
    } else {
      // Item moved upwards
      for (let i = newIndex; i < oldIndex; i++) {
        updatedPreviews[i].order = updatedPreviews[i].order + 1;
      }
    }
  };

  return (
    <div
      className="position-absoulte container-fluid my-5 border border-info p-2 rounded"
      style={{ cursor: "all-scroll" }}>
      <h5 className="ml-2"> {LeagueTitile} </h5>
      <div
        className="row ml-2 mr-2 mb-2 mt-2"
        style={{ backgroundColor: "black" }}>
        <div
          className="col-md-7 h-full bg-black"
          style={{
            backgroundColor: "black",
            height: "400px",
          }}>
          <div className="row mt-3 ">
            <div className="col-md-6">
              <div>
                <TitleTable
                  fontSize="30px"
                  fontWeight="900"
                  width="50px"
                  title={previews?.[0]?.title}
                />
              </div>
              <h3
                className="mt-4 text-uppercase"
                style={{ color: "white", fontSize: "20px", fontWeight: "900" }}>
                {previews?.[0]?.subTitle}
              </h3>
              <h6
                className="mt-5"
                style={{ color: "white", fontSize: "15px", fontWeight: "800" }}>
                {previews?.[0]?.excerpt}
              </h6>
            </div>
            <div className="col-md-6">
              <img
                width="100%"
                height="300"
                style={{
                  objectFit: "cover",
                  margin: 0,
                  padding: 0,
                }}
                src={previews?.[0]?.featuredImage}
                alt=""
              />
            </div>
          </div>
        </div>

        <div className="col-md-4">
          <div className="row">
            {/* <ReactSortable
            onEnd={(e) => {
               handleSort(e)
            }
          }
              dragClass="dragingItem"
              animation={500}
              list={previews}
              setList={setPreviews}
              scroll={true}> */}
            {previews?.slice(0, 3)?.map((item, i) => (
              <div
                key={`__previewSlice${item.order}`}
                className={`d-flex ${item !== 0 && "my-3 "}`}>
                <div className="">
                  <TitleTable
                    fontWeight="800"
                    fontSize="18px"
                    width="30px"
                    title={item?.title}
                  />
                </div>
                <img
                  className="mt-1 ml-2"
                  style={{ objectFit: "cover" }}
                  width={95}
                  height={95}
                  src={item?.featuredImage}
                  alt=""
                />
                <h6
                  className="ml-2 mt-1 text-md text-uppercase"
                  style={{
                    color: "white",
                    fontSize: "13px",
                    fontWeight: "900",
                  }}>
                  {item?.subTitle}
                </h6>
              </div>
            ))}
            {/* </ReactSortable> */}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Previews;
