import React from "react";

export default function Fandeul({
  link,
  heading,
  podbanner,
  podhero,
  getpodHeading,
  getpodLink,
}) {
  return (
    <div
      className="my-3 border border-secondary p-2 rounded "
      style={{ cursor: "all-scroll" }}>
      <h5 className="ml-2"> Fanduel </h5>
      <div className="bg-black pt-3 pb-3">
        <div className="row d-flex" style={{ justifyContent: "space-between" }}>
          <div className="col-md-6">
            <div className="container">
              <div className="ml-3 mb-3">
                <svg
                  width="103"
                  height="108"
                  viewBox="0 0 102 101"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg">
                  <path
                    d="M65.4728 43.4697V34.8587H36.1484V65.4829H65.4728V56.8719H47.1464V54.0015H63.6434V46.3619H47.1464V43.4697H65.4728Z"
                    fill="white"
                  />
                  <path
                    d="M65.4728 78.0227V69.4117H36.1484V100.036H65.4728V91.4249H47.1464V88.5546H63.6434V80.9149H47.1464V78.0227H65.4728Z"
                    fill="white"
                  />
                  <path
                    d="M99.6278 45.7071V45.6198C99.6278 42.4657 98.6535 40.1956 96.7917 38.3512C94.6159 36.2121 91.1086 34.8478 85.5988 34.8478H70.4116V65.4829H80.8034V56.73H83.0225L88.8787 65.4829H100.732L93.4901 55.0711C97.268 53.2813 99.6169 50.1708 99.6169 45.7071H99.6278ZM89.2792 46.4492C89.2792 48.3264 87.7746 49.4287 85.2849 49.4287H80.8034V43.437H85.3282C87.7205 43.437 89.2792 44.3974 89.2792 46.3728V46.4601V46.4492Z"
                    fill="white"
                  />
                  <path
                    d="M18.2981 23.4647C14.4878 23.4647 10.4501 22.4279 6.92123 19.9068L1.11914 26.3787C5.25421 29.762 11.197 31.4973 17.7893 31.4973C26.5249 31.4973 32.143 27.5901 32.143 21.2165V21.1291C32.143 15.0174 26.5682 12.7583 18.2548 11.3285C14.8233 10.7174 13.9357 10.2044 13.9357 9.37497V9.28766C13.9357 8.54552 14.6826 8.03257 16.3063 8.03257C19.3265 8.03257 22.9961 8.93842 26.0595 11.023L31.3528 4.16908C27.5858 1.38605 22.9419 0 16.6744 0C7.71144 0 2.88358 4.46375 2.88358 10.2372V10.3245C2.88358 16.7418 9.29187 18.6954 16.5878 20.0814C20.0734 20.7362 21.0909 21.2055 21.0909 22.0786V22.166C21.0909 22.9954 20.2574 23.4647 18.3089 23.4647H18.2981Z"
                    fill="white"
                  />
                  <path
                    d="M86.18 31.399C94.0172 31.399 98.4337 27.7537 101.086 23.29L92.3934 18.6189C91.0836 20.8453 89.4166 22.3951 86.4506 22.3951C82.9867 22.3951 80.5511 19.6448 80.5511 15.7485V15.6612C80.5511 12.0597 82.8893 9.10203 86.4506 9.10203C89.33 9.10203 90.997 10.6081 92.1661 12.7472L100.858 7.90151C98.2064 3.30679 93.5192 0.0872192 86.5805 0.0872192C77.1629 0.0872192 69.8237 6.77739 69.8237 15.7376V15.8249C69.8237 25.1344 77.4336 31.399 86.1692 31.399H86.18Z"
                    fill="white"
                  />
                  <path
                    d="M17.3455 65.8212C25.1827 65.8212 29.5992 62.176 32.2513 57.7122L23.559 53.0411C22.2492 55.2675 20.5821 56.8173 17.6162 56.8173C14.1522 56.8173 11.7166 54.067 11.7166 50.1708V50.0835C11.7166 46.4819 14.0548 43.5243 17.6162 43.5243C20.4956 43.5243 22.1626 45.0304 23.3316 47.1695L32.024 42.3238C29.3719 37.729 24.6847 34.5204 17.746 34.5204C8.32847 34.5204 0.989258 41.2106 0.989258 50.1708V50.2581C0.989258 59.5676 8.59909 65.8321 17.3347 65.8321L17.3455 65.8212Z"
                    fill="white"
                  />
                  <path
                    d="M50.8159 31.4319C59.6056 31.4319 66.7391 24.4143 66.7391 15.7487C66.7391 7.08313 59.6056 0.0655518 50.8159 0.0655518C42.0261 0.0655518 34.8926 7.08313 34.8926 15.7487C34.8926 24.4143 42.0261 31.4319 50.8159 31.4319ZM50.8159 9.87707C54.1174 9.87707 56.7911 12.5073 56.7911 15.7596C56.7911 19.0119 54.1174 21.6422 50.8159 21.6422C47.5143 21.6422 44.8406 19.0119 44.8406 15.7596C44.8406 12.5073 47.5143 9.87707 50.8159 9.87707Z"
                    fill="white"
                  />
                  <path
                    d="M25.4638 84.1017C28.9386 82.9558 31.2551 80.7185 31.2551 77.0623V76.975C31.2551 74.8687 30.4216 73.2752 29.2633 72.1839C27.3581 70.3831 24.5329 69.4117 20.0406 69.4117H1.86572V100.211H19.8565C28.0617 100.211 32.3267 96.5981 32.3267 91.6759V91.5886C32.3267 87.365 29.6422 85.2586 25.4638 84.1127V84.1017ZM12.4416 77.1933H17.1287C19.4452 77.1933 20.6035 77.9463 20.6035 79.2997V79.387C20.6035 80.7512 19.4885 81.4933 17.172 81.4933H12.4416V77.1824V77.1933ZM21.437 90.1698C21.437 91.4904 20.2354 92.4181 17.8648 92.4181H12.4416V87.8452H17.9081C20.2679 87.8452 21.4261 88.7729 21.4261 90.0934V90.1807L21.437 90.1698Z"
                    fill="white"
                  />
                  <path
                    d="M78.9639 100.212H90.683V78.1237H101V69.4117H68.647V78.1237H78.9639V100.212Z"
                    fill="white"
                  />
                </svg>
              </div>
              <div className="form-group mt-1">
                <input
                  // minlength="5"
                  // maxlength="40"
                  className="form-control form-control-lg"
                  type="text"
                  placeholder="Enter heading here...."
                  id="fanduelHeading"
                  defaultValue={heading}
                  onChange={getpodHeading}
                />
              </div>
              <div className="form-group mt-1">
                <button className="flex items-center p-3 mt-3 border-0 bg-white">
                  <span className="text-dark font-normal text-md text-bold ">
                    Join Us
                  </span>
                  <svg
                    className="ml-2 mt-1"
                    width="18"
                    height="13"
                    viewBox="0 0 18 21"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg">
                    <path
                      d="M18 10.5L0.749999 20.4593L0.75 0.540707L18 10.5Z"
                      fill="black"
                    />
                  </svg>
                </button>
                <div className="form-group mt-1">
                  <input
                    className="form-control"
                    type="text"
                    placeholder="Enter link here...."
                    id="fanduelLink"
                    defaultValue={link}
                    onChange={getpodLink}
                  />
                </div>
              </div>
            </div>
          </div>

          <div className="col-md-5 p-1 mr-4" style={{ position: "relative" }}>
            <div className="">
              <img src={podhero} alt="image" width="100%" height="100%" />
              <div
                className="d-flex"
                style={{ position: "absolute", top: 0, right: 15 }}>
                <div className="">
                  <input
                    onChange={podbanner}
                    type="file"
                    id="fanduelBanner"
                    accept="image/png, image/gif, image/jpeg"
                    className="d-none"
                  />
                  <label
                    htmlFor="fanduelBanner"
                    className="border px-2 bg-white rounded clickable d-block mt-2">
                    <i className="fa fa-plus"></i>
                  </label>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
