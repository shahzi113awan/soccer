import React, { useCallback, useState } from "react";
import { ReactSortable } from "react-sortablejs";
import { toast } from "react-toastify";
import HeroBanner from "./components/HeroBanner/HeroBanner";
import News from "./components/News";
import Previews from "./components/Previews";
import Listen from "./components/Listen";
import Module1 from "./components/Module1/Module1";
import Module2 from "./components/Module2/Module2";
import Module3 from "./components/Module3/Module3";
import Module4 from "./components/Module4/Module4";
import Slider from "./components/Slider/Slider";
import GoalFest from "./components/GoalFest";
import Fanduel from "./components/Fanduel/fanduel";
import {
  convertToBase64,
  imageDimensions,
} from "../../../utils/convertToBase64";
import AdBanner from "./components/AdBanner/AdBanner";
import { calls } from "../../../services/promiseHandler/promiseHandler";
import { useEffect } from "react";
import Input from "../../../components/common/input";
import TextArea from "../../../components/common/textarea";
import { set } from "lodash";
const Home = () => {
  const [loading, setLoading] = useState(true);

  const [bannerImage, setBannerImage] = useState(null);
  const [heroBanner, setHeroBanner] = useState("");
  const [Text, setText] = useState("");

  const [Image1, setImage1] = useState(null);
  const [alreadyImage1, setAlreadyImage1] = useState("");
  const [heading, setHeading] = useState("");
  const [description, setDescription] = useState("");
  const [link, setLink] = useState("");

  const [image2, setimage2] = useState(null);
  const [alreadyImage2, setAlreadyImage2] = useState("");
  const [heading2, setHeading2] = useState("");
  const [description2, setDescription2] = useState("");

  const [fanduelImage, setFanduelImage] = useState(null);
  const [fanduelExistImage, setFanduelExistImage] = useState("");
  const [fanduelHeading, setFanduelHeading] = useState("");
  const [fanduelLink, setFanduelLink] = useState("");

  const [metaTitle, setMetaTitle] = useState("");
  const [metaDescription, setMetaDescription] = useState("");
  const [metaKeyword, setMetaKeyword] = useState("");

  const [allLeaguesWithMatches, setAlLeaguesWithMatches] = useState([]);

  // const [altText, setAltText] = useState("");

  // const [newsState, setNewsState] = useState([]);
  // const [isUpdated, setIsUpdated] = useState(false);
  // const [previewsState, setPreviewsState] = useState([]);
  // const [isPreviewUpdated, setIsPreviewUpdated] = useState(false);
  const [state, setState] = useState([
    { id: 1, name: "news", isVisible: true },
    { id: 2, name: "previews", isVisible: true },
    { id: 3, name: "goalFest", isVisible: true },
    { id: 4, name: "Listen", isVisible: true },
    { id: 5, name: "module1", isVisible: true },
    { id: 4, name: "listen", isVisible: true },
    { id: 6, name: "adBanner", isVisible: true },
    { id: 7, name: "module2", isVisible: true },
    { id: 8, name: "adBanner", isVisible: true },
    { id: 9, name: "module3", isVisible: true },
    { id: 10, name: "slider", isVisible: true },
    { id: 11, name: "module4", isVisible: true },
    { id: 12, name: "adBanner", isVisible: true },
    { id: 13, name: "fanduel", isVisible: true },
  ]);

  const [pageId, setPageId] = useState(null);
  const [pageId2, setPageId2] = useState(null);
  const [pageId3, setPageId3] = useState(null);
  const [fanduelPageId, setFanduelPageId] = useState(null);

  const getpodHeading = async (e) => {
    const heads = e.target.value;
    setHeading(heads);
  };
  const getgoalHeading = async (e) => {
    const goal = e.target.value;
    setHeading2(goal);
  };
  const getFanduelHeading = async (e) => {
    const fanduelHeading = e.target.value;
    setFanduelHeading(fanduelHeading);
  };

  const getpodDescripation = async (e) => {
    const des = e.target.value;
    setDescription(des);
  };
  const getFanduelLink = async (e) => {
    const fanduelLink = e.target.value;

    setFanduelLink(fanduelLink);
  };

  const getgoalDescripation = async (e) => {
    const goal = e.target.value;
    setDescription2(goal);
  };

  const goalbanner = async (e) => {
    const file = e.target.files[0];
    const img = await convertToBase64(file);
    const imgSize = await imageDimensions(img);
    if (imgSize.width < 850 || imgSize.width > 950)
      toast.warning("Width should be between 850-950 pixels");

    setimage2(file);
    setAlreadyImage2(img);
  };

  const getFanduelBanner = async (e) => {
    const file = e.target.files[0];
    const img = await convertToBase64(file);
    const imgSize = await imageDimensions(img);
    if (imgSize.width < 850 || imgSize.width > 950)
      toast.warning("Width should be between 850-950 pixels");
    setFanduelImage(file);
    setFanduelExistImage(img);
  };

  const getpodLink = async (e) => {
    const lnk = e.target.value;
    setLink(lnk);
  };

  const podbanner = async (e) => {
    const file = e.target.files[0];
    const img = await convertToBase64(file);
    const imgSize = await imageDimensions(img);
    if (imgSize.width < 850 || imgSize.width > 950)
      toast.warning("Width should be between 850-950 pixels");
    setImage1(file);
    setAlreadyImage1(img);
  };

  const getData = async (e) => {
    const txt = e.target.value;
    setText(txt);
  };

  const handleAddBanner = async (e) => {
    const file = e.target.files[0];

    const img = await convertToBase64(file);

    const imgSize = await imageDimensions(img);
    if (imgSize.width < 1280 || imgSize.width > 2460) {
      toast.warning("Width should be between 1280-2460 pixels");
      return;
    }
    setBannerImage(file);
    setHeroBanner(img);
  };
  const handleMetaTitleChange = (e) => {
    setMetaTitle(e.target.value);
  };
  const handleMetaDescriptionChange = (e) => {
    const arrayOfStrings = e.target.value?.split(" ");
    const metaDescriptionLength = arrayOfStrings?.length;
    if (metaDescriptionLength > 3) {
      return;
    }
    setMetaDescription(e.target.value);
  };
  const handleMetaKeyWordChange = (e) => {
    setMetaKeyword(e.target.value);
  };
  // const handleAltTextChange = (e) => {
  //   setAltText(e.target.value);
  // };
  // const handleMetaTagChange = (e) => {
  //   setMetaTag(e.target.value);
  // };
  const getHomePageLayout = async () => {
    setLoading(true);

    try {
      const res = await calls("settings", "get");
      const apiRes = await calls("soccerPod", "get");
      const apiRes2 = await calls("moreTeamUsa", "get");
      const fanduelRes = await calls("fanduel", "get");
      const leagueRes = await calls("child/leagues", "get");

      setAlLeaguesWithMatches(leagueRes?.data);
      setPageId(res?.data?.[0]?._id);
      setPageId2(apiRes?.data?.[0]?._id);
      setPageId3(apiRes2?.data?.[0]?._id);
      setFanduelPageId(fanduelRes?.data?.[0]?._id);

      setHeroBanner(res?.data?.[0]?.value?.bannerImage);
      setText(res.data?.[0]?.text);
      setMetaTitle(res?.data?.[0]?.meta_title);
      setMetaDescription(res?.data?.[0]?.meta_des);
      setMetaKeyword(res?.data?.[0]?.meta_keyword);
      setAlreadyImage1(apiRes.data?.[0]?.image1);
      setAlreadyImage2(apiRes2.data?.[0]?.value?.image1);

      setState(JSON.parse(res?.data?.[0]?.value?.sections) ?? (state || []));

      setBannerImage(res?.data?.[0]?.value?.bannerImage);

      setImage1(apiRes?.data?.[0]?.value?.image1);
      setHeading(apiRes?.data?.[0]?.heading);
      setDescription(apiRes?.data?.[0]?.description);
      setLink(apiRes.data?.[0]?.link);
      setHeading2(apiRes2?.data?.[0]?.heading);
      setDescription2(apiRes2?.data?.[0]?.description);

      setFanduelImage(fanduelRes?.data?.[0]?.value?.image);
      setFanduelExistImage(fanduelRes.data?.[0]?.value?.image);
      setFanduelHeading(fanduelRes?.data?.[0]?.heading);
      setFanduelLink(fanduelRes.data?.[0]?.link);
      // const index = JSON.parse(res.data?.[0]?.value?.sections).findIndex(
      //   (item) => item.name === "news"
      // );

      // setNewsState(
      //   JSON.parse(res.data?.[0]?.value?.sections)?.[index]?.children
      // );

      // const previewIndex = res.data?.[0]?.value?.sections.findIndex(
      //   (item) => item.name === "previews"
      // );

      // setPreviewsState(
      //   JSON.parse(res.data?.[0]?.value?.sections)?.[previewIndex]?.children
      // );

      // setIsPreviewUpdated(true);
      // setIsUpdated(true);

      setLoading(false);
    } catch (err) {
      console.error(err);
      setLoading(false);
    }
  };

  useEffect(() => {
    getHomePageLayout();
  }, []);

  // useEffect(() => {
  //   const a = [...state];
  //   const index = state.findIndex((item) => item.name === "news");
  //   a[index] = { ...a[index], children: newsState };
  //   setState(a);
  // }, [newsState]);

  // const getNews = useCallback(async () => {
  //   const { data } = await calls("news", "get");

  //   if (isUpdated && data.length <= 0) {
  //     setNewsState([]);
  //     return;
  //   }
  //   if (isUpdated && !newsState) {
  //     setNewsState(data);
  //     return;
  //   }

  //   let temp = [];

  //   if (newsState.findIndex((item) => item._id === data[0]?._id) === -1) {
  //     temp = [data[0], ...newsState];
  //     setNewsState(temp);
  //   }
  // });

  // const getPreviews = useCallback(async () => {
  //   const { data } = await calls("previews", "get");
  //   if (isPreviewUpdated && !previewsState) {
  //     setPreviewsState(data);
  //     return;
  //   }
  //   let temp = [];

  //   if (previewsState.findIndex((item) => item._id === data[0]._id) === -1) {
  //     temp = [data[0], ...previewsState];
  //     setPreviewsState(temp);
  //   }
  // });

  // useEffect(() => {
  //   if (isPreviewUpdated) {
  //     getPreviews();
  //   }
  // }, [previewsState, isPreviewUpdated, getPreviews]);

  // useEffect(() => {
  //   if (isUpdated) {
  //     getNews();
  //   }
  // }, [newsState, isUpdated, getNews]);
  const handleSave = async () => {
    setLoading(true);
    try {
      const formData = new FormData();
      const fd = new FormData();
      const fd1 = new FormData();
      const fanduelFormData = new FormData();

      formData.append("key", "homePageLayout");
      formData.append("bannerImage", bannerImage);
      formData.append("text", Text);
      formData.append("meta_title", metaTitle);
      formData.append("meta_des", metaDescription);
      formData.append("meta_keyword", metaKeyword);
      // formData.append("altText", altText);

      fd.append("key", "any key");
      fd.append("image1", Image1);
      fd.append("heading", heading);
      fd.append("description", description);
      fd.append("link", link);
      fd1.append("key", "any key");
      fd1.append("image1", image2);
      fd1.append("heading", heading2);
      fd1.append("description", description2);

      fanduelFormData.append("key", "any key");
      fanduelFormData.append("image", fanduelImage);
      fanduelFormData.append("heading", fanduelHeading);
      fanduelFormData.append("link", fanduelLink);

      formData.append("value", JSON.stringify(state));
      fd.append("value", JSON.stringify(state));
      fd1.append("value", JSON.stringify(state));
      fanduelFormData.append("value", JSON.stringify(state));
      const leaguesBulk = allLeaguesWithMatches.map((item, index) => {
        return {
          updateOne: {
            filter: { _id: item._id },
            update: { $set: { order: index } },
          },
        };
      });
      const leaguesBulkRes = await calls("league/bulk", "put", {
        data: leaguesBulk,
      });
      const res = await calls(
        `settings${pageId ? "/" + pageId : ""}`,
        `${pageId ? "put" : "post"}`,
        formData
      );

      const apiRes = await calls(
        `SoccerPod${pageId2 ? "/" + pageId2 : ""}`,
        `${pageId2 ? "put" : "post"}`,
        fd
      );

      const apiRes2 = await calls(
        `moreTeamUsa${pageId3 ? "/" + pageId3 : ""}`,
        `${pageId3 ? "put" : "post"}`,
        fd1
      );

      const fanduelRes = await calls(
        `fanduel${fanduelPageId ? "/" + fanduelPageId : ""}`,
        `${fanduelPageId ? "put" : "post"}`,
        fanduelFormData
      );

      toast.success("Updated!");
      setLoading(false);
    } catch (err) {
      toast.error("Something went wrong :(");
      setLoading(false);
    }
  };

  const getComponent = (item) => {
    switch (item.name) {
      case "news":
        return <News />;
      // news={newsState} setNews={setNewsState}
      case "previews":
        return;
      // previews={previewsState} setPreviews={setPreviewsState}
      case "goalFest":
        return (
          <GoalFest
            goalbanner={goalbanner}
            goalhero={alreadyImage2}
            getgoalHeading={getgoalHeading}
            getgoalDescripation={getgoalDescripation}
            heading={heading2}
            description={description2}
            image2={image2}
          />
        );
      case "module1":
        return <Module1 />;
      case "listen":
        return (
          <Listen
            podbanner={podbanner}
            podhero={alreadyImage1}
            getpodHeading={getpodHeading}
            getpodDescripation={getpodDescripation}
            getpodLink={getpodLink}
            heading={heading}
            description={description}
            Image1={Image1}
            link={link}
          />
        );
      case "adBanner":
        return <AdBanner />;
      case "module2":
        return <Module2 />;
      case "module3":
        return <Module3 />;
      case "slider":
        return <Slider />;
      case "module4":
        return <Module4 />;
      case "fanduel":
        return (
          <Fanduel
            podbanner={getFanduelBanner}
            podhero={fanduelExistImage}
            getpodHeading={getFanduelHeading}
            getpodLink={getFanduelLink}
            heading={fanduelHeading}
            link={fanduelLink}
          />
        );
      default:
        return <></>;
    }
  };

  const handleEyeClick = (id) => {
    setState((prev) =>
      prev?.map((x) => (x.id === id ? { ...x, isVisible: !x?.isVisible } : x))
    );
  };
  return (
    <div>
      <button
        style={{ minWidth: "120px" }}
        disabled={loading}
        className="btn btn-info"
        onClick={handleSave}>
        {loading ? "Saving.." : "Save"}
      </button>
      <div className={loading ? "homePageLoading" : ""}>
        <HeroBanner
          handleAddBanner={handleAddBanner}
          heroBannerImage={heroBanner}
          getData={getData}
          Text={Text}
        />
        <div className="mb-3">
          <ReactSortable
            dragClass="dragingItem"
            animation={500}
            list={allLeaguesWithMatches}
            setList={setAlLeaguesWithMatches}
            scroll={true}>
            {allLeaguesWithMatches?.map((league) => (
              <div key={league._id} className="">
                <Previews
                  LeagueTitile={league.title}
                  leagueMatches={league?.matches}
                />
              </div>
            ))}
          </ReactSortable>
        </div>

        <ReactSortable
          dragClass="dragingItem"
          animation={500}
          list={state}
          setList={setState}
          scroll={true}>
          {state?.map((item) => (
            <div className="position-relative mb-5">
              <button
                onClick={() => handleEyeClick(item?.id)}
                className="homeSectionEye clickable border-0">
                <i
                  className={`fa fa-regular fa-eye${
                    !item?.isVisible ? "-slash" : ""
                  }`}></i>
              </button>
              <div
                key={item?.id}
                className={`${!item?.isVisible && "home-hiddenComp"}`}>
                {getComponent(item)}
              </div>
            </div>
          ))}
        </ReactSortable>
        <div className="mb-5">
          <h3>SEO Section</h3>
          <Input
            name="metaTitle"
            label="Meta Title"
            type="text"
            value={metaTitle}
            onChange={handleMetaTitleChange}
          />
          <TextArea
            id="metaDescription"
            rows="3"
            label="Meta Description"
            onChange={handleMetaDescriptionChange}
            value={metaDescription}
          />
          <Input
            name="metaKeyword"
            label="Keyword"
            type="text"
            value={metaKeyword}
            onChange={handleMetaKeyWordChange}
          />
        </div>
      </div>
    </div>
  );
};

export default Home;
