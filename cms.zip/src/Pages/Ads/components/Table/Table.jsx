import React from "react";

const Table = ({ rows }) => {
  return (
    <div>
      <table className="table">
        <thead>
          <tr>
            <th scope="col">#</th>
            <th scope="col">Name</th>
            <th scope="col">Category</th>
            <th scope="col">Type</th>
            <th scope="col">EXP Date</th>
            <th scope="col">Status</th>
            <th scope="col">Action</th>
          </tr>
        </thead>
        <tbody>
          {rows?.map((row, i) => (
            <tr>
              <th scope="row">{i++}</th>
              <th scope="row">{row?.name}</th>
              <th scope="row">{row?.category}</th>
              <th scope="row">{row?.type}</th>
              <th scope="row">{row?.status}</th>
              <th scope="row">{row?.expDate}</th>
              <th scope="row">
                <div className="d-flex">
                  <button type="button" className="btn p-1">
                    {" "}
                    <i className="fa fa-pencil" aria-hidden="true"></i>
                  </button>
                  <button type="button" className="btn p-1 mx-2">
                    {" "}
                    <i className="fa fa-eye" aria-hidden="true"></i>
                  </button>
                </div>
              </th>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default Table;
