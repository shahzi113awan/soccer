import React from "react";
import { useEffect } from "react";
import { toast } from "react-toastify";
import { useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { createAd, updateAd, getAd } from "../../../services/ads/ad";
import {
  convertToBase64,
  imageDimensions,
} from "../../../utils/convertToBase64";

const pages = [
  {
    id: 1,
    name: "News",
  },
  {
    id: 2,
    name: "Head to Head",
  },
  {
    id: 3,
    name: "Team USA",
  },
];

const NewAdd = ({ user }) => {
  const { id } = useParams();
  const [fileType, setFileType] = useState("");
  const [loading, setLoading] = useState(false);
  const [adUrl, setAdUrl] = useState("");

  const [fileLoading, setFileLoading] = useState(true);
  const [values, setValues] = useState({
    name: "", // name of the ad (xyz)
    type: "", // type of ad (image) OR (video)
    authorId: user.id,
    shortcode: "",
    url: "", // link of uploaded file
    linkTo: null, // link which will redirect user to a page.
    adFor: "", // ad for (news) OR (previews) OR (features) etc.
    adPosition: "", // where ad will be showen (sidebar) OR (main-content)
    expiryDate: "",
  });

  const [errors, setErrors] = useState({});

  const handleChangeInput = (e) => {
    const { name, value } = e.target;
    const currentDate = new Date();

    const selectedMonth = value?.split("-")?.[1];
    const selectedYear = value?.split("-")?.[0];
    setErrors({
      ...errors,
      [name]: false,
    });
    setValues({
      ...values,
      [name]: value,
    });
  };
  const handleChangetype = (e) => {
    const { name, id: value } = e.target;
    setErrors({
      ...errors,
      [name]: false,
    });
    setValues({
      ...values,
      [name]: value,
    });
    const videoTypes = "video/mp4,video/x-m4v,video/*";
    const imageType = "image/png, image/gif, image/jpeg";

    setFileType(e.target.id === "video" ? videoTypes : imageType);
  };

  const handleChangeFile = async (e) => {
    const inComingFile = e.target.files[0];
    setLoading(true);
    const file = await convertToBase64(inComingFile);

    if (values?.type === "image") {
      try {
        const imageSizes = await imageDimensions(file);
        if (values?.adPosition === "sidebar") {
          if (imageSizes.height !== 250 || imageSizes?.width !== 300) {
            toast.warn("Please Add a 300 x 250 image.");
            setLoading(false);

            // return;
          }
        }
      } catch (err) {
        toast.error("Please select a valid file");
        setLoading(false);
        setValues({
          ...values,
          url: "",
        });
      }
    }
    setFileLoading(false);
    setAdUrl(file);
    setValues({
      ...values,
      url: inComingFile,
    });
    setErrors({
      ...errors,
      url: false,
    });
    setLoading(false);
  };
  const handleChangeCategory = (key, value) => {
    setErrors({
      ...errors,
      [key]: false,
    });
    if (key !== "adFor") {
      setAdUrl("");
      setValues({
        ...values,
        [key]: value,
        url: "",
      });
    }
    setValues({
      ...values,
      [key]: value,
    });
  };
  const navigate = useNavigate();

  const createNewAd = async (data) => {
    setLoading(true);
    const res = await createAd(data);

    if (res?.status === 200) {
      const fd = new FormData();
      fd.append("authorId", user.id);
      fd.append("name", res?.data?.name);
      fd.append("type", res?.data?.type);
      fd.append(
        "shortcode",
        `${res?.data?._id},${res?.data?.type},${values.category}`
      );
      fd.append("url", res?.data?.url);
      if(!!res?.data?.linkTo){

        fd.append("linkTo", res?.data?.linkTo);
      }
      fd.append("adFor", res?.data?.adFor);
      fd.append("adPosition", res?.data?.adPosition);
      fd.append("expiryDate", res?.data?.expiryDate);
      const updatedShortCode = await updateAd(res?.data?._id, fd);
      if (updatedShortCode.status === 200) {
        toast.success("Successfuly Created");
        navigate("/ads");
      }
      setLoading(false);
      return;
    }
    setLoading(false);

    toast.error(res ?? "Something went wrong :(");
  };

  const handleValidation = () => {
    if (!values.name || values.name?.trim()?.length < 2) {
      setErrors({
        ...errors,
        name: "Please provide a correct name",
      });
      return false;
    }
    if (!values.type) {
      setErrors({
        ...errors,
        type: "Please select a type",
      });
      return false;
    }
    if (!values.adFor) {
      setErrors({
        ...errors,
        adFor: "Please select a Page",
      });
      return false;
    }
    if (!values.adPosition) {
      setErrors({
        ...errors,
        adPosition: "Please select a Position",
      });
      return false;
    }
    if (!values.url) {
      setErrors({
        ...errors,
        url: `Please select a ${values.type || "file"}`,
      });
      return false;
    }

    // if (!values.linkTo) {
    //   setErrors({
    //     ...errors,
    //     linkTo: "Please enter a url",
    //   });
    //   return false;
    // }
    if (!values.expiryDate) {
      setErrors({
        ...errors,
        expiryDate: "Please select a expiry date",
      });
      return false;
    }

    return true;
  };

  const handleSubmit = async (e) => {
    // try refactoring this code. It was written in hurry
    e.preventDefault();

    const isValid = handleValidation();
    if (isValid) {
      setLoading(true);
      const fd = new FormData();
      fd.append("authorId", user.id);
      fd.append("name", values?.name);
      fd.append("type", values?.type);
      fd.append("shortcode", `${values?._id},${values?.type},${values.adFor}}`);
      fd.append("url", values?.url);
      if(!!values.linkTo){

        fd.append("linkTo", values?.linkTo);
      }
      fd.append("adFor", values?.adFor);
      fd.append("adPosition", values?.adPosition);
      fd.append("expiryDate", values?.expiryDate);
      if (id) {
        const res = await updateAd(values._id, fd);

        if (res.status === 200) {
          toast.success("Successfuly Updated");
          navigate("/ads");
        }

        return;
      }

      createNewAd(fd);
    }
  };

  const fetchData = async () => {
    const res = await getAd(id);
    setValues({
      ...res.data,
      expiryDate: res?.data?.expiryDate?.split("T")?.[0],
    });
    setFileLoading(false);
    setAdUrl(res?.data?.url);
    const videoTypes = "video/mp4,video/x-m4v,video/*";
    const imageType = "image/png, image/gif, image/jpeg";

    setFileType(res?.data?.type === "video" ? videoTypes : imageType);
  };

  useEffect(() => {
    if (id) {
      fetchData();
    }
  }, [id]);

  return (
    <div>
      <h1>{id ? "Update Ad" : "Create New Ad"}</h1>
      <form>
        <div className="form-row">
          <div className="form-group col-md-8">
            <div className="form-row">
              <div className="form-group col-md-6">
                <div className="form-group">
                  <label htmlFor="name" className="font-weight-bold py-2">
                    Name
                  </label>
                  <input
                    type="text"
                    className="form-control"
                    required
                    disabled={loading}
                    onChange={handleChangeInput}
                    name="name"
                    value={values?.name}
                    id="name"
                    placeholder="Enter Name"
                  />
                  {errors?.name && (
                    <small className="text-danger">{errors?.name}</small>
                  )}
                </div>
              </div>
              <div className="form-group col-md-6">
                <div className="form-group">
                  <div className="font-weight-bold py-2">Type</div>

                  <div className="d-flex justify-content-between px-3">
                    <div>
                      <label htmlFor="image" className="mb-1 clickable">
                        Image
                      </label>
                      <input
                        type="radio"
                        onChange={handleChangetype}
                        disabled={loading || id}
                        name="type"
                        checked={values?.type === "image"}
                        className="clickable form-control"
                        style={{ height: "15px" }}
                        id="image"
                      />
                    </div>
                    <div>
                      <label htmlFor="video" className="mb-1 clickable">
                        Video
                      </label>
                      <input
                        type="radio"
                        onChange={handleChangetype}
                        disabled={loading || id}
                        name="type"
                        checked={values?.type === "video"}
                        className="clickable form-control"
                        style={{ height: "15px" }}
                        id="video"
                      />
                    </div>
                  </div>
                  {errors?.type && (
                    <small className="text-danger">{errors?.type}</small>
                  )}
                </div>
              </div>

              <div className="form-group col-md-6">
                <div className="row">
                  <div className="col-md-6">
                    <div className="my-1 font-weight-bold py-2">Page</div>
                    <div className="dropdown">
                      <button
                        className="btn btn-primary dropdown-toggle"
                        type="button"
                        id="dropdownMenuButton"
                        data-toggle="dropdown"
                        aria-haspopup="true"
                        aria-expanded="false"
                        disabled={id}>
                        {!values?.adFor ? "Select Page" : values?.adFor}
                      </button>

                      <div
                        className="dropdown-menu"
                        aria-labelledby="dropdownMenuButton">
                        {pages?.map((page) => (
                          <div
                            key={page?.id}
                            onClick={() =>
                              handleChangeCategory("adFor", page?.name)
                            }
                            className="dropdown-item clickable border-bottom">
                            {page?.name}
                          </div>
                        ))}
                      </div>
                    </div>
                    {errors?.adFor && (
                      <small className="text-danger">{errors?.adFor}</small>
                    )}
                  </div>
                  <div className="col-md-6">
                    <div className="my-1 font-weight-bold py-2">
                      Ad Position
                    </div>
                    <div className="dropdown">
                      <button
                        className="btn btn-primary dropdown-toggle"
                        type="button"
                        id="dropdownMenuButton"
                        data-toggle="dropdown"
                        aria-haspopup="true"
                        aria-expanded="false">
                        {!values?.adPosition
                          ? "Select Position"
                          : values?.adPosition === "sidebar"
                          ? "MPU"
                          : "Main Content"}
                      </button>

                      <div
                        className="dropdown-menu"
                        aria-labelledby="dropdownMenuButton">
                        <div
                          onClick={() =>
                            handleChangeCategory("adPosition", "main-content")
                          }
                          className="dropdown-item clickable border-bottom">
                          Main Content
                        </div>
                        <div
                          onClick={() =>
                            handleChangeCategory("adPosition", "sidebar")
                          }
                          className="dropdown-item clickable border-bottom">
                          MPU
                        </div>
                      </div>
                    </div>
                    {errors?.adPosition && (
                      <small className="text-danger">
                        {errors?.adPosition}
                      </small>
                    )}
                  </div>
                </div>
              </div>
              <div className="form-group col-md-6">
                <div className="form-group">
                  <label htmlFor="file" className="font-weight-bold py-2">
                    File
                  </label>
                  <input
                    title={!values?.type ? "Please select type first" : ""}
                    type="file"
                    disabled={!fileType || loading}
                    className="form-control"
                    accept={fileType}
                    onChange={handleChangeFile}
                    onClick={(event) => {
                      event.target.value = null;
                    }}
                    required
                    id="file"
                  />
                  {errors?.url && (
                    <small className="text-danger">{errors?.url}</small>
                  )}
                </div>
              </div>
              <div className="form-group col-md-6">
                <div className="form-group">
                  <label htmlFor="linkTo" className="font-weight-bold py-2">
                    Redirect To
                  </label>
                  <input
                    type="url"
                    className="form-control"
                    required
                    disabled={loading}
                    name="linkTo"
                    value={values.linkTo}
                    onChange={handleChangeInput}
                    id="linkTo"
                    placeholder="Enter url"
                  />
                  {/* {errors?.linkTo && (
                    <small className="text-danger">{errors?.linkTo}</small>
                  )} */}
                </div>
              </div>
              <div className="form-group col-md-6">
                <div className="form-group">
                  <label htmlFor="expiryDate" className="font-weight-bold py-2">
                    EXP Date
                  </label>

                  <input
                    type="date"
                    className="form-control"
                    required
                    disabled={loading}
                    name="expiryDate"
                    min={new Date().toISOString().split("T")[0]}
                    value={values.expiryDate}
                    onChange={handleChangeInput}
                    onKeyDown={(e) => e.preventDefault()}
                    id="expiryDate"
                    placeholder="Enter url"
                  />
                  {errors?.expiryDate && (
                    <small className="text-danger">{errors?.expiryDate}</small>
                  )}
                </div>
              </div>
            </div>
          </div>
          <div className="form-group col-md-4 border-left border-info">
            {adUrl &&
              (fileLoading ? (
                <h4>Loading...</h4>
              ) : (
                <div className="mx-auto" style={{ maxWidth: "200px" }}>
                  {values?.type === "image" ? (
                    <img width="100%" src={adUrl} alt="" />
                  ) : (
                    <video
                      width="320"
                      height="240"
                      loop
                      autoPlay
                      src={adUrl}></video>
                  )}
                </div>
              ))}
          </div>
        </div>
        {user.userRole?.includes("Admin") && (
          <button
            type="submit"
            onClick={handleSubmit}
            disabled={loading}
            className="btn btn-primary">
            {loading ? "Loading..." : "Submit"}
          </button>
        )}
      </form>
    </div>
  );
};

export default NewAdd;
