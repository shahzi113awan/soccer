import React, { useState, useEffect } from "react";
import { toast } from "react-toastify";
import { Link } from "react-router-dom";
import _ from "lodash";
import { CopyToClipboard } from "react-copy-to-clipboard";
import Pagination from "../../components/common/pagination";
import { deleteAd, getAds } from "../../services/ads/ad";
import { paginate } from "../../utils/paginate";

const Ads = ({ user }) => {
  const [ads, setAds] = useState([]);
  const [isAsc, setIsAsc] = useState(false);
  const [pagination, setPagination] = useState({
    pageSize: 10,
    currentPage: 1,
  });
  const [tempData, setTempData] = useState([]);
  const onDelete = async (object) => {
    if (window.confirm("Are you sure you want to delete this Ad?")) {
      const res = await deleteAd(object?._id);
      if (res?.status === 200) {
        setAds(ads.filter((x) => x?._id !== object?._id));
      }
      toast.info("Ad Deleted Successfully");
    }
  };

  useEffect(() => {
    (async () => {
      const res = await getAds();
      setAds(res?.data);
      setTempData(res?.data);
    })();
  }, []);

  const handlechangeSearch = (e) => {
    setAds((prev) =>
      tempData?.filter((p) =>
        p?.name?.toLowerCase()?.includes(e.target.value.toLowerCase())
      )
    );
  };

  const handlePageChange = (page) => {
    setPagination({
      ...pagination,
      currentPage: page,
    });
  };
  const getPagedData = () => {
    let collection = ads;

    const adsData = paginate(
      collection,
      pagination.currentPage,
      pagination.pageSize
    );

    return { totalCount: collection.length, data: adsData };
  };
  const { totalCount, data: adsData } = getPagedData();
  const sortByName = () => {
    const sortedAds = _.orderBy(ads, ["name"], [!isAsc ? "asc" : "desc"]);
    setAds(sortedAds);
    setIsAsc(!isAsc);
  };
  return (
    <div>
      <div className="d-flex justify-content-between">
        <div>
          {user.userRole?.includes("Admin") && (
            <Link
              className="btn btn-primary"
              to="/create-ad"
              style={{ marginBottom: 10, height: "max-content" }}>
              Create New
            </Link>
          )}
        </div>
        <div className="py-3">
          <input
            type="search"
            className="border p-2"
            onChange={handlechangeSearch}
            placeholder="Search.."
          />
        </div>
      </div>
      <table className="table">
        <thead>
          <tr>
            <th scope="col">
              <div className="clickable" onClick={sortByName}>
                Name <i className={`fa fa-sort-${isAsc ? "asc" : "desc"}`}></i>
              </div>
            </th>
            <th scope="col">Category</th>
            <th scope="col">Type</th>
            <th scope="col">Shortcode</th>
            <th scope="col">EXP Date</th>
            <th scope="col">Delete</th>
          </tr>
        </thead>
        <tbody>
          {adsData?.map((ad) => (
            <tr key={ad._id}>
              <td>
                <Link to={`/ads/${ad?._id}`}>{ad.name}</Link>
              </td>
              <td>
                <strong>{ad.adFor}</strong>&nbsp;
                <small>
                  <i>{ad?.adPosition}</i>
                </small>
              </td>
              <td>{ad.type}</td>
              <td>
                <CopyToClipboard
                  text={`~[SC~ ${ad?.shortcode?.id} ~[SC~`}
                  onCopy={() =>
                    toast.info("Shortcode is copied on clipboard.")
                  }>
                  <button
                    title="Click to Copy"
                    className="btn border-0 p-1 ml-2">
                    {`~[SC~ ${ad?.shortcode?.id} ~[SC~`}
                  </button>
                </CopyToClipboard>
              </td>
              <td>{ad.expiryDate?.split("T")?.[0]}</td>
              <td>
                {user.userRole?.includes("Admin") && (
                  <button
                    className="btn btn-small btn-danger"
                    onClick={() => onDelete(ad)}>
                    <i className="fa fa-trash" aria-hidden="true"></i>
                  </button>
                )}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      <Pagination
        itemsCount={totalCount}
        pageSize={pagination.pageSize}
        currentPage={pagination.currentPage}
        onPageChange={handlePageChange}
      />
    </div>
  );
};

export default Ads;
