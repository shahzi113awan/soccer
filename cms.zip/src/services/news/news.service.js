import { calls } from './../promiseHandler/promiseHandler';

export const getAllNews = () => {

  try {
    const res = calls('news', 'get')
    return res
  }
  catch (err) {
    return err
  }

}