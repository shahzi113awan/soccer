import axios from "axios";

export const calls = async (path, method, data = null) => {
  const environment = process.env.REACT_APP_NODE_ENV;
  let URL = "";

  if (environment === "uat") {
    URL = process.env.REACT_APP_UAT;
  } else if (environment === "production") {
    URL = process.env.REACT_APP_PROD;
  } else {
    URL = process.env.REACT_APP_DEV;
  }

  let response = await axios({
    method: method,
    url: `${URL}${path}`,
    data: data,
  });

  return response;
};
