import _ from "lodash";
const movies = [
  {
    "_id": "6267107e1535fc3b6f1fb49d",
    "title": "Avatar",
    "genre": {
        "name": "Sci Fi",
        "_id": "6213b05e310ef7c9d149f8f3"
    },
    "numberInStock": 9,
    "dailyRentalRate": 2.5,
    "Liked": true
  },
  {
      "_id": "62221d923d8bec05f9ff1804",
      "title": "Hang Out",
      "genre": {
          "name": "Comedy",
          "_id": "623dea09c880d64b479fa9e7"
      },
      "numberInStock": 8,
      "dailyRentalRate": 2,
  },
  {
      "_id": "6267157f48b87021eeac63f5",
      "title": "Interstellar",
      "genre": {
          "name": "Sci Fi",
          "_id": "6213b05e310ef7c9d149f8f3"
      },
      "numberInStock": 18,
      "dailyRentalRate": 2,
  },
  {
      "_id": "6222190e3d8bec05f9ff1800",
      "title": "Rocky",
      "genre": {
          "name": "Action",
          "_id": "6213a4dd8883c3594a2e1efa"
      },
      "numberInStock": 14,
      "dailyRentalRate": 3,
  },
  {
    "_id": "6222190e3d8bec05f9ff1807",
    "title": "Terminator",
    "genre": {
        "name": "Action",
        "_id": "6213a4dd8883c3594a2e1efa"
    },
    "numberInStock": 10,
    "dailyRentalRate": 2.5,
    "Liked": true
  },
  {
    "_id": "6222190e3d8bec05f9ff1887",
    "title": "Matrix",
    "genre": {
        "name": "Action",
        "_id": "6213a4dd8883c3594a2e1efa"
    },
    "numberInStock": 5,
    "dailyRentalRate": 3.5,
  }
]

function getMovies(){
  return movies;
}

function saveMovie(movie){
  movies.push(movie);
}

function getMovie(id){
  return _.find(movies , movie =>  movie._id === id); 
}

function updateMovie(_movie){
  return _.find(movies , movie => { return movie.id === _movie.id })
}

export { getMovies, saveMovie, getMovie, updateMovie }