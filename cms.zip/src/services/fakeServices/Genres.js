const genres = [{
  "_id": {
    "$oid": "6213a4dd8883c3594a2e1efa"
  },
  "name": "Action",
  "__v": 0
},{
  "_id": {
    "$oid": "6213b05e310ef7c9d149f8f3"
  },
  "name": "Sci Fi",
  "__v": 0
},{
  "_id": {
    "$oid": "623dea09c880d64b479fa9e7"
  },
  "name": "Comedy",
  "__v": 0
}]

function getGenres(){
  return genres;
}

module.exports.Genres = getGenres()