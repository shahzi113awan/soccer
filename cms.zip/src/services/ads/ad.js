import { calls } from "../promiseHandler/promiseHandler";

export const createAd = async (data) => {
  try {
    return await calls("advertisements", "post", data);
  } catch (err) {
    return err.response?.data.message;
  }
};
export const getAds = () => {
  try {
    const res = calls("advertisements", "get");
    return res;
  } catch (err) {
    return err;
  }
};
export const deleteAd = (id) => {
  try {
    const res = calls(`advertisements/${id}`, "delete");
    return res;
  } catch (err) {
    return err;
  }
};
export const getAd = async (id) => {
  try {
    const res = calls(`advertisements/${id}`, "get");
    return res;
  } catch (err) {
    return err;
  }
};
export const updateAd = (id, data) => {
  try {
    const res = calls(`advertisements/${id}`, "put", data);
    return res;
  } catch (err) {
    return err;
  }
};
