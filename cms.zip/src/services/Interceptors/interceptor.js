import Axios from "axios";

/* Error Show/Hide logic */
const handleError = (err) => {
  // handle your error here
  // console.log(`Logging the error from interceptor: ${err}`)
};

/* Function to validate|prepare|modify error object */
const prepareErrorObject = (error) => {
  let err = (error?.response?.data ?? error) || error.message;
  if (typeof err === "object") {
    err.timestamp = Date.now();
    err.config = error?.config;
  } else {
    err = {};
    err.message = "Something went wrong.";
    err.timestamp = Date.now();
  }
  return err;
};
const token = localStorage.getItem("token");
const interceptor = {
  setupInterceptors: (store) => {
    Axios.interceptors.request.use(
      (config) => {
        if (config?.method !== "get" && token) {
          config.headers = {
            ...config.headers,
            "x-auth-token": token,
          };
        }

        return config;
      },
      (error) => {
        handleError(error);
      }
    );

    // Response interceptor
    Axios.interceptors.response.use(
      (response) => {
        if (!response) return;
        const { data = {} } = response;

        if (data.status >= 400) {
          const err = prepareErrorObject(data);
          handleError(err);
        }

        if (response?.data?.message) {
          //   show your success message.
        }

        return response;
      },
      (error) => {
        const expectedError =
          error.response &&
          error.response.status >= 400 &&
          error.response.status < 500;

        if (!expectedError) {
          alert(`An unexpected error occured.`);
          console.log(error.message);
        }

        return Promise.reject(error ? error["response"] : null);
      }
    );
  },
};
export default interceptor;
