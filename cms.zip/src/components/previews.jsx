import React, { Component } from "react";
import Pagination from "./common/pagination";
import PreviewTable from "./previewTable";
import { paginate } from "../utils/paginate";
import _ from "lodash";
import { Link } from "react-router-dom";
import SearchBox from "./common/searchBox";
import axios from "axios";
import { toast } from "react-toastify";
import { baseUrl } from "./../utils/baseUrl";
import FilterSearchBox from "./common/filterSearchBox";

class Previews extends Component {
  state = {
    previews: [],
    pageSize: 10,
    currentPage: 1,
    sortColumn: { path: "", order: "" },
    searchQuery: "",
    draftFilter: false,
    archiveFilter: false,
    publishedFilter: false,
    showHideFilters: false,
    isLoaded: false,
    error: "",
  };

  async componentDidMount() {
    await axios
      .get(`${baseUrl()}previews`)
      .then((res) => {
        this.setState({ previews: res.data, isLoaded: true });
      })
      .catch((err) => {
        this.setState({ error: err.message, isLoaded: true });
      });
  }

  handleDelete = async (previews) => {
    if (window.confirm("Are you sure you want to delete this?")) {
      const previewsCurrentState = [...this.state.previews];
      const _previews = this.state.previews.filter(
        (n) => n._id !== previews._id
      );
      this.setState({ previews: _previews });

      const deletedPreview = await axios
        .delete(`${baseUrl()}previews/${previews._id}`)
        .catch((err) => {
          this.setState({ error: err.message });
        });

      if (deletedPreview) {
        this.notify();
      } else {
        this.setState({ previews: previewsCurrentState });
      }
    }
  };

  handlePageChange = (page) => {
    this.setState({ currentPage: page });
  };

  handleSearch = (query) => {
    this.setState({ searchQuery: query, currentPage: 1 });
  };

  handleDraftFilter = () => {
    this.setState({ draftFilter: !this.state.draftFilter });
  };

  handleArchiveFilter = () => {
    this.setState({ archiveFilter: !this.state.archiveFilter });
  };

  handlePublishedFilter = () => {
    this.setState({ publishedFilter: !this.state.publishedFilter });
  };

  handleSort = (sortColumn) => {
    this.setState({ sortColumn });
  };

  notify = () => {
    toast.error("Head to Head is deleted!");
  };

  getPagedData = () => {
    const {
      pageSize,
      currentPage,
      sortColumn,
      previews,
      searchQuery,
      draftFilter,
      archiveFilter,
      publishedFilter,
    } = this.state;

    let filtered = previews;

    if (searchQuery) {
      filtered = previews.filter((n) =>
        n.title.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }
    if (draftFilter) {
      filtered = previews.filter((post) => post.status === "draft");
    }
    if (publishedFilter) {
      filtered = previews.filter((post) => post.status === "published");
    }

    if (archiveFilter) {
      filtered = previews.filter((post) => post.status === "archive");
    }

    const sorted = _.orderBy(filtered, [sortColumn.path], [sortColumn.order]);

    const _previews = paginate(sorted, currentPage, pageSize);

    return { totalCount: filtered.length, data: _previews };
  };
  handleFilters = () => {
    this.setState({ showHideFilters: !this.state.showHideFilters });
  };
  render() {
    const {
      pageSize,
      currentPage,
      sortColumn,
      searchQuery,
      draftFilter,
      archiveFilter,
      publishedFilter,
      showHideFilters,
    } = this.state;

    if (!this.state.isLoaded && !this.state.error)
      return (
        <div className="lds-ellipsis">
          <div></div>
          <div></div>
          <div></div>
          <div></div>
        </div>
      );

    if (this.state.error) return <p>{this.state.error}</p>;
    

    if (this.state.previews.length === 0) {
      return (
        <>
          <p>There are no head to head to show.</p>
          {this.props.user.userRole?.includes("Admin") && (
            <Link
              className="btn btn-primary"
              to="/create-head-to-head"
              style={{ marginBottom: 10, height: "max-content" }}>
              Create New
            </Link>
          )}
        </>
      );
    }

    const { totalCount, data: previews } = this.getPagedData();

    return (
      <div className="row">
        <div className="col">
          <div className="d-flex justify-content-between align-items-end gap-8">
            <div className="flex-1">
              {this.props.user.userRole?.includes("Admin") && (
                <Link
                  className="btn btn-primary"
                  to="/create-head-to-head"
                  style={{ marginBottom: 10, height: "max-content" }}>
                  Create New
                </Link>
              )}
              <p>Showing {totalCount} records from the database.</p>
            </div>
            {/* <SearchBox
              value={searchQuery}
              onChange={this.handleSearch}
              placeholder="Search..."
            /> */}
            <div className="d-inline-flex">
              <FilterSearchBox
                value={searchQuery}
                onChange={this.handleSearch}
                placeholder="Search..."
              />
              <button
                className="d-flex btn btn-primary flex mb-2 ml-2"
                onClick={this.handleFilters}>
                Filters
              </button>
            </div>
          </div>
          <div className="d-flex justify-content-between align-items-end gap-8">
            <div></div>

            {showHideFilters && (
              <div className="custom-checkbox mt-2 d-inline-flex ">
                <label className="custom-checkbox mr-1 ml-1">
                  <input
                    className="mr-1 "
                    type="checkbox"
                    checked={draftFilter}
                    onChange={this.handleDraftFilter}
                  />
                  Draft
                </label>
                <label className="custom-checkbox mr-1 ml-1">
                  <input
                    className="mr-1 ml-1"
                    type="checkbox"
                    checked={archiveFilter}
                    onChange={this.handleArchiveFilter}
                  />
                  Archive
                </label>
                <label className="custom-checkbox mr-1 ml-1">
                  <input
                    className="mr-1 ml-1"
                    type="checkbox"
                    checked={publishedFilter}
                    onChange={this.handlePublishedFilter}
                  />
                  Published
                </label>
              </div>
            )}
          </div>
          <PreviewTable
            previews={previews}
            sortColumn={sortColumn}
            onSort={this.handleSort}
            onDelete={this.handleDelete}
            user={this.props.user}
          />
          <Pagination
            itemsCount={totalCount}
            pageSize={pageSize}
            currentPage={currentPage}
            onPageChange={this.handlePageChange}
          />
        </div>
      </div>
    );
  }
}

export default Previews;
