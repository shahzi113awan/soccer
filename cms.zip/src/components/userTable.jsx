import React, { Component } from "react";
import Table from "./common/table";

class UserTable extends Component {
  columns = [
    {
      path: "name",
      label: "Name",
      linkedColumn: true,
    },
    
    { path: "email", label: "Email" },
    { path: "userRole", label: "Role" },
    {
      label: "Delete",
      key: "Delete",
      content: (users) => (
        <button
          className="btn btn-small btn-danger"
          onClick={() => this.props.onDelete(users)}>
          <i className="fa fa-trash" aria-hidden="true"></i>
        </button>
      ),
    },
  ];

  render() {
    const { users, onSort, sortColumn } = this.props;
    return (
      <Table
        columns={this.columns}
        sortColumn={sortColumn}
        data={users}
        onSort={onSort}
        baseRoute={"/users"}
        linkedColumnPath={"name"}
      />
    );
  }
}

export default UserTable;
