import React from "react";
import { useParams, useNavigate } from "react-router-dom";

const NewsDetail = () => {
  let { id } = useParams();
  const navigate = useNavigate();

  function handleSave() {
    navigate("/movies");
  }

  return (
    <>
      <h1>News id: {id}</h1>
      <button className="btn btn-primary" onClick={handleSave}>
        Save
      </button>
    </>
  );
};

export default NewsDetail;
