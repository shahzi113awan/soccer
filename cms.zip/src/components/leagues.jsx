import React, { Component } from "react";
import Pagination from "./common/pagination";
import { paginate } from "../utils/paginate";
import _ from "lodash";
import { Link } from "react-router-dom";
import SearchBox from "./common/searchBox";

import axios from "axios";
import { toast } from "react-toastify";
import { baseUrl } from "./../utils/baseUrl";
import LeagueTable from "./leaguesTable";
import { withRouter } from "./common/withRouter";
import FilterSearchBox from "./common/filterSearchBox";
import SortableMenues from "./common/SortableMenues";
class Leagues extends Component {
  state = {
    league: [],
    pageSize: 10,
    currentPage: 1,
    sortColumn: { path: "", order: "" },
    searchQuery: "",
    draftFilter: false,
    archiveFilter: false,
    publishedFilter: false,
    showHideFilters: false,
    isLoaded: false,
    error: "",
  };

  async componentDidMount() {
    await axios
      .get(`${baseUrl()}league`)
      .then((res) => {
        this.setState({ league: res.data, isLoaded: true });
      })
      .catch((err) => {
        this.setState({ error: err.message, isLoaded: true });
      });
  }
  goToMatches = async ({ slug }) => {
    try {
      this.props.navigate(`/league/${slug}/head-to-head`);
    } catch (error) {
      console.error(error);
    }
  };

  handleDelete = async (league) => {
    if (window.confirm("Are you sure you want to delete this?")) {
      const leagueCurrentState = [...this.state.league];
      const _league = this.state.league.filter((n) => n._id !== league._id);
      this.setState({ league: _league });

      const deletedLeague = await axios
        .delete(`${baseUrl()}league/${league._id}`)
        .catch((err) => {
          this.setState({ error: err.message });
        });

      if (deletedLeague) {
        this.notify();
      } else {
        this.setState({ league: leagueCurrentState });
      }
    }
  };

  handlePageChange = (page) => {
    this.setState({ currentPage: page });
  };

  handleSearch = (query) => {
    this.setState({ searchQuery: query, currentPage: 1 });
  };
  handleDraftFilter = () => {
    this.setState({ draftFilter: !this.state.draftFilter });
  };

  handleArchiveFilter = () => {
    this.setState({ archiveFilter: !this.state.archiveFilter });
  };

  handlePublishedFilter = () => {
    this.setState({ publishedFilter: !this.state.publishedFilter });
  };

  handleSort = (sortColumn) => {
    this.setState({ sortColumn });
  };

  notify = () => {
    toast.error("League is deleted!");
  };

  getPagedData = () => {
    const {
      pageSize,
      currentPage,
      sortColumn,
      league,
      searchQuery,
      draftFilter,
      archiveFilter,
      publishedFilter,
    } = this.state;

    let filtered = league;

    if (searchQuery) {
      filtered = league.filter((n) =>
        n.title.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }
    if (draftFilter) {
      filtered = league.filter((post) => post.status === "draft");
    }
    if (publishedFilter) {
      filtered = league.filter((post) => post.status === "published");
    }

    if (archiveFilter) {
      filtered = league.filter((post) => post.status === "archive");
    }

    const sorted = _.orderBy(filtered, [sortColumn.path], [sortColumn.order]);

    const _league = paginate(sorted, currentPage, pageSize);

    return { totalCount: filtered.length, data: _league };
  };
  handleFilters = () => {
    this.setState({ showHideFilters: !this.state.showHideFilters });
  };

  render() {
    const {
      pageSize,
      currentPage,
      sortColumn,
      searchQuery,
      draftFilter,
      archiveFilter,
      publishedFilter,
      showHideFilters,
    } = this.state;

    if (!this.state.isLoaded && !this.state.error)
      return (
        <div className="lds-ellipsis">
          <div></div>
          <div></div>
          <div></div>
          <div></div>
        </div>
      );

    if (this.state.error) return <p>{this.state.error}</p>;

    if (
      this.state.league.length === 0 &&
      this.props.user.userRole?.includes("Admin")
    ) {
      return (
        <>
          <p>There are no league to show.</p>
          <Link
            className="btn btn-primary"
            to="/create-league"
            style={{ marginBottom: 10, height: "max-content" }}>
            Create League
          </Link>
        </>
      );
    }

    const { totalCount, data: league } = this.getPagedData();

    return (
      <div className="row">
        <div className="col">
          <div className="d-flex justify-content-between align-items-end gap-8">
            <div className="flex-1">
              {this.props.user.userRole?.includes("Admin") && (
                <Link
                  className="btn btn-primary"
                  to="/create-league"
                  style={{ marginBottom: 10, height: "max-content" }}>
                  Create League
                </Link>
              )}
              <p>Showing {totalCount} records from the database.</p>
            </div>
            {/* <SearchBox
              value={searchQuery}
              onChange={this.handleSearch}
              placeholder="Search..."
            /> */}
            <div className="d-inline-flex">
              <FilterSearchBox
                value={searchQuery}
                onChange={this.handleSearch}
                placeholder="Search..."
              />
              <button
                className="d-flex btn btn-primary flex mb-2 ml-2"
                onClick={this.handleFilters}>
                Filters
              </button>
            </div>
          </div>
          <div className="d-flex justify-content-between align-items-end gap-8">
            <div></div>

            {showHideFilters && (
              <div className="custom-checkbox mt-2 d-inline-flex ">
                <label className="custom-checkbox mr-1 ml-1">
                  <input
                    className="mr-1 "
                    type="checkbox"
                    checked={draftFilter}
                    onChange={this.handleDraftFilter}
                  />
                  Draft
                </label>
                <label className="custom-checkbox mr-1 ml-1">
                  <input
                    className="mr-1 ml-1"
                    type="checkbox"
                    checked={archiveFilter}
                    onChange={this.handleArchiveFilter}
                  />
                  Archive
                </label>
                <label className="custom-checkbox mr-1 ml-1">
                  <input
                    className="mr-1 ml-1"
                    type="checkbox"
                    checked={publishedFilter}
                    onChange={this.handlePublishedFilter}
                  />
                  Published
                </label>
              </div>
            )}
          </div>
          <LeagueTable
            league={league}
            sortColumn={sortColumn}
            onSort={this.handleSort}
            onDelete={this.handleDelete}
            user={this.props.user}
            goToMatches={this.goToMatches}
          />
          <Pagination
            itemsCount={totalCount}
            pageSize={pageSize}
            currentPage={currentPage}
            onPageChange={this.handlePageChange}
          />
          {/* <div className="row my-4">
            <div className="col-md-6"></div>
            <div className="col-md-6 border p-4">
              <SortableMenues league={league} />
            </div>
          </div> */}
        </div>
      </div>
    );
  }
}

export default withRouter(Leagues);
