import { React, useState } from "react";
import axios from "axios";
import { toast } from "react-toastify";
import { baseUrl } from "./../utils/baseUrl";

const LoginForm = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [errors, setErrors] = useState({});

  const handleInputChange = (e) => {
    setErrors({});
    const { name, value } = e.target;
    if (name === "email") {
      setEmail(value);
    } else {
      setPassword(value);
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    if (email?.trim().length < 1) {
      setErrors({ email: "Email cannot be empty." });
      return;
    }

    if (password?.trim().length < 1) {
      setErrors({ password: "Password cannot be empty." });
      return;
    }

    const data = {
      email: email,
      password: password,
    };

    setIsLoading(true);

    axios
      .post(`${baseUrl()}users/login`, data, {
        headers: {
          "Content-Type": "application/json",
        },
      })
      .then((res) => {
        if (res) {
          localStorage.setItem("token", res.data.authToken);
          setIsLoading(false);
          window.location = "/homepage";
        }
      })
      .catch((res) => {
        if (res.data.message && res.status === 400) {
          setIsLoading(false);
          toast.error(res.data.message);
        }
        setIsLoading(false);
      });
  };

  return (
    <div className="container">
      
      <div className="col-sm-12 login-container">
        <form className="login-form d-flex align-items-center justify-content-center flex-column">
          <div className="logo">
            <img src="/soccerbx-logo-square.svg" alt="" />
          </div>
          <div className="form-group">
            <label htmlFor={"email"}>Email</label>
            <input
              value={email}
              onChange={handleInputChange}
              id={"email"}
              name={"email"}
              type={"email"}
              className="form-control"
              required
            />
            {errors.email && (
              <div className="alert alert-danger">{errors.email}</div>
            )}
          </div>
          <div className="form-group">
            <label htmlFor={"password"}>Password</label>
            <input
              value={password}
              onChange={handleInputChange}
              id={"password"}
              name={"password"}
              type={"password"}
              className="form-control"
              required
            />
            {errors.password && (
              <div className="alert alert-danger">{errors.password}</div>
            )}
          </div>
          <button
            onClick={handleSubmit}
            disabled={isLoading}
            className="btn btn-primary btn-block">
            {isLoading && (
              <div className="lds-ring">
                <div></div>
                <div></div>
                <div></div>
                <div></div>
              </div>
            )}
            Login <i className="fa fa-sign-in" aria-hidden="true"></i>
          </button>
        </form>
      </div>
    </div>
  );
};

export default LoginForm;
