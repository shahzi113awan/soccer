import React from "react";
import { capitalize } from "./../../utils/capitalize";
import { Link } from "react-router-dom";

const Breadcrumb = ({ breadCrumbs }) => {
  return (
    <nav aria-label="breadcrumb">
      <ol className="breadcrumb">
        <li className="breadcrumb-item">
          <Link to="/">
            <i className="fa fa-home" aria-hidden="true"></i> Home
          </Link>
        </li>
        {breadCrumbs?.map((bc, idx) => (
          <>
            {bc.includes("league") ? (
              <li
                key={bc}
                className={`breadcrumb-item ${
                  idx === breadCrumbs?.length - 2 && "active"
                }`}
                aria-current="page">
                {idx < breadCrumbs?.length ? (
                  <Link to={`${bc}`}>{bc.split("/")[idx]}</Link>
                ) : bc ? (
                  capitalize(bc.split("-")[0])
                ) : (
                  ""
                )}
              </li>
            ) : (
              <li
                key={bc}
                className={`breadcrumb-item ${
                  idx === breadCrumbs?.length - 1 && "active"
                }`}
                aria-current="page">
                {idx !== breadCrumbs?.length - 1 ? (
                  <Link to={`/${bc}`}>{capitalize(bc)}</Link>
                ) : bc ? (
                  capitalize(bc)
                ) : (
                  ""
                )}
              </li>
            )}
          </>
        ))}
      </ol>
    </nav>
  );
};

export default Breadcrumb;
