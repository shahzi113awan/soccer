import React, { useState } from "react";
import { ReactSortable } from "react-sortablejs";

const SortableMenues = ({ league }) => {
  const [menuItems, setMenuItems] = useState(league);

  const onSort = (sortedList) => {
    setMenuItems(sortedList);
  };

  return (
    <>
      <h5 className="mb-4 text-center">Sort league menus</h5>
      <ReactSortable
        dragClass="dragingItem"
        animation={500}
        group="menuItemsGroup"
        list={menuItems}
        setList={onSort}
        scroll={true}>
        {menuItems?.map((item) => (
          <div
            key={item.id}
            className="menu-item position-relative mb-2"
            data-id={item.id}>
            <h1 className="text-md">{item.title}</h1>
          </div>
        ))}
      </ReactSortable>
    </>
  );
};

export default SortableMenues;
