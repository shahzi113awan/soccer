import React from "react";

const SearchBox = ({ value, onChange, ...rest }) => {
  return (
    <input
      className="form-control search-control"
      type="text"
      value={value}
      onChange={(e) => onChange(e.currentTarget.value)}
      {...rest}
    />
  );
};

export default SearchBox;
