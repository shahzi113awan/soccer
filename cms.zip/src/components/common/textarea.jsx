import React from "react";

const TextArea = ({ id, rows, label, value, error, onChange }) => {
  return (
    <div className="form-group">
      <label htmlFor={id}>{label}</label>
      <textarea
        className="form-control"
        id={id}
        rows={rows}
        onChange={onChange}
        value={value}></textarea>
      {error && <div className="alert alert-danger">{error}</div>}
    </div>
  );
};

export default TextArea;
