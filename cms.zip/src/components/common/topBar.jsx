import React from "react";

const TopBar = ({ user }) => {
  const handleLogout = () => {
    localStorage.removeItem("token");
    window.location = "/login";
  };

  return (
    
    <div className="user-info">
      <div className="d-flex justify-content-left flex-col">
        <div className="first-letter mx-2">{user.name.split("")[0]}</div>
        <div className="name-and-role">
          <a href="/#" onClick={handleLogout}>
            <p>{user.name}</p>
            <span>{user.userRole}</span>
          </a>
        </div>
      </div>
    </div>
  );
};

export default TopBar;
