import React from "react";

const FilterSearchBox = ({ value, onChange, ...rest }) => {
  return (
    <input
      className="form-control filter-search-control"
      type="text"
      value={value}
      
      onChange={(e) => onChange(e.currentTarget.value)}
      {...rest}
    />
  );
};

export default FilterSearchBox;
