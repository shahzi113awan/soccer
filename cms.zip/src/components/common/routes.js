import { Navigate } from "react-router-dom";
import Ads from "../../Pages/Ads/Ads";
import NewAd from "../../Pages/Ads/NewAd/NewAd";
import Features from "../.././components/features";
import FeatureForm from "../.././components/featureForm";
import Users from "../.././components/users";
import UserForm from "../.././components/userForm";
import Home from "../.././Pages/Settings/Home/Home";
import News from "../.././components/news";
import Previews from "../.././components/previews";
import Subscribers from "../.././components/subscribers";
import Dashboard from "../.././components/dashboard";
import NewsForm from "../.././components/newsForm";
import PreviewForm from "../.././components/previewForm";
import Soccerbet from "../soccerbetForm";
import NotFound from "../.././components/404";
import Leagues from "../leagues";
import LeagueForm from "../leagueForm";
import Matches from "../matches";
import MatchForm from "../matchForm";
import NewsPreview from "../NewsFormPreview";
import SoccerPodForm from "../SoccerPodForm";
import SoccerPods from "../Soccrpods";

export const getRoutes = (user) => {
  const privateRoutes = [
    // {
    //   path: "/",
    //   element: <Dashboard user={user} />,
    // },
    // {
    //   path: "/dashboard",
    //   element: <Dashboard user={user} />,
    // },
    {
      path: "/ads",
      element: <Ads user={user} />,
    },
    {
      path: "/create-ad",
      element: <NewAd user={user} />,
      notAllowed: "View Only",
    },
    {
      path: "/ads/:id",
      element: <NewAd user={user} />,
    },
    {
      path: "/news",
      element: <News user={user} />,
    },
    {
      path: "/create-news",
      element: <NewsForm user={user} />,
      notAllowed: "View Only",
    },
    // {
    //   path: "/news-preview",
    //   element: <NewsPreview user={user} />,
    //   notAllowed: "View Only",
    // },
    {
      path: "/news/:id",
      element: <NewsForm user={user} />,
    },
    {
      path: "/pages/:id",
      element: <Soccerbet user={user} />,
    },
    {
      path: "/create-soccerpod",
      element: <SoccerPodForm user={user} />,
    },
    {
      path: "/soccerpods/:id",
      element: <SoccerPodForm user={user} />,
    },
    {
      path: "/soccerpods",
      element: <SoccerPods user={user} />,
    },

    {
      path: "/soccerpod/:id",
      element: <Soccerbet user={user} />,
    },
    {
      path: "/create-league",
      element: <LeagueForm user={user} />,
      notAllowed: "View Only",
    },
    {
      path: "/league",
      element: <Leagues user={user} />,
    },

    {
      path: "/league/:id",
      element: <LeagueForm user={user} />,
    },
    {
      path: "/league/:slug/head-to-head",
      element: <Matches user={user} />,
    },
    {
      path: "/league/:slugId/create-head-to-head",
      element: <MatchForm user={user} />,
      notAllowed: "View Only",
    },
    {
      path: "/league/:slugId/head-to-head/:id",
      element: <MatchForm user={user} />,
      notAllowed: "View Only",
    },
    {
      path: "/head-to-head",
      element: <Previews user={user} />,
    },
    {
      path: "/create-head-to-head",
      element: <PreviewForm user={user} />,
      notAllowed: "View Only",
    },
    {
      path: "/head-to-head/:id",
      element: <PreviewForm user={user} />,
    },
    {
      path: "/team-usa",
      element: <Features user={user} />,
    },
    {
      path: "/create-team-usa",
      element: <FeatureForm user={user} />,
      notAllowed: "View Only",
    },
    {
      path: "/team-usa/:id",
      element: <FeatureForm user={user} />,
    },
    {
      path: "/subscribers",
      element: <Subscribers user={user} />,
      notAllowed: "Content Admin,View Only",
      
    },
    {
      path: "/users",
      element: <Users user={user} />,
      notAllowed: "Content Admin,View Only",
    },
    {
      path: "/create-user",
      element: <UserForm user={user} />,
      notAllowed: "Content Admin,View Only",
    },
    {
      path: "/users/:id",
      element: <UserForm user={user} />,
      notAllowed: "Content Admin,View Only",
    },

    {
      path: "/homepage",
      element: <Home user={user} />,
      notAllowed: "Content Admin,View Only",
    },
    {
      path: "/",
      element: <Home user={user} />,
      notAllowed: "Content Admin,View Only",
    },
    {
      path: "/not-found",
      element: <NotFound />,
    },
    {
      path: "/login",
      element: <Navigate to="/homepage" />,
    },
  ];

  if (user?.name) {
    if (user.userRole === "Content Admin" || user.userRole === "View Only") {
      return privateRoutes.filter(
        (x) => !x?.notAllowed?.split(",")?.includes(user?.userRole?.trim())
      );
    }
    return privateRoutes;
  }
};
