import React from "react";
import { useState } from "react";
import { NavLink } from "react-router-dom";

export default function Sidebar({ user }) {
  const [isActive, setIsActive] = useState(false);
  const [ddActive, setDdActive] = useState(false);

  const handleDropDown = (e) => {
    setDdActive(!ddActive);
  };

  return (
    <header className={`sidebar-wrapper ${isActive ? "open-header" : ""}`}>
      <div className="position-relative">
        <div className="p-4">
          <h3>
            <NavLink to={"/homepage"} className="logo">
              Soccerbx
            </NavLink>
          </h3>
        </div>
        <div className="d-lg-none text-center mt-3 menu-btn-position">
          <button className="btn" onClick={() => setIsActive(!isActive)}>
            <i className="fa fa-bars" aria-hidden="true"></i>
          </button>
        </div>
        <nav className="sidebar-nav px-4">
          <ul className="sidebar-list ">
            <li>
              <i className="fa fa-tachometer" aria-hidden="true"></i>
              {/* <NavLink to="/dashboard">Dashboard</NavLink> */}
              <NavLink to="/homepage">Homepage</NavLink>
            </li>
            <li>
              <i className="fa fa-adn" aria-hidden="true"></i>
              <NavLink to="/ads">Ads</NavLink>
            </li>
            <li>
              <i className="fa fa-pencil" aria-hidden="true"></i>
              <NavLink to="/news">News</NavLink>
            </li>
            {/* <li>
              <i className="fa fa-plus-square-o" aria-hidden="true"></i>
              <NavLink to="/head-to-head">Head to Head</NavLink>
            </li> */}
            <li>
              <i className="fa fa-plus-square-o" aria-hidden="true"></i>
              <NavLink to="/league">Leagues</NavLink>
            </li>
            <li>
              <i className="fa fa-eercast" aria-hidden="true"></i>
              <NavLink to="/team-usa">Team USA</NavLink>
            </li>
            {/* <li>
              <i className="fa fa-cubes" aria-hidden="true"></i>
              <NavLink to="/pages/soccerbet">Soccerbet</NavLink>
            </li> */}
            <li>
              <i className="fa fa-cubes" aria-hidden="true"></i>
              <NavLink to="/soccerpods">Soccerpod</NavLink>
            </li>
            {(user.userRole === "Admin" || user.userRole === "Super Admin") && (
              <>
                <li>
                  <i className="fa fa-users" aria-hidden="true"></i>
                  <NavLink to="/subscribers">Subscribers</NavLink>
                </li>
                <li>
                  <i className="fa fa-user" aria-hidden="true"></i>
                  <NavLink to="/users">Users</NavLink>
                </li>
                {/* <li>
                  <a
                    className="link px-0 py-0 bg-transparent"
                    data-toggle="collapse"
                    data-target="#homeSetting"
                    aria-expanded="true"
                    aria-controls="homeSetting"
                    href="/#"
                    onClick={handleDropDown}>
                    <i className="fa fa-gear" style={{ color: "white" }}></i>{" "}
                    Appearnace
                  </a>
                  <i
                    className={`fa fa-caret-${ddActive ? "up" : "down"}`}
                    style={{
                      color: "#8a8a8a",
                      position: "relative",
                      left: "6px",
                      top: "2px",
                      fontSize: "18px",
                    }}></i>
                </li>
                <div
                  id="homeSetting"
                  className="collapse pl-4"
                  aria-labelledby="headingOne"
                  data-parent="#accordion">
                  <NavLink to="/homepage">Menues</NavLink>
                </div> */}
              </>
            )}
          </ul>
        </nav>
      </div>
    </header>
  );
}
