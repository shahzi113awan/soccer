const ListGroup = ({ items, selectedItem, searchQuery, onItemSelect }) => {
  return (
    <ul className="list-group">
      {items.map((item) => (
        <li
          key={Math.random()}
          className={
            item === selectedItem ? "list-group-item active" : "list-group-item"
          }
          onClick={() => onItemSelect(item)}
          style={{ cursor: "pointer" }}>
          {item.name}
        </li>
      ))}
    </ul>
  );
};

export default ListGroup;
