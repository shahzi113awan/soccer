import React, { Component } from "react";
import _ from "lodash";
import { Link } from "react-router-dom";
import { getHumanReadableTime, formatDate } from "../../utils/dateFormat";

class TableBody extends Component {
  renderCell = (item, column) => {
    const {
      baseRoute,
      
      linkedColumnPath,
      createdAtColumn,
      lastUpdateColumn,
      statusColumn,
      featureColumn,
      pinColumn,
      scheduleColumn,
    } = this.props;

    if (column.content) return column.content(item);
    if (column.createdAtColumn) return formatDate(item[createdAtColumn]);
    if (column.lastUpdateColumn)
      return getHumanReadableTime(item[lastUpdateColumn]);
    if (column.linkedColumn)
      return (
        <Link to={`${baseRoute}/${item.slug ?? item._id}`}>
          {item[linkedColumnPath]}
        </Link>
      );
    if (column.idCoulmn)
      return (
        <Link to={`${baseRoute}/${item._id}`}>{item[linkedColumnPath]}</Link>
      );
    if (column.path === featureColumn) {
      return (
        <span
          className={`badge text-white p-2 ml-3 ${
            item[featureColumn] ? "bg-primary" : ""
          }`}>
          {item[featureColumn] ? "Featured" : ""}
        </span>
      );
    }
    // if (column.path === statusColumn && column.statusColumn) {
    //   return (
    //     <span
    //       className={`badge text-white p-2 ${
    //         item[statusColumn] ? "bg-success" : "bg-danger"
    //       }`}>
    //       {item[statusColumn] ? "Published" : "Draft"}
    //     </span>
    //   );
    // }
    if (column.path === statusColumn && column.statusColumnB) {
      return (
        <span
          className={`badge text-white p-2 ${
            item[statusColumn] === "published"
              ? "bg-success"
              : item[statusColumn] === "archive"
              ? "bg-warning"
              : "bg-danger"
          }`}>
          {item[statusColumn]}
        </span>
      );
    }

    if (column.path === scheduleColumn) {
      return (
        <i
          className={item[scheduleColumn] ? "fa fa-clock-o text-gray" : ""}
          aria-hidden="true"></i>
        // <button
        //   className={`btn btn-small ${
        //     scheduleColumn ? "btn-primary" : ""
        //   } mr-2`}>
        //   <i
        //     className={item[scheduleColumn] ? "fa fa-clock-o" : "fa fa-clock-o"}
        //     aria-hidden="true"></i>
        // </button>
      );
    }
    if (column.path === pinColumn) {
      return (
        <button className="btn btn-small btn-primary mr-2">
          <i
            className={
              item[pinColumn]
                ? "fa fa-thumb-tack text-warning"
                : "fa fa-thumb-tack "
            }
            aria-hidden="true"></i>
        </button>
        // <span
        //   className={`badge text-white p-2 ${
        //     item[pinColumn] ? "bg-success" : "bg-danger"
        //   }`}>
        //   {item[pinColumn] ? "Published" : "Draft"}
        // </span>
      );
    }

    return _.get(item, column.path);
  };

  render() {
    const { data, columns } = this.props;
    return (
      <tbody className="text-capitalize">
        {data.length > 0 ? (
          data?.map((item) => (
            <tr key={item._id}>
              {columns.map((column) => (
                <td key={item._id + (column.path || column.key)}>
                  {this.renderCell(item, column)}
                </td>
              ))}
            </tr>
          ))
        ) : (
          <>
            <tr className="text-center">
              <td colSpan={columns?.length - 1 / 2}>
                <h1 className="text-center">No rows to display</h1>
              </td>
            </tr>
          </>
        )}
      </tbody>
    );
  }
}

export default TableBody;
