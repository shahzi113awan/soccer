import React from "react";
import { Editor } from "@tinymce/tinymce-react";

const TinyMCE = ({ editorRef, value, callback, customImageClass = "" }) => {
  return (
    
    <>
      <input
        id="my-file"
        type="file"
        name="my-file"
        style={{ display: "none" }}
        onChange=""
      />
      <Editor
        onInit={(evt, editor) => (editorRef.current = editor)}
        value={value}
        onEditorChange={callback}
        apiKey="475mge6w8k5s7lgufzcs5o4i6dnsbcomb4penidf7wl56i3k"
        init={{
          formats: {
            "custom-wrapper": {
              block: "table",
              classes: "xyz12123",
              wrapper: true,
            },
          },
          height: 500,
          menubar: true,
          table_sizing_mode: "resizetable",
          image_advtab: true,
          file_picker_callback: function (callback, value, meta) {
            if (meta.filetype == "image") {
              let input = document.getElementById("my-file");
              input.click();
              input.onchange = function () {
                var file = input.files[0];
                var reader = new FileReader();
                reader.onload = function (e) {
                  callback(e.target.result, {
                    alt: file.name,
                  });
                };
                reader.readAsDataURL(file);
              };
            }
          },
          extended_valid_elements: customImageClass,
          plugins: [
            "advlist",
            "autolink",
            "lists",
            "link",
            "image",
            "charmap",
            "preview",
            "anchor",
            "searchreplace",
            "visualblocks",
            "code",
            "fullscreen",
            "insertdatetime",
            "media",
            "table",
            "code",
            "help",
            "wordcount",
          ],
          toolbar:
            "undo redo | formatselect | " +
            "bold italic backcolor | alignleft aligncenter " +
            "alignright alignjustify | bullist numlist  " +
            "removeformat | code | link | image",
          content_style:
            "body { font-family:Helvetica,Arial,sans-serif; font-size:14px }",
        }}
      />
    </>
  );
};

export default TinyMCE;
