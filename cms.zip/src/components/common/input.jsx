import React from "react";

const Input = ({
  name,
  label,
  type,
  value,
  error,
  required,
  onChange,
  style,
  
  strongLable,
  handleKeyDown = () => {},
  ...rest
}) => {
  return (
    <div className="form-group">
      <label className={`${strongLable ? "text-bold" : ""}`} htmlFor={name}>
        {label}
      </label>
      <input
       style={style}
        value={value}
        onChange={onChange}
        id={name}
        onKeyDown={handleKeyDown}
        name={name}
        type={type}
        className="form-control"
        required={required}
        {...rest}
      />
      {error && <div className="alert alert-danger">{error}</div>}
    </div>
  );
};

export default Input;
