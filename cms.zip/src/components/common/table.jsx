import React from "react";
import TableHeader from "./tableHeader";
import TableBody from "./tableBody";

const Table = ({
  columns,
  sortColumn,
  onSort,
  data,
  baseRoute,
  linkedColumnPath,
  createdAtColumn,
  lastUpdateColumn,
  statusColumn,
  statusCoulmnB,
  featureColumn,
  leagueColumn,
  scheduleColumn,
  

  pinColumn,
}) => {
  return (
    <table className="table">
      <TableHeader columns={columns} sortColumn={sortColumn} onSort={onSort} />
      <TableBody
        data={data}
        columns={columns}
        baseRoute={baseRoute}
        linkedColumnPath={linkedColumnPath}
        createdAtColumn={createdAtColumn}
        lastUpdateColumn={lastUpdateColumn}
        statusColumn={statusColumn}
        statusColumnB={statusCoulmnB}
        featureColumn={featureColumn}
        leagueColumn={leagueColumn}
        scheduleColumn={scheduleColumn}
        pinColumn={pinColumn}
      />
    </table>
  );
};

export default Table;
