import React, { useState, useEffect } from "react";
import axios from "axios";
import slugify from "react-slugify";
import { useParams, useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import Input from "./common/input";
import { baseUrl } from "./../utils/baseUrl";
import "react-tabs/style/react-tabs.css";

const LeagueForm = ({ user }) => {
  const [title, setTitle] = useState("");
  const [slug, setSlug] = useState("");
  const [errors, setErrors] = useState([]);
  const [authorId] = useState(user.id);
  const [isActive, setIsActive] = useState(true);
  const [isLoading, setIsLoading] = useState(false);
  const [status, setStatus] = useState("published");


  const { id } = useParams();
  
  const navigate = useNavigate();

  async function getLeagueById(id) {
    await axios
      .get(`${baseUrl()}league/${id}`)
      .then(async (res) => {
        const { title, slug, isActive,status } = res.data;
        setTitle(title);
        setSlug(slug);
        setIsActive(isActive);
        setStatus(status);
      })
      .catch((err) => {
        if (err.data.error && err.status === 404) alert(err.data?.error);

        setErrors({ API: err.data?.error });
      });
  }

  useEffect(() => {
    if (id) {
      getLeagueById(id);
    }
  }, []);
  const handleIsActiveChange = (e) => {
    
    if(e.target.value === "published") setIsActive(true);
    setStatus(e.target.value);
  };
  const handleTitleChange = (e) => {
    const arrayOfStrings = e.target.value?.split(" ");
    const titleLength = arrayOfStrings?.length;

    if (titleLength > 3) {
      return;
    }

    setTitle(e.target.value);
  };

  const handleSlug = () => {
    if (!slug?.length) {
      let leagueSlug = slugify(title);
      setSlug(leagueSlug);
    }
    return;
  };

  const handleSlugChange = (e) => {
    setSlug(e.currentTarget.value);
  };

  const notify = (message) => {
    toast.success(message, {
      position: "top-right",
      autoClose: 2000,
      hideProgressBar: true,
      closeOnClick: true,
      pauseOnHover: true,
      draggable: true,
      progress: undefined,
    });
  };

  const notifyError = (message) => {
    toast.error(message, {
      position: "top-right",
      autoClose: 10000,
      hideProgressBar: true,
      closeOnClick: true,
      pauseOnHover: true,
      draggable: true,
      progress: undefined,
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // Data validation
    if (title?.trim().length < 2) {
      setErrors({ title: "Title cannot be empty or less than 2 characters." });
      return;
    } else if (title?.trim().length > 60) {
      setErrors({ title: "Title cannot be larger than 60 characters." });
      return;
    }

    if (slug?.trim().length === 0) {
      setErrors({ slug: "Slug cannot be empty" });
      return;
    } else if (slug?.trim().length > 60) {
      setErrors({ slug: "Slug cannot be larger than 60 characters." });
      return;
    }

    setIsLoading(true);
    // Building Form data
    const fd = new FormData();
    fd.append("title", title);
    fd.append("slug", slug);
    fd.append("authorId", authorId);
    fd.append("isActive", isActive);
    fd.append("status", status);

    if (!id) {
      axios
        .post(`${baseUrl()}league`, fd, {
          headers: {
            "Content-Type": "multipart/form-data",
          },
        })
        .then((res) => {
          setIsLoading(false);
          setErrors([]);
          if (res.status === 200) {
            navigate("/league");
            notify("New is created!");
          }
        })
        .catch((err) => {
          setIsLoading(false);
          console.log(err);
          setErrors([]);
          err?.data?.message
            ? toast.error(err.data.message)
            : toast.error("Something went wrong :(");
        });
    } else {
      axios
        .put(`${baseUrl()}league/${id}`, fd, {
          headers: {
            "Content-Type": "multipart/form-data",
          },
        })
        .then((res) => {
          setIsLoading(false);
          setErrors([]);
          if (res.status === 200) {
            navigate("/league");
            notify("league is updated!");
            return;
          }
        })
        .catch((err) => {
          setIsLoading(false);
          setErrors([]);
          err?.data?.message
            ? toast.error(err.data.message)
            : toast.error("Something went wrong :(");
        });
    }
  };

  return (
    <div className="row">
      <div className="col-md-12">
        <h1>{id ? "Update League" : "Create League"}</h1>
        <form onSubmit={handleSubmit} encType="multipart/form-data">
          <div className="row">
            <div className="col-md-8">
              <Input
                name="title"
                label="Title"
                type="text"
                value={title}
                onChange={handleTitleChange}
                onBlur={handleSlug}
                error={errors.title}
              />

              <Input
                name="slug"
                label="Slug"
                type="text"
                value={slug ?? ""}
                onChange={handleSlugChange}
                error={errors.slug}
              />
            </div>
            <div className="col-md-4">
              <div id="accordian" className="aside-accordian">
                <div className="card">
                  <div className="card-header" id="headingOne">
                    <h5 className="mb-o">
                      <a
                        href="/#"
                        className="btn btn-link"
                        data-toggle="collapse"
                        data-target="#collapseOne"
                        aria-expanded="true"
                        aria-controls="collapseOne">
                        Publish
                      </a>
                    </h5>
                  </div>
                  <div
                    id="collapseOne"
                    className="collapse show"
                    aria-labelledby="headingOne"
                    data-parent="#accordion">
                    <div className="card-body">
                      {!isLoading && (
                        <select
                          className="custom-select custom-select-md mb-3"
                          name="isActive"
                          id="isActive"
                          onChange={handleIsActiveChange}
                          value={status}>
                          {!isLoading ? (
                            <>
                                   <option value={"published"}>Publish</option>
                             <option value={"draft"}>Draft</option>
                             <option value={"archive"}>Archive</option>
                            </>
                          ) : (
                            <option value={true}>'...'</option>
                          )}
                        </select>
                      )}

                      {user.userRole !== "View Only" && (
                        <button
                          disabled={isLoading}
                          className="btn btn-primary">
                          {isLoading && (
                            <div className="lds-ring">
                              <div></div>
                              <div></div>
                              <div></div>
                              <div></div>
                            </div>
                          )}
                          {id ? "Update" : "Save"}
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};

export default LeagueForm;
