import React, { Component } from "react";
import Table from "./common/table";

class NewsTable extends Component {
  columns = [
    {
      path: "isScheduled",
      scheduleColumn: true,
    },
    {
      path: "_id",
      label: "Name",
      linkedColumn: true,
      linkedColumnPath: "_id",
    },
    { path: "authorId.name", label: "Author" },
    { path: "createdAt", label: "Created At", createdAtColumn: true },
    { path: "updatedAt", label: "Last Update", lastUpdateColumn: true },
    {
      path: "league.title",
      
      label: "League",
      leagueColumn: true,
    },

    {
      path: "isFeatured",
      label: "Homepage",
      featureColumn: true,
    },

    // {
    //   path: "isActive",
    //   label: "Status",
    //   statusColumn: true,
    // },
    {
      path: "status",
      label: "Status",
      statusColumnB: true,
    },
    {
      label: "Pin",
      key: "Pin",
      content: (news) => (
        <button
          className={`btn btn-small ${news.pinned ? "btn-primary" : ""}`}
          onClick={() => this.props.onHandlePin(news, news.pinned ? 0 : 1)}>
          <i className="fa fa-thumb-tack" aria-hidden="true"></i>
        </button>
      ),
    },

    {
      label: "Delete",
      key: "Delete",
      content: (news) =>
        this.props.user.userRole?.includes("Admin") && (
          <button
            className="btn btn-small btn-danger ml-3"
            onClick={() => this.props.onDelete(news)}>
            <i className="fa fa-trash" aria-hidden="true"></i>
          </button>
        ),
    },
  ];

  render() {
    const { news, onSort, sortColumn } = this.props;

    return (
      <Table
        columns={this.columns}
        sortColumn={sortColumn}
        data={news}
        onSort={onSort}
        baseRoute={"/news"}
        linkedColumnPath={"title"}
        createdAtColumn={"createdAt"}
        lastUpdateColumn={"updatedAt"}
        statusColumn={"status"}
        featureColumn={"isFeatured"}
        leagueColumn={"league"}
        pinColumn={"pinned"}
        scheduleColumn={"isScheduled"}
      />
    );
  }
}

export default NewsTable;
