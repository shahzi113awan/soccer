import React, { Component } from "react";
import Pagination from "./common/pagination";
import UserTable from "./userTable";
import { paginate } from "../utils/paginate";
import _ from "lodash";
import { Link } from "react-router-dom";
import SearchBox from "./common/searchBox";
import axios from "axios";
import { toast } from "react-toastify";
import { baseUrl } from "./../utils/baseUrl";


class Users extends Component {
  state = {
    users: [],
    pageSize: 10,
    currentPage: 1,
    sortColumn: { path: "", order: "" },
    searchQuery: "",
    isLoaded: false,
    error: "",
  };

  async componentDidMount() {
    await axios
      .get(`${baseUrl()}users`)
      .then((res) => {
        this.setState({ users: res.data, isLoaded: true });
      })
      .catch((err) => {
        this.setState({ error: err.message, isLoaded: true });
      });
  }

  handleDelete = async (user) => {
    if (window.confirm("Are you sure you want to delete this?")) {
      const userCurrentState = [...this.state.users];
      const _users = this.state.users.filter((u) => u._id !== user._id);
      this.setState({ users: _users });

      const deletedUser = await axios
        .delete(`${baseUrl()}users/${user._id}`)
        .catch((err) => {
          this.setState({ error: err.message });
        });

      if (deletedUser) {
        this.notify();
      } else {
        this.setState({ users: userCurrentState });
        toast.error("Something went wrong while deleting this object!");
      }
    }
  };

  handlePageChange = (page) => {
    this.setState({ currentPage: page });
  };

  handleSearch = (query) => {
    this.setState({ searchQuery: query, currentPage: 1 });
  };

  handleSort = (sortColumn) => {
    this.setState({ sortColumn });
  };

  notify = () => {
    toast.error("User is deleted!");
  };

  getPagedData = () => {
    const { pageSize, currentPage, sortColumn, users, searchQuery } =
      this.state;

    let filtered = users;

    if (searchQuery) {
      filtered = users.filter((u) =>
        u.name.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }

    const sorted = _.orderBy(filtered, [sortColumn.path], [sortColumn.order]);

    const _users = paginate(sorted, currentPage, pageSize);

    return { totalCount: filtered.length, data: _users };
  };

  render() {
    const { pageSize, currentPage, sortColumn, searchQuery } = this.state;

    if (!this.state.isLoaded && !this.state.error)
      return (
        <div className="lds-ellipsis">
          <div></div>
          <div></div>
          <div></div>
          <div></div>
        </div>
      );

    if (this.state.error) return <p>{this.state.error}</p>;

    if (this.state.users.length === 0) {
      return (
        <>
          <p>There are no users to show.</p>
          <Link
            className="btn btn-primary"
            to="/create-user"
            style={{ marginBottom: 10, height: "max-content" }}
          >
            Create New
          </Link>
        </>
      );
    }

    const { totalCount, data: users } = this.getPagedData();

    return (
      <div className="row">
        <div className="col">
          <div className="d-flex justify-content-between align-items-end gap-8">
            <div className="flex-1">
              <Link
                className="btn btn-primary"
                to="/create-user"
                style={{ marginBottom: 10, height: "max-content" }}
              >
                Create New
              </Link>
              <p>Showing {totalCount} users from the database.</p>
            </div>
            <SearchBox
              value={searchQuery}
              onChange={this.handleSearch}
              placeholder="Search..."
            />
          </div>
          <UserTable
            users={users}
            sortColumn={sortColumn}
            onSort={this.handleSort}
            onDelete={this.handleDelete}
          />
          <Pagination
            itemsCount={totalCount}
            pageSize={pageSize}
            currentPage={currentPage}
            onPageChange={this.handlePageChange}
          />
        </div>
      </div>
    );
  }
}

export default Users;
