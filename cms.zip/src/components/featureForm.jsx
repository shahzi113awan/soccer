import React, { useState, useEffect } from "react";
import Input from "./common/input";
import TinyMCE from "./common/tinymce";
import $ from "jquery";

import axios from "axios";
import Select from "react-select";
import { useParams, useNavigate } from "react-router-dom";
import TextArea from "./common/textarea";
import { useRef } from "react";
import { toast } from "react-toastify";
import { baseUrl } from "./../utils/baseUrl";
import slugify from "react-slugify";
import { getAds } from "../services/ads/ad";
import { CopyToClipboard } from "react-copy-to-clipboard";
import { Tab, Tabs, TabList, TabPanel } from "react-tabs";
import "react-tabs/style/react-tabs.css";
import moment from "moment-timezone";

const FeatureForm = ({ user }) => {
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const [image, setImage] = useState("");
  const [currentImage, setCurrentImage] = useState("");
  const [errors, setErrors] = useState("");
  const [authorId] = useState(user.id);
  const [subTitle, setSubTitle] = useState("");
  const [isActive, setIsActive] = useState(true);
  const [isContentChange, setIsContentChange] = useState(false);
  const [slug, setSlug] = useState("");
  const [adsToDisplay, setAdsToDisplay] = useState([]);
  const [selectedsidebarAds, setSelectedSidebarAds] = useState([]);
  const [mainContentAdsShortCodes, setMainContentAdsShortCodes] = useState([]);
  const [sidebarAds, setSidebarAds] = useState([]);
  const [excerpt, setExcerpt] = useState("");
  const [mainContentAds, setMainContentAds] = useState([]);
  const [sideBarAds, setSideBarAds] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [metaTitle, setMetaTitle] = useState("");
  const [metaDescription, setMetaDescription] = useState("");
  const [metaKeyword, setMetaKeyword] = useState("");
  const [altText, setAltText] = useState("");
  const [publisheDate, setPublisheDate] = useState("");
  const [isScheduled, setIsScheduled] = useState(false);
  const [status, setStatus] = useState("published");
  const [pinned, setPinned] = useState(0);
  const [touched,setTouched]  = useState(false)

  useEffect(() => {
    (async () => {
      const res = await getAds();
      setMainContentAds(
        res?.data?.filter(
          (n) => n.adFor === "Team USA" && n.adPosition === "main-content"
        )
      );
      setSideBarAds(
        res?.data?.filter(
          (n) => n.adFor === "Team USA" && n.adPosition === "sidebar"
        )
      );
    })();
  }, []);

  const handleIsActiveChange = (e) => {
    if (e.target.value === "published") setIsActive(true);

    setStatus(e.target.value);
  };
  let { id } = useParams();
  const navigate = useNavigate();
  async function getFeatureById(id) {
    await axios
      .get(`${baseUrl()}features/${id}`)
      .then(async (res) => {
        const {
          title,
          slug,
          sidebarAds,
          content,
          excerpt,
          subTitle,
          featuredImage,
          isActive,
          meta_title,
          meta_des,
          meta_keyword,
          altText,
          publisheDate,
          isScheduled,
          status,
        } = res.data;
        const adsIds = sidebarAds?.split(",");

        const spacesRemoved = adsIds?.map((item) => item?.trim());
        setTitle(title);
        setSlug(slug);
        setContent(content);
        setExcerpt(excerpt);
        setSubTitle(subTitle);
        setCurrentImage(featuredImage);
        setIsActive(isActive);
        setMetaTitle(meta_title);
        setMetaDescription(meta_des);
        setMetaKeyword(meta_keyword);
        setAltText(altText);
        setStatus(status);
        setPublisheDate(
          publisheDate ? moment(publisheDate).format("YYYY-MM-DDTHH:mm") : ""
        );
        setIsScheduled(isScheduled);
        const _res = await getAds();
        const options = _res?.data
          ?.filter(
            (x) => x?.adPosition === "sidebar" && x?.adFor === "Team USA"
          )
          ?.map((item) => ({
            value: item?.shortcode?.id,
            label: item?.name,
            id: item?.shortcode?.id,
          }));
        const mainContentShortCodes = _res?.data
          ?.filter(
            (x) => x?.adPosition === "main-content" && x?.adFor === "Team USA"
          )
          ?.map((item) => ({
            value: `~[SC~ ${item?.shortcode?.id} ~[SC~`,
            label: item?.name,
            id: item?.shortcode?.id,
          }));
        setAdsToDisplay(
          options?.filter((item) => {
            return spacesRemoved?.includes(item?.id.trim());
          })
        );
        setMainContentAdsShortCodes(mainContentShortCodes);
        setSidebarAds(options);
      })
      .catch((err) => {
        if (err.data.error && err.status === 404) alert(err.data?.error);

        setErrors({ API: err.data?.error });
      });
  }

  const getAdsData = async () => {
    const _res = await getAds();
    const options = _res?.data
      ?.filter((x) => x?.adPosition === "sidebar" && x?.adFor === "Team USA")
      ?.map((item) => ({
        value: item?.shortcode?.id,
        label: item?.name,
        id: item?.shortcode?.id,
        
      }));
    const mainContentShortCodes = _res?.data
      ?.filter(
        (x) => x?.adPosition === "main-content" && x?.adFor === "Team USA"
      )
      ?.map((item) => ({
        value: `~[SC~ ${item?.shortcode?.id} ~[SC~`,
        label: item?.name,
        id: item?.shortcode?.id,
      }));

    setMainContentAdsShortCodes(mainContentShortCodes);
    setSidebarAds(options);
  };

  useEffect(() => {
    if (id) getFeatureById(id);
    if (!id) getAdsData();
  }, [id]);

  const handleInputChange = (e) => {
    const titleLength = e.target.value?.split(" ")?.length;
    if (titleLength > 3) {
      return;
    }
    setTitle(e.currentTarget.value);
  };
  const handleMetaTitleChange = (e) => {
    setMetaTitle(e.target.value);
  };
  const handleMetaDescriptionChange = (e) => {
    setMetaDescription(e.target.value);
  };
  const handleMetaKeyWordChange = (e) => {
    setMetaKeyword(e.target.value);
  };
  const handleAltTextChange = (e) => {
    setAltText(e.target.value);
  };
  const handleEditorChange = (content) => {
    setContent(content);
  };

  const handleFileChange = (e) => {
    // if (
    //   e.target.files[0]?.type === "image/png" ||
    //   e.target.files[0]?.type === "image/jpg" ||
    //   e.target.files[0]?.type === "image/jpeg" ||
    //   e.target.files[0]?.type === "image/webp"
    // ) {
    //   setImage(e.target.files[0]);
    //   setIsContentChange(true);
    // } else {
    //   return notifyError("Only png, jpg, jpeg and webp formats are allowed.");
    // }
    const file = e.target.files[0];
    const allowedTypes = ["image/png", "image/jpg", "image/jpeg", "image/webp"];

    if (!file) {
      return;
    }

    if (!allowedTypes.includes(file.type)) {
      notifyError("Only png, jpg, jpeg and webp formats are allowed.");
      return;
    }

    const reader = new FileReader();

    reader.onload = (event) => {
      const image = new Image();

      image.onload = () => {
        const width = image.width;
        const height = image.height;

        if (width < 850 || width > 950) {
          toast.warning("Width should be between 850-950 pixels");
        }

        setImage(file);
        setIsContentChange(true);
      };

      image.src = event.target.result;
    };

    reader.readAsDataURL(file);
  };

  const notify = (message) => {
    toast.success(message, {
      position: "top-right",
      autoClose: 2000,
      hideProgressBar: true,
      closeOnClick: true,
      pauseOnHover: true,
      draggable: true,
      progress: undefined,
    });
  };

  const notifyError = (message) => {
    toast.error(message, {
      position: "top-right",
      autoClose: 10000,
      hideProgressBar: true,
      closeOnClick: true,
      pauseOnHover: true,
      draggable: true,
      progress: undefined,
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // Data validation
    if (title?.trim().length < 2) {
      setErrors({ title: "Title cannot be empty or less than 2 characters." });
      return;
    } else if (title?.trim().length > 60) {
      setErrors({ title: "Title cannot be larger than 60 characters." });
      return;
    }

    if (slug?.trim().length === 0) {
      setErrors({ slug: "Slug cannot be empty" });
      return;
    } else if (slug?.trim().length > 60) {
      setErrors({ slug: "Slug cannot be larger than 60 characters." });
      return;
    }

    if (subTitle?.trim().length < 2) {
      setErrors({
        subTitle: "Sub Title cannot be empty or less than 2 characters.",
      });
      return;
    } else if (subTitle?.trim().length > 255) {
      setErrors({
        subTitle: "Sub title cannot be larger than 255 characters.",
      });
      return;
    }

    if (excerpt?.trim().length > 512) {
      setErrors({ excerpt: "Excerpt cannot be larger than 512 characters" });
      return;
    }

    // Building Form data
    const fd = new FormData();
    if (image) fd.append("imageUrl", image, image.name);
    const tempStr = selectedsidebarAds?.reduce(
      (a, c) => (a = `${a},${c.id}`),
      ""
    );
    fd.append("publisheDate", touched  ||id ?publisheDate:"");
    fd.append("imageUrl", currentImage);
    fd.append("title", title);
    fd.append("content", content);
    fd.append("subTitle", subTitle);
    fd.append("authorId", authorId);
    fd.append("excerpt", excerpt);
    fd.append("slug", slug);
    fd.append("isActive", isActive);
    fd.append(
      "sidebarAds",
      tempStr[0] === "," ? tempStr?.slice(1) : `${tempStr}`
    );
    fd.append("meta_title", metaTitle);
    fd.append("meta_des", metaDescription);
    fd.append("meta_keyword", metaKeyword);
    fd.append("altText", altText);
    fd.append("isScheduled", !!publisheDate);
    fd.append("status", status);
    setIsLoading(true);

    if (!id) {
      axios
        .post(`${baseUrl()}features`, fd, {
          headers: {
            "Content-Type": "multipart/form-data",
          },
        })
        .then((res) => {
          setIsLoading(false);
          setErrors([]);
          if (res.status === 200) {
            navigate("/team-usa");
            notify("Article is created!");
          }
        })
        .catch((err) => {
          setIsLoading(false);
          setErrors([]);
          err?.data?.message
            ? toast.error(err.data.message)
            : toast.error("Something went wrong :(");
        });
    } else {
      axios
        .put(`${baseUrl()}features/${id}`, fd, {
          headers: {
            "Content-Type": "multipart/form-data",
          },
        })
        .then((res) => {
          setIsLoading(false);
          if (res.status === 200) {
            navigate("/team-usa");
            notify("Article is updated!");
          }
        })
        .catch((err) => {
          setIsLoading(false);
          setErrors([]);
          err?.data?.message
            ? toast.error(err.data.message)
            : toast.error("Something went wrong :(");
        });
    }
  };
  const handlePublisheDateChange = (e) => {
    setTouched(true)
    setPublisheDate(e.currentTarget.value);
  };
  const handleSlugChange = (e) => {
    setIsContentChange(true);
    setSlug(e.currentTarget.value);
  };

  const handleSubTitleChange = (e) => {
    setIsContentChange(true);
    setSubTitle(e.currentTarget.value);
  };
  const handleSlug = () => {
    if (!slug?.length) {
      let newSlug = slugify(title);
      setSlug(newSlug);
    }
    return;
  };
  const editorRef = useRef(null);
  const handleTextArea = (e) => {
    setIsContentChange(true);
    setExcerpt(e.target.value);
  };
  const handleChangeSidebarAd = (e) => {
    setSelectedSidebarAds([...e]);
  };
  const handleChangeMainContentShortcode = (e) => {
    const text = e[e.length - 1]?.value;

    navigator.clipboard.writeText(text);
    toast.info("Shortcode Copied to clipboard");
  };
  useEffect(() => {
    if (adsToDisplay?.length > 0) {
      setSelectedSidebarAds(adsToDisplay);
    }
  }, [adsToDisplay?.length]);

  useEffect(() => {
    const contentArray = content?.split("<ta");
  }, [content]);

  const handlePreview = () => {
    const imageUrl = image ? URL.createObjectURL(image) : currentImage;
    const data = {
      title,
      subTitle,
      slug,
      content,
      excerpt,
      authorId,
      isActive,
      publisheDate,
      metaTitle,
      metaDescription,
      metaKeyword,
      altText,
      imageUrl,
    };

    const queryParams = new URLSearchParams(data).toString();

    window.open(`/news-preview?${queryParams}`, "_blank");
  };
  return (
    <div className="row">
      <div className="col-md-12">
        <h1>{id ? "Update Article" : "Create Article"}</h1>
        <form onSubmit={handleSubmit} encType="multipart/form-data">
          <div className="row">
            <div className="col-md-8">
              <Input
                name={"title"}
                label={"Title"}
                type={"text"}
                onBlur={handleSlug}
                value={title}
                onChange={handleInputChange}
                error={errors.title}
              />
              <Input
                name="subTitle"
                label="Sub Title"
                type="text"
                value={subTitle}
                onChange={handleSubTitleChange}
                error={errors.subTitle}
              />
              <Input
                name="slug"
                label="Slug"
                type="text"
                value={slug ?? ""}
                onChange={handleSlugChange}
                error={errors.slug}
              />
              <p style={{ marginBottom: "0.5rem" }}>Content</p>
              <TinyMCE
                editorRef={editorRef}
                value={content}
                callback={handleEditorChange}
              />
              <div>
                <TextArea
                  id="excerpt"
                  rows="3"
                  className="w-100"
                  label="Excerpt"
                  onChange={handleTextArea}
                  value={excerpt}
                  error={errors.excerpt}
                />
              </div>
              <div className="mb-5">
                <h3>SEO Section</h3>
                <Input
                  name="metaTitle"
                  label="Meta Title"
                  type="text"
                  value={metaTitle}
                  onChange={handleMetaTitleChange}
                />
                <TextArea
                  id="metaDescription"
                  rows="3"
                  label="Meta Description"
                  onChange={handleMetaDescriptionChange}
                  value={metaDescription}
                />
                <Input
                  name="metaKeyword"
                  label="Keyword"
                  type="text"
                  value={metaKeyword}
                  onChange={handleMetaKeyWordChange}
                />
              </div>
            </div>
            <div className="col-md-4">
              <div id="accordian" className="aside-accordian">
                <div className="card">
                  <div className="card-header" id="headingOne">
                    <h5 className="mb-o">
                      <a
                        href="/#"
                        className="btn btn-link"
                        data-toggle="collapse"
                        data-target="#collapseOne"
                        aria-expanded="true"
                        aria-controls="collapseOne">
                        Publish
                      </a>
                    </h5>
                  </div>
                  <div
                    id="collapseOne"
                    className="collapse show"
                    aria-labelledby="headingOne"
                    data-parent="#accordion">
                    <div className="card-body">
                      {!isLoading && (
                        <select
                          className="custom-select custom-select-md mb-3"
                          name="isActive"
                          id="isActive"
                          onChange={handleIsActiveChange}
                          value={status}>
                          {!isLoading ? (
                            <>
                              <option value={"published"}>Publish</option>
                              <option value={"draft"}>Draft</option>
                              <option value={"archive"}>Archive</option>
                            </>
                          ) : (
                            <option value={true}>'...'</option>
                          )}
                        </select>
                      )}

                      {user.userRole !== "View Only" && (
                        <button
                          disabled={isLoading}
                          className="btn btn-primary">
                          {isLoading && (
                            <div className="lds-ring">
                              <div></div>
                              <div></div>
                              <div></div>
                              <div></div>
                            </div>
                          )}
                          {id ? "Update" : "Save"}
                        </button>
                      )}
                      <button
                        // disabled={isLoading}
                        type="button"
                        onClick={() => handlePreview()}
                        className="btn btn-primary ml-3">
                        {/* {isLoading && (
                          <div className="lds-ring">
                            <div></div>
                            <div></div>
                            <div></div>
                            <div></div>
                          </div>
                        )} */}
                        Preview
                      </button>
                    </div>
                  </div>
                  {/* <div
                    id="collapseOne"
                    className="collapse show"
                    aria-labelledby="headingOne"
                    data-parent="#accordion">
                    <div className="card-body">
                      {user.userRole !== "View Only" && (
                        <button
                          disabled={isLoading}
                          className="btn btn-primary">
                          {isLoading && (
                            <div className="lds-ring">
                              <div></div>
                              <div></div>
                              <div></div>
                              <div></div>
                            </div>
                          )}
                          {id ? "Update" : "Save"}
                        </button>
                      )}
                    </div>
                  </div> */}
                </div>
              </div>

              <div id="accordian" className="aside-accordian">
                <div className="card">
                  <div className="card-header" id="headingFive">
                    <h5 className="mb-o">
                      <a
                        href="/#"
                        className="btn btn-link"
                        data-toggle="collapse"
                        data-target="#collapseFive"
                        aria-expanded="true"
                        aria-controls="collapseFive">
                        Schedule Team USA
                      </a>
                    </h5>
                  </div>
                  <div
                    id="collapseFive"
                    className="collapse show"
                    aria-labelledby="headingPublishDate"
                    data-parent="#accordion">
                    <div className="card-body">
                      <div className="mb-3">
                      <Input
                       style={{
                        color:
                        publisheDate?"":'lightgray'
                        
                      }}
                          name="publisheDate "
                          type="datetime-local"
                          // label="Schedule Post"
                          min={
                            id || !touched?"":
                            moment(new Date()).tz("America/New_York").format("YYYY-MM-DDTHH:mm")
                                   
                          }
                          value={ !publisheDate ? moment(new Date()).tz("America/New_York").format("YYYY-MM-DDTHH:mm"):publisheDate}

                        
                          onChange={handlePublisheDateChange}
                          // error={errors.venueDateAndTime}
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div id="accordian" className="aside-accordian">
                <div className="card">
                  <div className="card-header" id="headingOne">
                    <h5 className="mb-o">
                      <a
                        href="/#"
                        className="btn btn-link"
                        data-toggle="collapse"
                        data-target="#collapseThree"
                        aria-expanded="true"
                        aria-controls="collapseThree">
                        Advertisments
                      </a>
                    </h5>
                  </div>
                  <div
                    id="collapseThree"
                    className="collapse show"
                    aria-labelledby="headingOne"
                    data-parent="#accordion">
                    <div className="card-body">
                      <div className="adsDropdown mb-3">
                        <p className="my-1">
                          {sidebarAds.length > 0
                            ? "MPU Ads"
                            : "No MPU Ads found for Features."}
                        </p>
                        {sidebarAds?.length > 0 && (
                          <Select
                            isMulti
                            name="colors"
                            options={sidebarAds}
                            defaultValue={adsToDisplay}
                            onChange={handleChangeSidebarAd}
                            className="basic-multi-select"
                            classNamePrefix="select"
                          />
                        )}
                      </div>
                      <div className="adsDropdown">
                        <button
                          type="button"
                          className="btn btn-link pl-0"
                          data-toggle="modal"
                          data-target="#AdsModalList">
                          Open Ads List
                        </button>
                        <div
                          className="modal fade listingModal"
                          id="AdsModalList"
                          tabIndex="-1"
                          role="dialog"
                          aria-labelledby="AdsModalList"
                          aria-hidden="true">
                          <div
                            className="modal-dialog modal-lg"
                            role="document">
                            <div className="modal-content">
                              <div className="modal-header">
                                <h3 className="modal-title" id="AdsModalList">
                                  Features Ads
                                </h3>
                                <button
                                  type="button"
                                  className="close"
                                  data-dismiss="modal"
                                  aria-label="Close">
                                  <span aria-hidden="true">&times;</span>
                                </button>
                              </div>
                              <div className="modal-body">
                                <Tabs>
                                  <TabList>
                                    <Tab>Main Content Ads</Tab>
                                    <Tab>Small Screen MPU Ads</Tab>
                                  </TabList>

                                  <TabPanel>
                                    <table className="table">
                                      <thead>
                                        <tr>
                                          <th scope="col">Name</th>
                                          <th scope="col">Shortcode</th>
                                        </tr>
                                      </thead>
                                      <tbody>
                                        {mainContentAds?.map((ad) => (
                                          <tr key={ad._id}>
                                            <td>{ad.name}</td>
                                            <td>
                                              <CopyToClipboard
                                                text={`~[SC~ ${ad?.shortcode?.id} ~[SC~`}
                                                onCopy={() =>
                                                  toast.info(
                                                    "Shortcode is copied on clipboard."
                                                  )
                                                }>
                                                <button
                                                  title="Click to Copy"
                                                  className="btn border-0 p-1 ml-2"
                                                  type="button"
                                                  data-dismiss="modal">
                                                  {`~[SC~ ${ad?.shortcode?.id} ~[SC~`}
                                                </button>
                                              </CopyToClipboard>
                                            </td>
                                          </tr>
                                        ))}
                                      </tbody>
                                    </table>
                                  </TabPanel>
                                  <TabPanel>
                                    <table className="table">
                                      <thead>
                                        <tr>
                                          <th scope="col">Name</th>
                                          <th scope="col">Shortcode</th>
                                        </tr>
                                      </thead>
                                      <tbody>
                                        {sideBarAds?.map((ad) => (
                                          <tr key={ad._id}>
                                            <td>{ad.name}</td>
                                            <td>
                                              <CopyToClipboard
                                                text={`~[SC~ ${ad?.shortcode?.id} ~[SC~`}
                                                onCopy={() =>
                                                  toast.info(
                                                    "Shortcode is copied on clipboard."
                                                  )
                                                }>
                                                <button
                                                  title="Click to Copy"
                                                  className="btn border-0 p-1 ml-2"
                                                  type="button"
                                                  data-dismiss="modal">
                                                  {`~[SC~ ${ad?.shortcode?.id} ~[SC~`}
                                                </button>
                                              </CopyToClipboard>
                                            </td>
                                          </tr>
                                        ))}
                                      </tbody>
                                    </table>
                                  </TabPanel>
                                </Tabs>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div id="accordian" className="aside-accordian">
                <div className="card">
                  <div className="card-header" id="headingTwo">
                    <h5 className="mb-o">
                      <a
                        href="/#"
                        className="btn btn-link"
                        data-toggle="collapse"
                        data-target="#collapseTwo"
                        aria-expanded="true"
                        aria-controls="collapseTwo">
                        Featured Image
                      </a>
                    </h5>
                  </div>
                  <div
                    id="collapseTwo"
                    className="collapse show"
                    aria-labelledby="headingTwo"
                    data-parent="#accordion">
                    <div className="card-body">
                      <Input
                        name={"image"}
                        label={""}
                        type={"file"}
                        onChange={handleFileChange}
                        accept={"image/png, image/gif, image/jpeg"}
                      />
                      {currentImage && (
                        <img src={currentImage} alt="Featured Image" />
                      )}
                      <Input
                        name="altText"
                        label="Alt Text"
                        type="text"
                        value={altText ?? ""}
                        onChange={handleAltTextChange}
                        error={errors.altText}
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};

export default FeatureForm;
