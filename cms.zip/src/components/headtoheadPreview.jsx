import React from "react";
import { useLocation } from "react-router-dom";
import parse from "html-react-parser";
import TitleTable from "../Pages/Settings/Home/components/HeadToHeadPreview/TitleTable";
function HeadToHeadPreview() {
  const { search } = useLocation();
  const queryParams = new URLSearchParams(search);
  const title = queryParams.get("title");
  const imageUrl = queryParams.get("imageUrl");
  const subTitle = queryParams.get("subTitle");
  
  const content = queryParams.get("content");
  const excerpt = queryParams.get("excerpt");
  const venueLocation = queryParams.get("venueLocation");
  const venueDateAndTime = queryParams.get("venueDateAndTime");

  const headingStyles = `h1, h2, h3, h4, h5, h6 { font-size: 17px; font-weight: 800; }`;
  const paragraphStyles = `p, pre { color: gray; }`;
  const StrongStyles = `strong { color: black; }`;
  const anchorStyles = `a { color: blue; }`;
  const tableHeading = `
  table th {
    background: linear-gradient(90deg, #BA1622 0%, #B71825 9.38%, #AD1D2E 18.75%, #9D273D 26.56%, #863452 34.38%, #69456D 42.71%, #4F5485 52.08%, #435B91 60.42%, #3265A1 70.31%, #266CAC 80.73%, #1F70B2 91.15%, #1D71B4 100%);
    color: #fff;
    font-size: 18px;
    padding: 10px 0;
    text-transform: uppercase;
  }
`;
  return (
    <>
      <div className="">
        <style>
          {headingStyles}
          {paragraphStyles}
          {StrongStyles}
          {tableHeading}
        </style>
        <div className="container main-container d-flex ">
          <div className="mh-100 topDiv d-flex align-items-center justify-content-center ">
            <div
              className="h-full bg-black"
              style={{
                backgroundColor: "black",
                height: "400px",
              }}>
              <div className="row mt-5">
                <div className="">
                  <div>
                    <TitleTable
                      fontSize="60px"
                      fontWeight="900"
                      width="100px"
                      title={title}
                    />
                  </div>
                  {/* <h3
                    className="mt-4 text-uppercase"
                    style={{
                      color: "white",
                      fontSize: "20px",
                      fontWeight: "900",
                    }}>
                    {subTitle}
                  </h3>
                  <h6
                    className="mt-5"
                    style={{
                      color: "white",
                      fontSize: "15px",
                      fontWeight: "800",
                    }}>
                    {excerpt}
                  </h6> */}
                </div>
              </div>
            </div>
            {/* <ul className="list-none">
              <li>
                <h1 className="headFont text-xl lineheight-1 text-bold-lg uppercase text-white p-3">
                  {title?.split(" ")?.[0] ?? ""}
                </h1>
              </li>
              <li>
                <h1 className="headFont text-xl lineheight-1 text-bold-lg uppercase text-white p-3">
                  {title?.split(" ")?.[1] ?? ""}
                </h1>
              </li>
              <li>
                <h1 className="headFont text-xl lineheight-1 text-bold-lg uppercase text-white p-3">
                  {title?.split(" ")?.[2] ?? ""}
                </h1>
              </li>
            </ul> */}
          </div>
          <div className="topDiv">
            <img className="imgWidth" src={imageUrl} alt="news" />
          </div>
        </div>

        <div className="container main-container">
          <div className="row">
            <div className="flex flex-col col-10 mt-4">
              <div className=" max-w-[600px] break-words">
                <h2 className="uppercase text-bold-lg text-lg ">
                  {subTitle || ""}
                </h2>
                <div
                  className="overflow-hidden editorContent mt-4 "
                  style={{ wordBreak: "break-word" }}>
                  {parse(content ?? "")}
                </div>
              </div>
            </div>
            {/* <div className="col-6 mt-4">
              <h2 className="uppercase text-bold-lg text-lg">{subTitle}</h2>
              <div
                className="overflow-hidden editorContent"
                style={{ wordBreak: "break-word" }}>
                {parse(content)}
              </div>
            </div> */}
            {/* <div className="col-3"></div> */}
          </div>
        </div>
      </div>
    </>
  );
}

export default HeadToHeadPreview;
