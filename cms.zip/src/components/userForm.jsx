import React, { useState, useEffect } from "react";
import axios from "axios";
import { useParams, useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import Input from "./common/input";
import { baseUrl } from "./../utils/baseUrl";

const UserForm = ({ user }) => {
  const [errors, setErrors] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [formValues, setFormValues] = useState({
    name: "",
    email: "",
    password: "",
    userRole: "",
  });
  const { id } = useParams();
  const navigate = useNavigate();

  async function getUserById(id) {
    await axios
      .get(`${baseUrl()}users/${id}`)
      .then(async (res) => {
        const obj = { ...res?.data };

        setFormValues({
          name: obj.name,
          userRole: obj?.userRole,
          email: obj?.email,
        });
      })
      .catch((err) => {
        if (err.data.error && err.status === 404) alert(err.data?.error);
        setIsLoading(false);
        setErrors({ API: err.data?.error });
      });
  }

  useEffect(() => {
    if (id) {
      getUserById(id);
    }
  }, [id]);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormValues({
      ...formValues,
      [name]: value,
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // Data validation
    if (formValues?.name?.trim().length < 2) {
      setErrors({ name: "Name cannot be empty or less than 2 characters." });
      return;
    } else if (formValues?.name?.trim().length > 60) {
      setErrors({ title: "Name cannot be larger than 60 characters." });
      return;
    }

    if (!formValues?.userRole) {
      toast.error("Please select user role.");
      return;
    }

    if (formValues?.password?.trim().length > 50) {
      setErrors({
        password: "Password cannot be larger than 50 characters.",
      });
      return;
    }

    let data = {
      ...formValues,
    };

    if (!id) {
      setIsLoading(true);
      axios
        .post(`${baseUrl()}users`, data, {
          headers: {
            "Content-Type": "application/json",
          },
        })
        .then((res) => {
          setIsLoading(false);
          setErrors([]);
          if (res.status === 200) {
            navigate("/users");
          }
          toast.info(
            res.status === 200 ? "User is created!" : "Something went wrong :("
          );
        })
        .catch((res) => {
          if (res.data.message && res.status === 400) {
            setIsLoading(false);
            setErrors([]);
            toast.error(res.data.message);
          }
        });
    } else {
      setIsLoading(true);
      axios
        .put(`${baseUrl()}users/${id}`, data, {
          headers: {
            "Content-Type": "application/json",
          },
        })
        .then((res) => {
          setIsLoading(false);
          setErrors([]);
          if (res.status === 200) {
            navigate("/users");
            toast.info("User is updated!");
            return;
          }
          toast.error(res?.message ?? "Something went wrong :(");
        })
        .catch((res) => {
          if (res.data.message && res.status === 400) {
            setIsLoading(false);
            setErrors([]);
            toast.error(res.data.message);
          }
        });
    }
  };

  return (
    <div className="row">
      <div className="col-md-12">
        <h1>{id ? "Update User" : "Create User"}</h1>
        <form onSubmit={handleSubmit} encType="multipart/form-data">
          <div className="row">
            <div className="col-md-8">
              <Input
                name="name"
                label="Name"
                type="text"
                value={formValues?.name}
                onChange={handleInputChange}
                error={errors.name}
              />
              <Input
                name="email"
                label="Email"
                type="text"
                autoComplete="off"
                value={formValues?.email}
                onChange={handleInputChange}
                
                error={errors.email}
              />
              {id !== user?.id && (
                <div className="form-group">
                  <label htmlFor="inputState">User Role</label>
                  <select
                    name="userRole"
                    value={formValues?.userRole ?? ""}
                    className="form-control"
                    onChange={handleInputChange}
                  >
                    <option disabled value="">
                      Please select user role
                    </option>
                    <option disabled={user.userRole === "Admin"} value="Admin">
                      Admin
                    </option>
                    <option value="Content Admin">Content Admin</option>
                    <option value="View Only">View Only</option>
                  </select>
                </div>
              )}
              <Input
                name="password"
                label="Set New Password"
                type="password"
                autoComplete="new-password"
                value={formValues?.password}
                onChange={handleInputChange}
                error={errors.password}
              />
            </div>
            <div className="col-md-4">
              <div id="accordian" className="aside-accordian">
                <div className="card">
                  <div className="card-header" id="headingOne">
                    <h5 className="mb-o">
                      <a
                        href="/#"
                        className="btn btn-link"
                        data-toggle="collapse"
                        data-target="#collapseOne"
                        aria-expanded="true"
                        aria-controls="collapseOne"
                      >
                        Publish
                      </a>
                    </h5>
                  </div>
                  <div
                    id="collapseOne"
                    className="collapse show"
                    aria-labelledby="headingOne"
                    data-parent="#accordion"
                  >
                    <div className="card-body">
                      <button disabled={isLoading} className="btn btn-primary">
                        {isLoading && (
                          <div className="lds-ring">
                            <div></div>
                            <div></div>
                            <div></div>
                            <div></div>
                          </div>
                        )}
                        {id ? "Update" : "Save"}
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};

export default UserForm;
