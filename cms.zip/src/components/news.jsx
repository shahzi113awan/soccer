import React, { Component } from "react";
import Pagination from "./common/pagination";
import NewsTable from "./newsTable";
import { paginate } from "../utils/paginate";
import _ from "lodash";
import { Link } from "react-router-dom";
import FilterSearchBox from "./common/filterSearchBox";
import axios from "axios";
import { toast } from "react-toastify";
import { baseUrl } from "./../utils/baseUrl";
class News extends Component {
  state = {
    news: [],
    pageSize: 10,
    currentPage: 1,
    sortColumn: { path: "", order: "" },
    searchQuery: "",
    draftFilter: false,
    archiveFilter: false,
    publishedFilter: false,
    featuredFilter: false,
    isLoaded: false,
    error: "",
    pinnedArticle: 0,
    showHideFilters: false,
  };

  async fetchNews() {
    try {
      const res = await axios.get(`${baseUrl()}news`);
      this.setState({ news: res.data, isLoaded: true, error: null });
    } catch (err) {
      this.setState({ error: err.message, isLoaded: true });
    }
  }

  async componentDidMount() {
    await this.fetchNews();
  }

  // async componentDidUpdate() {
  //   await this.fetchNews();
  // }
  // async componentDidMount() {
  //   await axios
  //     .get(`${baseUrl()}news`)
  //     .then((res) => {
  //       this.setState({ news: res.data, isLoaded: true });
  //     })
  //     .catch((err) => {
  //       this.setState({ error: err.message, isLoaded: true });
  //     });
  // }

  handleDelete = async (news) => {
    if (window.confirm("Are you sure you want to delete this?")) {
      const newsCurrentState = [...this.state.news];
      const _news = this.state.news.filter((n) => n._id !== news._id);
      this.setState({ news: _news });

      const deletedNews = await axios
        .delete(`${baseUrl()}news/${news._id}`)
        .catch((err) => {
          this.setState({ error: err.message });
        });

      if (deletedNews) {
        this.notify();
      } else {
        this.setState({ news: newsCurrentState });
      }
    }
  };

  handlePinArticle = async (news) => {
    if (news.status === "published" && !news.isScheduled) {
      const currentPinned = this.state.pinnedArticle;
      const updatedArticle = {
     
        pinned: currentPinned ? 0 : 1,
        authorId: news.authorId?._id,
       
      };

      try {
        const response = await axios.put(
          `${baseUrl()}news/${news.slug}`,
          updatedArticle
        ).then(()=>{
          this.fetchNews();

        });

        this.setState({ pinnedArticle: updatedArticle.pinned }, () => {
          this.pinNewsUpdated(
            `Article ${
              updatedArticle.pinned ? "pinned" : "unpinned"
            } successfully`
          );
        });
      } catch (error) {
        this.setState({ pinnedArticle: currentPinned }, () => {
          this.pinNewsUpdated("Failed to update the article");
        });
      }
    } else {
      toast.error("Article is not published yet");
    }
  };

  handlePageChange = (page) => {
    this.setState({ currentPage: page });
  };

  handleSearch = (query) => {
    this.setState({ searchQuery: query, currentPage: 1 });
  };
  handleDraftFilter = () => {
    this.setState({ draftFilter: !this.state.draftFilter });
  };

  handleArchiveFilter = () => {
    this.setState({ archiveFilter: !this.state.archiveFilter });
  };

  handlePublishedFilter = () => {
    this.setState({ publishedFilter: !this.state.publishedFilter });
  };
  handleFeaturedFilter = () => {
    this.setState({ featuredFilter: !this.state.featuredFilter });
  };
  handleSort = (sortColumn) => {
    this.setState({ sortColumn });
  };

  notify = () => {
    toast.error("News is deleted!");
  };
  pinNewsUpdated = () => {
    toast.success("News is Updated!");
  };

  handleFilters = () => {
    this.setState({ showHideFilters: !this.state.showHideFilters });
  };
  getPagedData = () => {
    const {
      pageSize,
      currentPage,
      sortColumn,
      news,
      searchQuery,
      draftFilter,
      archiveFilter,
      publishedFilter,
      featuredFilter,
    } = this.state;

    let filtered = news;

    if (searchQuery) {
      filtered = news.filter((n) =>
        n.title.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }
    if (draftFilter) {
      filtered = news.filter((post) => post.status === "draft");
    }
    if (publishedFilter) {
      filtered = news.filter((post) => post.status === "published");
    }
    if (archiveFilter) {
      filtered = news.filter((post) => post.status === "archive");
    }

    if (featuredFilter) {
      filtered = news.filter((post) => post.isFeatured);
    }

    const sorted = _.orderBy(filtered, [sortColumn.path], [sortColumn.order]);

    const _news = paginate(sorted, currentPage, pageSize);

    return { totalCount: filtered.length, data: _news };
  };

  render() {
    const {
      pageSize,
      currentPage,
      sortColumn,
      searchQuery,
      draftFilter,
      archiveFilter,
      publishedFilter,
      featuredFilter,
      showHideFilters,
    } = this.state;

    if (!this.state.isLoaded && !this.state.error)
      return (
        <div className="lds-ellipsis">
          <div></div>
          <div></div>
          <div></div>
          <div></div>
        </div>
      );

    if (this.state.error) return <p>{this.state.error}</p>;

    if (
      this.state.news.length === 0 &&
      this.props.user.userRole?.includes("Admin")
    ) {
      return (
        <>
          <p>There are no news to show.</p>
          <Link
            className="btn btn-primary"
            to="/create-news"
            style={{ marginBottom: 10, height: "max-content" }}>
            Create New
          </Link>
        </>
      );
    }

    const { totalCount, data: news } = this.getPagedData();

    return (
      <div className="row">
        <div className="col">
          <div className="d-flex justify-content-between align-items-end gap-8">
            <div className="flex-1">
              {this.props.user.userRole?.includes("Admin") && (
                <Link
                  className="btn btn-primary"
                  to="/create-news"
                  style={{ marginBottom: 10, height: "max-content" }}>
                  Create New
                </Link>
              )}
              <p>Showing {totalCount} records from the database.</p>
            </div>
            <div className="d-inline-flex">
              <FilterSearchBox
                value={searchQuery}
                onChange={this.handleSearch}
                placeholder="Search..."
              />
              <button
                className="d-flex btn btn-primary flex mb-2 ml-2"
                onClick={this.handleFilters}>
                Filters
              </button>
            </div>
          </div>
          <div className="d-flex justify-content-between align-items-end gap-8">
            <div></div>
            {showHideFilters && (
              <div className="custom-checkbox mt-2 d-inline-flex ">
                <label className="custom-checkbox mr-1 ml-1">
                  
                  <input
                    className="mr-1 "
                    type="checkbox"
                    checked={draftFilter}
                    onChange={this.handleDraftFilter}
                  />
                  Draft
                </label>
                <label className="custom-checkbox mr-1 ml-1">
                  <input
                    className="mr-1 ml-1"
                    type="checkbox"
                    checked={archiveFilter}
                    onChange={this.handleArchiveFilter}
                  />
                  Archive
                </label>
                <label className="custom-checkbox mr-1 ml-1">
                  <input
                    className="mr-1 ml-1"
                    type="checkbox"
                    checked={publishedFilter}
                    onChange={this.handlePublishedFilter}
                  />
                  Published
                </label>
                <label className="custom-checkbox mr-1 ml-1">
                  <input
                    className="mr-1 ml-1"
                    type="checkbox"
                    checked={featuredFilter}
                    onChange={this.handleFeaturedFilter}
                  />
                  Featured
                </label>
              </div>
            )}
          </div>
          <NewsTable
            news={news}
            sortColumn={sortColumn}
            onSort={this.handleSort}
            onDelete={this.handleDelete}
            user={this.props.user}
            onHandlePin={this.handlePinArticle}
          />
          <Pagination
            itemsCount={totalCount}
            pageSize={pageSize}
            currentPage={currentPage}
            onPageChange={this.handlePageChange}
          />
        </div>
      </div>
    );
  }
}

export default News;
