import React, { Component } from "react";
import Table from "./common/table";

class SubscriberTable extends Component {
  columns = [
    { path: "name", label: "Name" },
    { path: "email", label: "Email" },
    { path: "favoriteTeam", label: "Favorite Team" },
    { path: "favClubTeam", label: "Favorite Club Team" },
    
  ];

  render() {
    const { subscribers, onSort, sortColumn } = this.props;
    return (
      <Table
        columns={this.columns}
        sortColumn={sortColumn}
        data={subscribers}
        onSort={onSort}
      />
    );
  }
}

export default SubscriberTable;
