import React, { Component } from "react";
import Pagination from "./common/pagination";
import { paginate } from "../utils/paginate";
import _ from "lodash";
import axios from "axios";
import { baseUrl } from "./../utils/baseUrl";
import SubscriberTable from "./subscriberTable";
import { CSVLink } from "react-csv";

class Subscribers extends Component {
  
  state = {
    subscribers: [],
    pageSize: 20,
    currentPage: 1,
    sortColumn: { path: "", order: "" },
    isLoaded: false,
    error: "",
  };

  async componentDidMount() {
    await axios
      .get(`${baseUrl()}subscribers`)
      .then((res) => {
        this.setState({ subscribers: res.data, isLoaded: true });
      })
      .catch((err) => {
        this.setState({ error: err.message, isLoaded: true });
      });
  }

  handlePageChange = (page) => {
    this.setState({ currentPage: page });
  };

  handleSort = (sortColumn) => {
    this.setState({ sortColumn });
  };

  getPagedData = () => {
    const { pageSize, currentPage, sortColumn, subscribers, searchQuery } =
      this.state;

    let filtered = subscribers;

    if (searchQuery) {
      filtered = subscribers.filter((n) =>
        n.name.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }

    const sorted = _.orderBy(filtered, [sortColumn.path], [sortColumn.order]);

    const _subscribers = paginate(sorted, currentPage, pageSize);

    return { totalCount: filtered.length, data: _subscribers };
  };

  render() {
    const { pageSize, currentPage, sortColumn } = this.state;

    if (!this.state.isLoaded && !this.state.error)
      return (
        <div className="lds-ellipsis">
          <div></div>
          <div></div>
          <div></div>
          <div></div>
        </div>
      );

    if (this.state.error) return <p>{this.state.error}</p>;

    if (this.state.subscribers.length === 0) {
      return (
        <>
          <p>There are no subscriber to show.</p>
        </>
      );
    }

    const { totalCount, data: subscribers } = this.getPagedData();

    return (
      <div className="row">
        <div className="col">
          <div className="d-flex justify-content-between align-items-end gap-8">
            <div className="flex-1">
              <CSVLink
                className="btn btn-primary"
                style={{ marginBottom: 10, height: "max-content" }}
                data={this.state.subscribers}
                filename={"subscribers.csv"}
              >
                Export To CSV
              </CSVLink>
              <p>Showing {totalCount} subscribers from the database.</p>
            </div>
          </div>
          <SubscriberTable
            subscribers={subscribers}
            sortColumn={sortColumn}
            onSort={this.handleSort}
            onDelete={this.handleDelete}
            user={this.props.user}
          />
          <Pagination
            itemsCount={totalCount}
            pageSize={pageSize}
            currentPage={currentPage}
            onPageChange={this.handlePageChange}
          />
        </div>
      </div>
    );
  }
}

export default Subscribers;
