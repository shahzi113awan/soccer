import React from "react";

const Dashboard = ({ user }) => {
  return (
    <div className="jumbotron">
      <h1 className="display-4">Soccerbx Dashboard</h1>
      
      <p className="lead">
        Lorem ipsum dolor sit, amet consectetur adipisicing elit. Libero neque
        ad possimus recusandae ipsam, ea fugit quibusdam necessitatibus placeat
        inventore, illum molestias obcaecati nisi pariatur quis, dicta vitae
        dolorem ex?
      </p>
      <a className="btn btn-primary btn-lg" href="#" role="button">
        Learn more
      </a>
    </div>
  );
};

export default Dashboard;
