import React, { Component } from "react";
import Table from "./common/table";

class FeatureTable extends Component {
  columns = [
    {
      path: "isScheduled",
      scheduleColumn: true,
    },
    
    {
      path: "title",
      label: "Title",
      linkedColumn: true,
    },
    { path: "author.name", label: "Author" },
    { path: "createdAt", label: "Created At", createdAtColumn: true },
    // { path: "lastUpdate", label: "Last Update", lastUpdateColumn: true },
    { path: "updatedAt", label: "Last Update", lastUpdateColumn: true },

    // {
    //   path: "isActive",
    //   label: "Status",
    //   statusColumn: true,
    // },
    {
      path: "status",
      label: "Status",
      statusColumnB: true,
    },

    {
      label: "Pin",
      key: "Pin",
      content: (features) => (
        <button
          className={`btn btn-small  mr-2 ${
            features.pinned ? "btn-primary" : ""
          }`}
          onClick={() =>
            this.props.onHandlePin(features, features.pinned ? 0 : 1)
          }>
          <i className="fa fa-thumb-tack" aria-hidden="true"></i>
        </button>
      ),
    },

    {
      label: "Delete",
      key: "Delete",
      content: (previews) =>
        this.props.user.userRole?.includes("Admin") && (
          <button
            className="btn btn-small btn-danger"
            onClick={() => this.props.onDelete(previews)}>
            <i className="fa fa-trash" aria-hidden="true"></i>
          </button>
        ),
    },
  ];

  render() {
    const { features, onSort, sortColumn } = this.props;
    return (
      <Table
        columns={this.columns}
        sortColumn={sortColumn}
        data={features}
        onSort={onSort}
        baseRoute={"/team-usa"}
        linkedColumnPath={"title"}
        createdAtColumn={"createdAt"}
        lastUpdateColumn={"updatedAt"}
        statusColumn={"status"}
        scheduleColumn={"isScheduled"}
        pinColumn={"pinned"}
      />
    );
  }
}

export default FeatureTable;
