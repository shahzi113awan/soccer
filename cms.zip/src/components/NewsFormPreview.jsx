import React from "react";
import { useLocation } from "react-router-dom";
import parse from "html-react-parser";
function NewsPreview() {
  const { search } = useLocation();
  const queryParams = new URLSearchParams(search);
  const title = queryParams.get("title");
  const imageUrl = queryParams.get("imageUrl");
  const subTitle = queryParams.get("subTitle");
  const content = queryParams.get("content");

  const headingStyles = `h1, h2, h3, h4, h5, h6 { font-size: 17px; font-weight: 800; }`;
  const paragraphStyles = `p, pre { color: gray; }`;
  const StrongStyles = `strong { color: black; }`;
  const anchorStyles = `a { color: blue; }`;

  return (
    <>
      <div className="">
        <style>
          {headingStyles}
          {paragraphStyles}
          {StrongStyles}
          {anchorStyles}
        </style>
        <div className=" d-flex ">
          <div className="mh-100 topDiv d-flex align-items-center justify-content-center ">
            <ul className="list-none">
              <li>
                <h1 className="headFont text-xl lineheight-1 text-bold-lg uppercase text-white p-3">
                  {title?.split(" ")?.[0] ?? ""}
                </h1>
              </li>
              <li>
                <h1 className="headFont text-xl lineheight-1 text-bold-lg uppercase text-white p-3">
                  {title?.split(" ")?.[1] ?? ""}
                </h1>
              </li>
              <li>
                <h1 className="headFont text-xl lineheight-1 text-bold-lg uppercase text-white p-3">
                  {title?.split(" ")?.[2] ?? ""}
                </h1>
              </li>
            </ul>
          </div>
          <div className="topDiv">
            <img className="imgWidth" src={imageUrl} alt="news" />
          </div>
        </div>

        <div className="container">
          <div className="row">
            <div className="col-3">
              <p className="mt-3 text-md ">Photo Credit</p>
            </div>

            <div className="flex flex-col col-6 mt-4">
              <div className=" max-w-[600px] break-words">
                <h2 className="uppercase text-bold-lg text-lg ">
                  {subTitle || ""}
                </h2>
                <div
                  className="overflow-hidden editorContent mt-4 "
                  style={{ wordBreak: "break-word" }}>
                  {parse(content ?? "")}
                </div>
              </div>
            </div>
            {/* <div className="col-6 mt-4">
              <h2 className="uppercase text-bold-lg text-lg">{subTitle}</h2>
              <div
                className="overflow-hidden editorContent"
                style={{ wordBreak: "break-word" }}>
                {parse(content)}
              </div>
            </div> */}
            
            <div className="col-3"></div>
          </div>
        </div>
      </div>
    </>
  );
}

export default NewsPreview;
