import React, { Component } from "react";
import Table from "./common/table";

class PodsTable extends Component {
  columns = [
    {
      path: "isScheduled",
      scheduleColumn: true,
      
    },
    {
      path: "_id",
      label: "Name",
      linkedColumn: true,
      linkedColumnPath: "_id",
    },
    { path: "author.name", label: "Author" },
    { path: "createdAt", label: "Created At", createdAtColumn: true },
    { path: "updatedAt", label: "Last Update", lastUpdateColumn: true },

    // {
    //   path: "status",
    //   label: "Status",
    //   statusColumn: true,
    // },
    {
      path: "status",
      label: "Status",
      statusColumnB: true,
    },

    // {
    //   key: "Pin",
    //   content: (pods) => (
    //     <button
    //       className={`btn btn-small  mr-2 ${pods.pinned ? "btn-primary" : ""}`}
    //       onClick={() => this.props.onHandlePin(pods, pods.pinned ? 0 : 1)}>
    //       <i className="fa fa-thumb-tack" aria-hidden="true"></i>
    //     </button>
    //   ),
    // },

    {
      label: "Delete",
      key: "Delete",
      content: (pods) =>
        this.props.user.userRole?.includes("Admin") && (
          <button
            className="btn btn-small btn-danger ml-3"
            onClick={() => this.props.onDelete(pods)}>
            <i className="fa fa-trash" aria-hidden="true"></i>
          </button>
        ),
    },
  ];

  render() {
    const { pods, onSort, sortColumn } = this.props;
    return (
      <Table
        columns={this.columns}
        sortColumn={sortColumn}
        data={pods}
        onSort={onSort}
        baseRoute={"/soccerpods"}
        linkedColumnPath={"title"}
        createdAtColumn={"createdAt"}
        lastUpdateColumn={"updatedAt"}
        statusColumn={"status"}
        statusColumnB={""}
        featureColumn={"isFeatured"}
        pinColumn={"pinned"}
        scheduleColumn={"isScheduled"}
      />
    );
  }
}

export default PodsTable;
