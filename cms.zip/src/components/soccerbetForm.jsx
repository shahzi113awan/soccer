import React, { useState, useEffect } from "react";
import Input from "./common/input";
import TinyMCE from "./common/tinymce";
import axios from "axios";
import { useParams } from "react-router-dom";
import { useRef } from "react";
import { toast } from "react-toastify";
import { baseUrl } from "./../utils/baseUrl";

const Soccerbet = ({ user }) => {
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const [image, setImage] = useState("");
  const [currentImage, setCurrentImage] = useState("");
  const [errors, setErrors] = useState("");
  const [authorId] = useState(user.id);
  const [subTitle, setSubTitle] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [pageExits, setPageExists] = useState(false);

  let { id } = useParams();
  async function getPageById(id) {
    await axios
      .get(`${baseUrl()}page/${id}`)
      .then(async (res) => {
        const { title, content, subTitle, featuredImage } = res.data;
        setTitle(title);
        setContent(content);
        setSubTitle(subTitle);
        setCurrentImage(featuredImage);
        setPageExists(true);
      })
      .catch((err) => {
        setErrors({ API: err.data?.error ?? "Something went wrong :(" });
        setPageExists(false);
      });
  }

  useEffect(() => {
    if (id) getPageById(id);
  }, [id]);

  const handleInputChange = (e) => {
    const { value } = e.target;
    setTitle(value);
  };

  const handleEditorChange = (content) => {
    setContent(content);
  };

  const handleFileChange = (e) => {
    if (
      e.target.files[0]?.type === "image/png" ||
      e.target.files[0]?.type === "image/jpg" ||
      e.target.files[0]?.type === "image/jpeg" ||
      e.target.files[0]?.type === "image/webp"
    ) {
      setImage(e.target.files[0]);
    } else {
      return notifyError("Only png, jpg, jpeg and webp formats are allowed.");
    }
  };

  const notify = (message) => {
    toast.success(message, {
      position: "top-right",
      autoClose: 2000,
      hideProgressBar: true,
      closeOnClick: true,
      pauseOnHover: true,
      draggable: true,
      progress: undefined,
    });
  };

  const notifyError = (message) => {
    toast.error(message, {
      position: "top-right",
      autoClose: 10000,
      hideProgressBar: true,
      closeOnClick: true,
      pauseOnHover: true,
      draggable: true,
      progress: undefined,
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // Data validation
    if (title?.trim().length < 2) {
      setErrors({ title: "Title cannot be empty or less than 2 characters." });
      return;
    } else if (title?.trim().length > 60) {
      setErrors({ title: "Title cannot be larger than 60 characters." });
      return;
    }

    if (subTitle?.trim().length < 2) {
      setErrors({
        subTitle: "Sub Title cannot be empty or less than 2 characters.",
      });
      return;
    } else if (subTitle?.trim().length > 255) {
      setErrors({
        subTitle: "Sub title cannot be larger than 255 characters.",
      });
      return;
    }

    // Building Form data
    const fd = new FormData();
    if (image) fd.append("image", image, image.name);
    fd.append("image", currentImage);
    fd.append("title", title);
    fd.append("content", content);
    fd.append("subTitle", subTitle);
    fd.append("authorId", authorId);
    fd.append("slug", "soccerbet");

    setIsLoading(true);

    if (!pageExits) {
      axios
        .post(`${baseUrl()}page`, fd, {
          headers: {
            "Content-Type": "multipart/form-data",
          },
        })
        .then((res) => {
          setIsLoading(false);
          setErrors([]);
          if (res.status === 200) {
            notify("Page is created!");
          }
        })
        .catch((err) => {
          setIsLoading(false);
          setErrors([]);
          err?.data?.message
            ? toast.error(err.data.message)
            : toast.error("Something went wrong :(");
        });
    } else {
      axios
        .put(`${baseUrl()}page/${id}`, fd, {
          headers: {
            "Content-Type": "multipart/form-data",
          },
        })
        .then((res) => {
          setIsLoading(false);
          setErrors([]);
          if (res.status === 200) {
            notify("Page is updated!");
            return;
          }
        })
        .catch((err) => {
          setIsLoading(false);
          setErrors([]);
          err?.data?.message
            ? toast.error(err.data.message)
            : toast.error("Something went wrong :(");
        });
    }
  };
  const handleSubTitleChange = (e) => {
    setSubTitle(e.currentTarget.value);
  };
  const editorRef = useRef(null);

  return (
    <div className="row">
      <div className="col-md-12">
        <h1>Soccerbet Page</h1>
        <form onSubmit={handleSubmit} encType="multipart/form-data">
          <div className="row">
            <div className="col-md-8">
              
              <Input
                name={"title"}
                label={"Title"}
                type={"text"}
                value={title}
                onChange={handleInputChange}
                error={errors.title}
              />
              <Input
                name="subTitle"
                label="Sub Title"
                type="text"
                value={subTitle}
                onChange={handleSubTitleChange}
                error={errors.subTitle}
              />
              <p style={{ marginBottom: "0.5rem" }}>Content</p>
              <TinyMCE
                editorRef={editorRef}
                value={content}
                callback={handleEditorChange}
              />
            </div>
            <div className="col-md-4">
              <div id="accordian" className="aside-accordian">
                <div className="card">
                  <div className="card-header" id="headingOne">
                    <h5 className="mb-o">
                      <a
                        href="/#"
                        className="btn btn-link"
                        data-toggle="collapse"
                        data-target="#collapseOne"
                        aria-expanded="true"
                        aria-controls="collapseOne"
                      >
                        Publish
                      </a>
                    </h5>
                  </div>
                  <div
                    id="collapseOne"
                    className="collapse show"
                    aria-labelledby="headingOne"
                    data-parent="#accordion"
                  >
                    <div className="card-body">
                      {user.userRole !== "View Only" && (
                        <button
                          disabled={isLoading}
                          className="btn btn-primary"
                        >
                          {isLoading && (
                            <div className="lds-ring">
                              <div></div>
                              <div></div>
                              <div></div>
                              <div></div>
                            </div>
                          )}
                          {id ? "Update" : "Save"}
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              </div>
              <div id="accordian" className="aside-accordian">
                <div className="card">
                  <div className="card-header" id="headingTwo">
                    <h5 className="mb-o">
                      <a
                        href="/#"
                        className="btn btn-link"
                        data-toggle="collapse"
                        data-target="#collapseTwo"
                        aria-expanded="true"
                        aria-controls="collapseTwo"
                      >
                        Featured Image
                      </a>
                    </h5>
                  </div>
                  <div
                    id="collapseTwo"
                    className="collapse show"
                    aria-labelledby="headingTwo"
                    data-parent="#accordion"
                  >
                    <div className="card-body">
                      <Input
                        name={"image"}
                        label={""}
                        type={"file"}
                        onChange={handleFileChange}
                        accept={"image/png, image/gif, image/jpeg"}
                      />
                      <img src={currentImage} alt="" />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};

export default Soccerbet;
