import React, { Component } from "react";
import Table from "./common/table";
import { withRouter } from "./common/withRouter";
class MatchesTable extends Component {
  columns = [
    {
      path: "title._id",
      label: "Title",
      linkedColumn: true,
    },
    
    { path: "author.name", label: "Author" },
    { path: "createdAt", label: "Created At", createdAtColumn: true },
    { path: "updatedAt", label: "Last Update", lastUpdateColumn: true },
    // {
    //   path: "isActive",
    //   label: "Status",
    //   statusColumn: true,
    // },
    {
      path: "status",
      label: "Status",
      statusColumnB: true,
    },
    {
      label: "Delete",
      key: "Delete",
      content: (previews) =>
        this.props.user.userRole?.includes("Admin") && (
          <button
            className=" btn btn-small btn-danger"
            onClick={() => this.props.onDelete(previews)}>
            <i className="fa fa-trash" aria-hidden="true"></i>
          </button>
        ),
    },
  ];

  render() {
    const { previews, onSort, sortColumn } = this.props;
    const { slug } = this.props.params;
    return (
      <Table
        columns={this.columns}
        sortColumn={sortColumn}
        data={previews}
        onSort={onSort}
        baseRoute={`/league/${slug}/head-to-head`}
        linkedColumnPath={"title"}
        createdAtColumn={"createdAt"}
        lastUpdateColumn={"updatedAt"}
        statusColumn={"status"}
      />
    );
  }
}

export default withRouter(MatchesTable);
