import React, { Component } from "react";
import Pagination from "./common/pagination";
import FeatureTable from "./featureTable";
import { paginate } from "../utils/paginate";
import _ from "lodash";
import { Link } from "react-router-dom";
import FilterSearchBox from "./common/filterSearchBox";
import axios from "axios";
import { toast } from "react-toastify";
import { baseUrl } from "./../utils/baseUrl";

class Features extends Component {
  state = {
    features: [],
    pageSize: 10,
    currentPage: 1,
    sortColumn: { path: "", order: "" },
    searchQuery: "",
    draftFilter: false,
    archiveFilter: false,
    publishedFilter: false,
    showHideFilters: false,
    isLoaded: false,
    error: "",
  };

  async fetchFeatureNews() {
    try {
      const res = await axios.get(`${baseUrl()}features`);
      this.setState({ features: res.data, isLoaded: true });
    } catch (err) {
      this.setState({ error: err.message, isLoaded: true });
    }
  }

  async componentDidMount() {
    await this.fetchFeatureNews();
  }
  handlePinArticle = async (features) => {
    if (features.status === "published" && !features.isScheduled) {
      const currentPinned = this.state.pinnedArticle;
      const updatedArticle = {
        ...features,
        pinned: currentPinned ? 0 : 1,
      };

      try {
        const response = await axios.put(
          `${baseUrl()}features/${features.slug}`,
          updatedArticle
        );
        this.setState({ pinnedArticle: updatedArticle.pinned }, () => {
          this.pinFeatureUpdated(
            `Article ${
              updatedArticle.pinned ? "pinned" : "unpinned"
            } successfully`
          );
        });
        this.fetchFeatureNews();
      } catch (error) {
        this.setState({ pinnedArticle: currentPinned }, () => {
          this.pinFeatureUpdated("Failed to update the article");
        });
      }
    } else {
      toast.error("Article is not published yet!");
    }
  };
  handleDelete = async (features) => {
    if (window.confirm("Are you sure you want to delete this?")) {
      const featuresCurrentState = [...this.state.features];
      const _features = this.state.features.filter(
        (n) => n._id !== features._id
      );
      this.setState({ features: _features });

      const deletedFeatures = await axios
        .delete(`${baseUrl()}features/${features._id}`)
        .catch((err) => {
          this.setState({ error: err.message });
        });

      if (deletedFeatures) {
        this.notify();
      } else {
        this.setState({ features: featuresCurrentState });
      }
    }
  };

  handlePageChange = (page) => {
    this.setState({ currentPage: page });
  };

  handleSearch = (query) => {
    this.setState({ searchQuery: query, currentPage: 1 });
  };

  handleDraftFilter = () => {
    this.setState({ draftFilter: !this.state.draftFilter });
  };

  handleArchiveFilter = () => {
    this.setState({ archiveFilter: !this.state.archiveFilter });
  };

  handlePublishedFilter = () => {
    this.setState({ publishedFilter: !this.state.publishedFilter });
  };

  handleSort = (sortColumn) => {
    this.setState({ sortColumn });
  };

  notify = () => {
    toast.error("Article is deleted!");
  };
  pinFeatureUpdated = () => {
    toast.success("Team USA News is Updated!");
  };
  getPagedData = () => {
    const {
      pageSize,
      currentPage,
      sortColumn,
      features,
      searchQuery,
      draftFilter,
      archiveFilter,
      publishedFilter,
    } = this.state;

    let filtered = features;

    if (searchQuery) {
      filtered = features.filter((n) =>
        n.title.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }
    if (draftFilter) {
      filtered = features.filter((post) => post.status === "draft");
    }
    if (publishedFilter) {
      filtered = features.filter((post) => post.status === "published");
    }

    if (archiveFilter) {
      filtered = features.filter((post) => post.status === "archive");
    }

    const sorted = _.orderBy(filtered, [sortColumn.path], [sortColumn.order]);

    const _features = paginate(sorted, currentPage, pageSize);

    return { totalCount: filtered.length, data: _features };
  };
  handleFilters = () => {
    this.setState({ showHideFilters: !this.state.showHideFilters });
  };

  render() {
    const {
      pageSize,
      currentPage,
      sortColumn,
      searchQuery,
      draftFilter,
      archiveFilter,
      publishedFilter,
      showHideFilters,
    } = this.state;

    if (!this.state.isLoaded && !this.state.error)
      return (
        <div className="lds-ellipsis">
          <div></div>
          <div></div>
          <div></div>
          <div></div>
        </div>
      );

    if (this.state.error) return <p>{this.state.error}</p>;

    if (this.state.features.length === 0) {
      return (
        <>
          <p>There are no features to show.</p>
          {this.props.user.userRole?.includes("Admin") && (
            <Link
              className="btn btn-primary"
              to="/create-team-usa"
              style={{ marginBottom: 10, height: "max-content" }}>
              Create New
            </Link>
          )}
        </>
      );
    }

    const { totalCount, data: features } = this.getPagedData();

    return (
      <div className="row">
        <div className="col">
          <div className="d-flex justify-content-between align-items-end gap-8">
            <div className="flex-1">
              {this.props.user.userRole?.includes("Admin") && (
                <Link
                  className="btn btn-primary"
                  to="/create-team-usa"
                  style={{ marginBottom: 10, height: "max-content" }}>
                  Create New
                </Link>
              )}
              <p>Showing {totalCount} records from the database.</p>
            </div>
            {/* <div className="d-inline-flex">
              <label className="mt-1 mr-2" htmlFor="filters">
                Filters:
              </label>
              <select
                className="form-control filter-search-control"
                id="filters"
                onChange={this.handleFilterChange}>
                <option
                  value="published"
                  selected={publishedFilter}
                  onClick={this.handlePublishedFilter}>
                  All
                </option>
                <option
                  value="published"
                  selected={publishedFilter}
                  onClick={this.handlePublishedFilter}>
                  Published
                </option>
                <option
                  value="draft"
                  selected={draftFilter}
                  onClick={this.handleDraftFilter}>
                  
                  Draft
                </option>
                <option
                  value="archive"
                  selected={archiveFilter}
                  onClick={this.handleArchiveFilter}>
                  Archive
                </option>
              </select>
            </div> */}
            <div className="d-inline-flex">
              <FilterSearchBox
                value={searchQuery}
                onChange={this.handleSearch}
                placeholder="Search..."
              />
              <button
                className="d-flex btn btn-primary flex mb-2 ml-2"
                onClick={this.handleFilters}>
                Filters
              </button>
            </div>
          </div>

          <div className="d-flex justify-content-between align-items-end gap-8">
            <div></div>

            {showHideFilters && (
              <div className="custom-checkbox mt-2 d-inline-flex ">
                <label className="custom-checkbox mr-1 ml-1">
                  <input
                    className="mr-1 "
                    type="checkbox"
                    checked={draftFilter}
                    onChange={this.handleDraftFilter}
                  />
                  Draft
                </label>
                <label className="custom-checkbox mr-1 ml-1">
                  <input
                    className="mr-1 ml-1"
                    type="checkbox"
                    checked={archiveFilter}
                    onChange={this.handleArchiveFilter}
                  />
                  Archive
                </label>
                <label className="custom-checkbox mr-1 ml-1">
                  <input
                    className="mr-1 ml-1"
                    type="checkbox"
                    checked={publishedFilter}
                    onChange={this.handlePublishedFilter}
                  />
                  Published
                </label>
              </div>
            )}
          </div>
          <FeatureTable
            features={features}
            sortColumn={sortColumn}
            onSort={this.handleSort}
            onDelete={this.handleDelete}
            user={this.props.user}
            onHandlePin={this.handlePinArticle}
          />
          <Pagination
            itemsCount={totalCount}
            pageSize={pageSize}
            currentPage={currentPage}
            onPageChange={this.handlePageChange}
          />
        </div>
      </div>
    );
  }
}

export default Features;
