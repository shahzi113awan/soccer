import React, { Component } from "react";
import Pagination from "./common/pagination";
import PodsTable from "./PodsTable";
import { paginate } from "../utils/paginate";
import _ from "lodash";
import { Link } from "react-router-dom";
import SearchBox from "./common/searchBox";
import axios from "axios";
import { toast } from "react-toastify";
import { baseUrl } from "./../utils/baseUrl";
import FilterSearchBox from "./common/filterSearchBox";
import Input from "./common/input";

class SoccerPods extends Component {
  state = {
    pods: [],
    pageSize: 10,
    currentPage: 1,
    sortColumn: { path: "", order: "" },
    searchQuery: "",
    draftFilter: false,
    archiveFilter: false,
    publishedFilter: false,
    showHideFilters: false,
    isLoaded: false,
    error: "",
    pinnedArticle: 0,
  };

  async fetchPods() {
    try {
      const res = await axios.get(`${baseUrl()}pods`);

      this.setState({ pods: res.data, isLoaded: true, error: null });
    } catch (err) {
      this.setState({ error: err.message, isLoaded: true });
    }
  }

  async componentDidMount() {
    await this.fetchPods();
  }

  // async componentDidUpdate() {
  //   await this.fetchPods();
  // }
  // async componentDidMount() {
  //   await axios
  //     .get(`${baseUrl()}pods`)
  //     .then((res) => {
  //       this.setState({ pods: res.data, isLoaded: true });
  //     })
  //     .catch((err) => {
  //       this.setState({ error: err.message, isLoaded: true });
  //     });
  // }

  handleDelete = async (pod) => {
    if (window.confirm("Are you sure you want to delete this?")) {
      const podCurrentState = [...this.state.pods];
      const _pods = this.state.pods.filter((n) => n._id !== pod._id);
      this.setState({ pods: _pods });

      const deletePod = await axios
        .delete(`${baseUrl()}pods/${pod._id}`)
        .catch((err) => {
          this.setState({ error: err.message });
        });

      if (deletePod) {
        this.notify();
      } else {
        this.setState({ pods: podCurrentState });
      }
    }
  };

  handlePinArticle = async (pods) => {
    const currentPinned = this.state.pinnedArticle;
    const updatedArticle = {
      title: pods.title,
      pinned: currentPinned ? 0 : 1,
      authorId: pods.authorId._id,
    };

    try {
      const response = await axios.put(
        `${baseUrl()}pods/${pods.slug}`,
        updatedArticle
      );

      this.setState({ pinnedArticle: updatedArticle.pinned }, () => {
        this.pinpodsUpdated(
          `Article ${
            updatedArticle.pinned ? "pinned" : "unpinned"
          } successfully`
        );
      });
    } catch (error) {
      this.setState({ pinnedArticle: currentPinned }, () => {
        this.pinpodsUpdated("Failed to update the article");
      });
    }
    this.fetchPods();
  };

  handlePageChange = (page) => {
    this.setState({ currentPage: page });
  };

  handleSearch = (query) => {
    this.setState({ searchQuery: query, currentPage: 1 });
  };

  handleDraftFilter = () => {
    this.setState({ draftFilter: !this.state.draftFilter });
  };

  handleArchiveFilter = () => {
    this.setState({ archiveFilter: !this.state.archiveFilter });
  };

  handlePublishedFilter = () => {
    this.setState({ publishedFilter: !this.state.publishedFilter });
  };

  handleSort = (sortColumn) => {
    this.setState({ sortColumn });
  };

  notify = () => {
    toast.error("pod is deleted!");
  };
  pinPodsUpdated = () => {
    toast.success("Pods is Updated!");
  };

  getPagedData = () => {
    const {
      pageSize,
      currentPage,
      sortColumn,
      pods,
      searchQuery,
      draftFilter,
      archiveFilter,
      publishedFilter,
    } = this.state;

    let filtered = pods;

    if (searchQuery) {
      filtered = pods.filter((n) =>
        n.title.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }
    if (draftFilter) {
      filtered = pods.filter((post) => post.status === "draft");
    }
    if (publishedFilter) {
      filtered = pods.filter((post) => post.status === "published");
    }

    if (archiveFilter) {
      filtered = pods.filter((post) => post.status === "archive");
    }

    const sorted = _.orderBy(filtered, [sortColumn.path], [sortColumn.order]);

    const _pods = paginate(sorted, currentPage, pageSize);

    return { totalCount: filtered.length, data: _pods };
  };
  handleFilters = () => {
    this.setState({ showHideFilters: !this.state.showHideFilters });
  };

  render() {
    const {
      pageSize,
      currentPage,
      sortColumn,
      searchQuery,
      draftFilter,
      archiveFilter,
      publishedFilter,
      showHideFilters,
    } = this.state;

    if (!this.state.isLoaded && !this.state.error)
      return (
        <div className="lds-ellipsis">
          <div></div>
          <div></div>
          <div></div>
          <div></div>
        </div>
      );

    if (this.state.error) return <p>{this.state.error}</p>;

    if (
      this.state.pods.length === 0 &&
      this.props.user.userRole?.includes("Admin")
    ) {
      return (
        <>
          <p>There are no Pods to show.</p>
          <Link
            className="btn btn-primary"
            to="/create-soccerpod"
            style={{ marginBottom: 10, height: "max-content" }}>
            Create New
          </Link>
        </>
      );
    }

    const { totalCount, data: pods } = this.getPagedData();

    return (
      <div className="row">
        <div className="col">
          <div className="d-flex justify-content-between align-items-end gap-8">
            <div className="flex-1">
              {this.props.user.userRole?.includes("Admin") && (
                <Link
                  className="btn btn-primary"
                  to="/create-soccerpod"
                  style={{ marginBottom: 10, height: "max-content" }}>
                  Create New
                </Link>
              )}
              <p>Showing {totalCount} records from the database.</p>
            </div>
            {/* <SearchBox
              value={searchQuery}
              onChange={this.handleSearch}
              placeholder="Search..."
            /> */}
            <div className="d-inline-flex">
              <FilterSearchBox
                value={searchQuery}
                onChange={this.handleSearch}
                placeholder="Search..."
              />
              <button
                className="d-flex btn btn-primary flex mb-2 ml-2"
                onClick={this.handleFilters}>
                Filters
              </button>
            </div>
          </div>
          <div className="d-flex justify-content-between align-items-end gap-8">
            <div></div>

            {showHideFilters && (
              <div className="custom-checkbox mt-2 d-inline-flex ">
                <label className="custom-checkbox mr-1 ml-1">
                  <input
                    className="mr-1 "
                    type="checkbox"
                    checked={draftFilter}
                    onChange={this.handleDraftFilter}
                  />
                  Draft
                </label>
                <label className="custom-checkbox mr-1 ml-1">
                  <input
                    className="mr-1 ml-1"
                    type="checkbox"
                    checked={archiveFilter}
                    onChange={this.handleArchiveFilter}
                  />
                  Archive
                </label>
                <label className="custom-checkbox mr-1 ml-1">
                  <input
                    className="mr-1 ml-1"
                    type="checkbox"
                    checked={publishedFilter}
                    onChange={this.handlePublishedFilter}
                  />
                  Published
                </label>
              </div>
            )}
          </div>
          <div className="mt-3 mb-3">
            <Input
              name="title"
              label="Enter SoccerPod Heading"
              type="text"
              minlength="10"
              maxlength="40"
              strongLable={true}
              value="Lorem ipsum dolor sit amet, consectetur adipiscing elit"
              // onChange={handleChange}
              // onBlur={handleSlug}
              // error={errors.title}
            />
          </div>

          <PodsTable
            pods={pods}
            sortColumn={sortColumn}
            onSort={this.handleSort}
            onDelete={this.handleDelete}
            user={this.props.user}
            onHandlePin={this.handlePinArticle}
          />
          <Pagination
            itemsCount={totalCount}
            pageSize={pageSize}
            currentPage={currentPage}
            onPageChange={this.handlePageChange}
          />
        </div>
      </div>
    );
  }
}

export default SoccerPods;
