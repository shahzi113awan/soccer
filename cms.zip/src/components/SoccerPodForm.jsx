import React, { useState, useEffect, useRef } from "react";
import axios from "axios";
import slugify from "react-slugify";
import { useParams, useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import Input from "./common/input";
import { baseUrl } from "./../utils/baseUrl";
import "react-tabs/style/react-tabs.css";
import Select from "react-select";
import TinyMCE from "./common/tinymce";

import { da } from "date-fns/locale";
import TextArea from "./common/textarea";
import moment from "moment-timezone";
const SoccerPodForm = ({ user }) => {
  const [author] = useState(user.id);
  const [content, setContent] = useState("");
const[touched,setTouched] = useState(false)
  const [data, setData] = useState({
    title: "",
    slug: "",
    status: "draft",
    mediaLink: "",
    mediaType: "video",
    image: "",
    imageUrl: "",
    isContentChange: false,
    publisheDate: "",
  });
  const [errors, setErrors] = useState([]);
  const [isLoading, setIsLoading] = useState(false);

  const { id } = useParams();
  const editorRef = useRef(null);
  const navigate = useNavigate();

  async function getPodById(id) {
    await axios
      .get(`${baseUrl()}pods/${id}`)
      .then(async (res) => {
        const {
          title,
          status,
          mediaLink,
          mediaType,
          thumbnail,
          content,
          publisheDate,
        } = res.data;
        setData({
          title,
          imageUrl: thumbnail,
          status,
          mediaLink,
          mediaType,
          publisheDate: publisheDate ? moment(publisheDate).format("YYYY-MM-DDTHH:mm"):"",
        });
        setContent(content);
      })
      .catch((err) => {
        if (err.data.error && err.status === 404) notifyError(err.data?.error);

        setErrors({ API: err.data?.error });
      });
  }

  useEffect(() => {
    if (id) {
      getPodById(id);
    }
  }, []);

  const notify = (message) => {
    toast.success(message, {
      position: "top-right",
      autoClose: 2000,
      hideProgressBar: true,
      closeOnClick: true,
      pauseOnHover: true,
      draggable: true,
      progress: undefined,
    });
  };

  const notifyError = (message) => {
    toast.error(message, {
      position: "top-right",
      autoClose: 10000,
      hideProgressBar: true,
      closeOnClick: true,
      pauseOnHover: true,
      draggable: true,
      progress: undefined,
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    if (data.title?.trim().length < 5) {
      setErrors({ title: "Title cannot be empty or less than 5 characters." });
      return;
    } else if (data.title?.trim().length > 60) {
      setErrors({ title: "Title cannot be larger than 60 characters." });
      return;
    }

    if (data.mediaLink?.trim().length < 1) {
      setErrors({ mediaLink: "Media link cannot be empty" });
      return;
    } else if (!data.mediaLink?.includes("youtu")) {
      setErrors({ mediaLink: "Please enter a valid youtube link" });
      return;
    }

    if (content?.trim().length > 500) {
      setErrors({ content: "Content cannot be larger than 500 characters" });
      return;
    }

    setIsLoading(true);
    const { title, status, mediaLink, mediaType, image, publisheDate } = data;
    const formData = new FormData();
    if (image) formData.append("image", image, image.name);
    formData.append("title", title);
    formData.append("slug", slugify(title));
    formData.append("content", content);
    formData.append("status", status);
    formData.append("mediaLink", mediaLink);
    formData.append("mediaType", mediaType);
    formData.append("author", author);
    formData.append("publisheDate", touched ||id ? publisheDate:"");
    formData.append("isScheduled", !!publisheDate);

    if (id) {
      axios
        .put(`${baseUrl()}pods/${id}`, formData)
        .then((res) => {
          notify("SoccerPod updated successfully");
          setIsLoading(false);
          navigate("/soccerpods");
        })
        .catch((err) => {
          if (err.data.error && err.status === 404) alert(err.data?.error);

          setErrors({ API: err.data?.error });
          setIsLoading(false);
        });
    } else {
      axios
        .post(`${baseUrl()}pods`, formData)
        .then((res) => {
          notify("SoccerPod created successfully");
          setIsLoading(false);
          navigate("/soccerpods");
        })
        .catch((err) => {
          if (err.data.error && err.status === 404) alert(err.data?.error);

          setErrors({ API: err.data?.error });
          setIsLoading(false);
        });
    }
  };

  const handleChange = (e) => {
  
    if (e.target.name != "image") {
      setData({ ...data, [e.target.name]: e.target.value });
    } else {
      setData({ ...data, [e.target.name]: e.target.files[0] });
    }
  };
  const handleEditorChange = (e) => {
    setContent(e.target.value);
  };
  const handleSelect = (e) => {
    setData({ ...data, mediaType: e.target.value });
  };
  const handleDateChange = (e) => { 
    setTouched(true)
    setData({ ...data, publisheDate: e.target.value });

   }
  return (
    <div className="row">
      <div className="col-md-12">
        <h1>{id ? "Update SoccerPod" : "Create SoccerPod"}</h1>
        <form onSubmit={handleSubmit} encType="multipart/form-data">
          <div className="row">
            <div className="col-md-8">
              <Input
                name="title"
                label="Title"
                type="text"
                value={data.title}
                onChange={handleChange}
                // onBlur={handleSlug}
                error={errors.title}
              />

              <Input
                name="slug"
                label="Slug"
                type="text"
                value={slugify(data.title)}
                onChange={handleChange}
                // onBlur={handleSlug}
                error={errors.slug}
              />

              <label>Media Type</label>

              <select
                className="custom-select custom-select-md mb-3"
                name="mediaType"
                id="mediaType"
                onChange={(e) => handleSelect(e)}
                value={data.mediaType}>
                <option defaultChecked value={"video"}>
                  Youtube
                </option>
                {/* <option defaultChecked value={"audio"}>
                  Audio
                </option> */}
                {/* <option value={"Voice"}>Voice</option> */}
              </select>

              <Input
                name="mediaLink"
                label="Media Link"
                type="text"
                value={data.mediaLink}
                onChange={handleChange}
                error={errors.mediaLink}
              />
              <div className="mt-3">
                <TextArea
                  id="content"
                  rows="7"
                  className="w-100"
                  label="Content"
                  onChange={handleEditorChange}
                  value={content}
                  error={errors.content}
                />
              </div>
              {/* <label>Content</label>
              <TinyMCE
                editorRef={editorRef}
                value={data.content}
                callback={handleEditorChange}
              />
              <br /> */}
            </div>
            <div className="col-md-4">
              <div id="accordian" className="aside-accordian">
                <div className="card">
                  <div className="card-header" id="headingOne">
                    <h5 className="mb-o">
                      <a
                        href="/#"
                        className="btn btn-link"
                        data-toggle="collapse"
                        data-target="#collapseOne"
                        aria-expanded="true"
                        aria-controls="collapseOne">
                        Publish
                      </a>
                    </h5>
                  </div>
                  <div
                    id="collapseOne"
                    className="collapse show"
                    aria-labelledby="headingOne"
                    data-parent="#accordion">
                    <div className="card-body">
                      <select
                        className="custom-select custom-select-md mb-3"
                        name="status"
                        id="status"
                        onChange={handleChange}
                        value={data.status}>
                        <option value={"published"}>Publish</option>
                        <option value={"draft"}>Draft</option>
                        <option value={"archive"}>Archive</option>
                      </select>

                      {user.userRole !== "View Only" && (
                        <button
                          disabled={isLoading}
                          className="btn btn-primary">
                          {isLoading && (
                            <div className="lds-ring">
                              <div></div>
                              <div></div>
                              <div></div>
                              <div></div>
                            </div>
                          )}
                          {id ? "Update" : "Save"}
                        </button>
                      )}
                    </div>

                    {/* <div className="card-header" id="headingOne">
                      <h5 className="mb-o">
                        <a
                          href="/#"
                          className="btn btn-link"
                          data-toggle="collapse"
                          data-target="#collapseOne"
                          aria-expanded="true"
                          aria-controls="collapseOne">
                          Schedule
                        </a>
                      </h5>
                    </div> */}

                    {/* <div className="card">
                      <Input
                        name="publisheDate"
                        type="datetime-local"
                        // label="Schedule Post"
                        min={
                          id
                            ? ""
                            : new Date()
                                .toISOString()
                                .slice(
                                  0,
                                  new Date().toISOString().lastIndexOf(":")
                                )
                        }
                        value={data.publisheDate}
                        onChange={handleChange}
                        // error={errors.venueDateAndTime}
                      />
                    </div> */}
                  </div>
                </div>
                <div className="card-body">
                  <label>Image</label>
                  <Input
                    name={"image"}
                    label={""}
                    type={"file"}
                    onChange={handleChange}
                    accept={"image/png, image/gif, image/jpeg"}
                  />
                  {data.imageUrl && <img src={data.imageUrl} alt="" />}
                </div>
              </div>

              <div id="accordian" className="aside-accordian">
                <div className="card">
                  <div className="card-header" id="headingFive">
                    <h5 className="mb-o">
                      <a
                        href="/#"
                        className="btn btn-link"
                        data-toggle="collapse"
                        data-target="#collapseFive"
                        aria-expanded="true"
                        aria-controls="collapseFive">
                        Schedule News
                      </a>
                    </h5>
                  </div>
                  <div
                    id="collapseFive"
                    className="collapse show"
                    aria-labelledby="headingPublishDate"
                    data-parent="#accordion">
                    <div className="card-body">
                      <div className="mb-3">
                       <Input
                        style={{
                          color:touched || id?"":'lightgray'
                          
                        }}
                          name="publisheDate "
                          type="datetime-local"
                          // label="Schedule Post"
                          min={
                            id || !touched?"":
                            moment(new Date()).tz("America/New_York").format("YYYY-MM-DDTHH:mm")
                                   
                          }
                          value={ !data.publisheDate ? moment(new Date()).tz("America/New_York").format("YYYY-MM-DDTHH:mm"):data.publisheDate}

                          onChange={(e)=>{
                             
                            handleDateChange(e)
                          }}
                          // error={errors.venueDateAndTime}
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="card mt-4">
                <iframe
                  width="100%"
                  height="260"
                  src={
                    data.mediaLink
                      .split("&")[0]
                      .replace("watch?v=", "embed/") ||
                    "https://www.youtube.com/embed/0Z9VW4Y8X1I"
                  }
                  title="YouTube video player"
                  frameborder="0"
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                  allowfullscreen
                />
              </div>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};

export default SoccerPodForm;
