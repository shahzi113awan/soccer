import React, { Component } from "react";
import Table from "./common/table";

class LeagueTable extends Component {
  
  columns = [
    {
      path: "title",
      label: "Title",
      linkedColumn: true,
    },
    { path: "author.name", label: "Author" },
    { path: "createdAt", label: "Created At", createdAtColumn: true },
    { path: "lastUpdate", label: "Last Update", lastUpdateColumn: true },
    // {
    //   path: "isActive",
    //   label: "Status",
    //   statusColumn: true,
    // },
    {
      path: "status",
      label: "Status",
      statusColumnB: true,
    },
    {
      key: "children",
      content: (league) =>
        this.props.user.userRole?.includes("Admin") && (
          <div className="d-flex justify-content-end">
            <button
              className="btn btn-small btn-primary text-bold text-md capitalized text-white"
              onClick={() => {
                this.props.goToMatches(league);
              }}>
              All matches
              <i className="ml-2 fa fa-external-link" aria-hidden="true"></i>
            </button>
          </div>
        ),
    },
    {
      label: "Delete",
      key: "Delete",
      content: (league) =>
        this.props.user.userRole?.includes("Admin") && (
          <button
            className="btn btn-small btn-danger ml-3"
            onClick={() => this.props.onDelete(league)}>
            <i className="fa fa-trash" aria-hidden="true"></i>
          </button>
        ),
    },
  ];

  render() {
    const { league, onSort, sortColumn, goToMatches } = this.props;

    return (
      <Table
        columns={this.columns}
        sortColumn={sortColumn}
        data={league}
        onSort={onSort}
        baseRoute={"/league"}
        linkedColumnPath={"title"}
        createdAtColumn={"createdAt"}
        lastUpdateColumn={"lastUpdate"}
        statusColumn={"status"}
      />
    );
  }
}

export default LeagueTable;
