
export function baseUrl() {
  const enviroment = process.env.REACT_APP_NODE_ENV;
  let baseUrl = "";

  if (enviroment === "uat") {
    baseUrl = process.env.REACT_APP_UAT
  } else if (enviroment === "production") {
    baseUrl = process.env.REACT_APP_PROD
  } else {
    baseUrl = process.env.REACT_APP_DEV
  }

  return baseUrl;
}