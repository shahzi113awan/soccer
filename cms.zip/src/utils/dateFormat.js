import { formatDistance } from 'date-fns'

export function getHumanReadableTime(fromDate) {
  let result= "";
  if (fromDate) {
    result = formatDistance(
      new Date(fromDate),
      new Date(),
      { addSuffix: true }
    )
  }
  return result;
}

export function formatDate(timestamp) {
  const monthNames = [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December",
  ];

  let date = new Date(timestamp);
  let day = ("0" + date.getDate()).slice(-2);
  let month = monthNames[date.getMonth()];
  let year = date.getFullYear();
  
  return `${day}-${month}-${year}`;
}