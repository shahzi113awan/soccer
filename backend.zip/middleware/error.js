const { logger } = require("../middleware/logger");

module.exports = function (err, req, res, next) {
  logger.log({ level: "error", message: err });
  res.status(500).send({ error: "Something Failed!" });
};
