const multer = require("multer");

let maxFileSize = 200 * 1024 * 1024; // 200MB

const fileStorageEngine = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, "./uploads");
  },
  filename: (req, file, cb) => {
    cb(
      null,
      Date.now() + "-" + file.originalname.toLowerCase().split(" ").join("-")
    );
  },
});

const uploadMedia = multer({
  storage: fileStorageEngine,
  limits: { fileSize: maxFileSize },
});

module.exports = uploadMedia;
