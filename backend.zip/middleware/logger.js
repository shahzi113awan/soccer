const { transports, createLogger, format } = require("winston");

module.exports.logger = createLogger({
  format: format.combine(format.timestamp(), format.json(), format.colorize()),
  transports: [
    new transports.File({ filename: "error.log", level: "error" }),
    new transports.Console({ format: format.simple() }),
  ],
});
