function isAdmin(req, res, next) {
  if (
    req.user.userRole === "Content Admin" ||
    req.user.userRole === "View Only"
  )
    return res.status(403).send("Access denied.");

  next();
}

function isContentAdmin(req, res, next) {
  if (req.user.userRole === "View Only")
    return res.status(403).send("Access denied.");

  next();
}

module.exports = { isAdmin, isContentAdmin };
