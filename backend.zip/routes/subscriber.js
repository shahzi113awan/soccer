const express = require("express");
const router = express.Router();
const { Subscriber, validate } = require("../models/subscriber");

router.get("/", async (req, res) => {
  const subscribers = await Subscriber.find().sort("name");
  res.send(subscribers);
});

router.post("/", async (req, res) => {
  const { error } = validate(req.body);
  if (error) return res.status(400).send({ message: error.details[0].message });

  const emailCheck = await Subscriber.findOne({ email: req.body.email });
  if (emailCheck)
    return res.status(400).send({ message: "Email already exist!" });

  const subscriber = new Subscriber({
    name: req.body.name,
    email: req.body.email,
    favoriteTeam: req.body.favoriteTeam,
    favClubTeam: req.body.favClubTeam,
  });

  await subscriber.save();
  res.send({ message: "Thank you for subscribing." });
});

module.exports = router;
