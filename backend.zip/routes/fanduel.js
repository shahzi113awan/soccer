const express = require("express");
const router = express.Router();
const { Fanduel, validate } = require("../models/fanduel");

const validateObjectId = require("../middleware/validateObjectId");
const { auth } = require("../middleware/auth");
const { isAdmin } = require("../middleware/admin");
const upload = require("../middleware/upload");
const { baseUrl } = require("../utils/helpers");
const fs = require("fs");

router.get("/", async (req, res) => {
  
  const fanduels = await Fanduel.find();
  res.send(fanduels);
});

router.get("/:id", validateObjectId, async (req, res) => {
  const fanduel = await fanduel.findById(req.params.id);
  res.send(fanduel);
});

router.post("/", [auth, isAdmin, upload.single("image")], async (req, res) => {
  console.log(req);
  let newImage = "";

  if (req.file) newImage = baseUrl() + req.file.path.replace("\\", "/");

  const { error } = validate(req.body);
  if (error) {
    let imagePath = newImage.replace(baseUrl(), "");
    if (imagePath)
      try {
        fs.unlinkSync("./" + imagePath);
      } catch (err) {}
    return res.status(400).send({ message: error.details[0].message });
  }

  const value = {
    image: newImage,
    sections: req.body.value,
  };

  const fanduel = new Fanduel({
    key: req.body.key,
    value: value,
    link: req.body.link,
  });

  await fanduel.save();

  res.status(200).send(fanduel);
});

router.put(
  "/:id",
  [auth, isAdmin, validateObjectId, upload.single("image")],
  async (req, res) => {
    let newImage = "";
    let imagePath = "";

    if (req.file) newImage = baseUrl() + req.file.path.replace("\\", "/");

    imagePath = newImage.replace(baseUrl(), "");

    const { error } = validate(req.body);

    if (error) {
      if (imagePath)
        try {
          fs.unlinkSync("./" + imagePath);
        } catch (err) {}

      return res.status(400).send({ message: error.details[0].message });
    }

    const oldPost = await Fanduel.findById(req.params.id);

    if (newImage) {
      let oldImage = oldPost.value.image.replace(baseUrl(), "");

      if (oldImage)
        try {
          fs.unlinkSync("./" + oldImage);
        } catch (err) {}
    } else {
      newImage = oldPost.value.image;
    }

    const value = {
      image: newImage,
      sections: req.body.value,
    };

    const fanduel = await Fanduel.findByIdAndUpdate(
      req.params.id,
      {
        key: req.body.key,
        value: value,
        heading: req.body.heading,
        link: req.body.link,
      },
      { new: true }
    );

    if (!fanduel) return res.status(404).send({ error: "Not found!" });

    res.send(fanduel);
  }
);

// router.delete('/:id', [auth, isAdmin, validateObjectId], async (req, res) => {
//   const adBanner = await AdBanner.findByIdAndRemove(req.params.id);

//   if (!adBanner) return res.status(404).send({ message: 'No adBanner found!' });
//   let imagePath = adBanner.value.image.replace(baseUrl(), "");
//   if (imagePath) try { fs.unlinkSync("./" + imagePath) } catch (err) { }
//   res.send(adBanner);
// })

module.exports = router;
