const express = require("express");
const router = express.Router();
const { News, validate, validateUpdate } = require("../models/news");
const { User } = require("../models/user");
const validateObjectId = require("../middleware/validateObjectId");
const upload = require("../middleware/upload");
const { auth } = require("../middleware/auth");
const { isContentAdmin } = require("../middleware/admin");
const { baseUrl } = require("../utils/helpers");
const fs = require("fs");
const mongoose = require("mongoose");
const { League } = require("../models/league");
const { error } = require("console");

router.get("/", async (req, res) => {
  const { pageNumber = null, pageSize = null, league = undefined } = req.query;
// console.log("merge")
  if (pageSize > 25)
    return res.send({ error: "Invalid page number or page size." });
  const news = await News.find()
    .select("-content")
    .populate("authorId")
    .populate("league")
    .skip((pageNumber - 1) * pageSize)
    .limit(pageSize)
    .sort({ pinned: -1, createdAt: -1 });
  return res.send(news);

  // const news = await News.find().populate("author")
  // .populate("league").select("-content").sort("-createdAt");
  // res.send(news);
});
//get by leagues
router.get("/leagues", async (req, res) => {
  // const { pageNumber = 0, pageSize = 4 } = req.query;
  const Pinnednews = await League.aggregate([
    {
      $match: {
        status: "published",
      },
    },
    {
      $sort: {
        order: 1,
      },
    },
    {
      $lookup: {
        from: "news",
        localField: "_id",
        foreignField: "league",
        as: "news",
      },
    },
    {
      $unwind: "$news",
    },
    {
      $match: {
        "news.pinned": 1,
      },
    },
    {
      $sort: {
        "news.createdAt": -1,
      },
    },
    {
      $group: {
        _id: "$_id",
        leagueTitle: { $first: "$title" },
        leagueSlug: { $first: "$slug" },
        isActive: { $first: "$isActive" },
        leagueOrder: { $first: "$order" },
        routes: { $first: "$slug" },
        slug: { $first: true },
        news: { $push: "$news" },
      },
    },
    {
      $project: {
        _id: true,
        leagueTitle: true,
        leagueSlug: true,
        isActive: true,
        leagueOrder: true,
        routes: true,
        slug: true,
        news: {
          _id: true,
          title: true,
          subTitle: true,
          authorId: true,
          tags: true,
          featuredImage: true,
          slug: true,
          isActive: true,
          order: true,
          meta_title: true,
          meta_des: true,
          meta_keyword: true,
          meta_tag: true,
          altText: true,
          isFeatured: true,
          pinned: true,
          publisheDate: true,
          isScheduled: true,
          status: true,
          archive: true,
          createdAt: true,
        },
      },
    },
  ]);
  const firstNews = await League.aggregate([
    {
      $match: {
        status: "published",
      },
    },
    {
      $sort: {
        order: 1,
      },
    },
    {
      $lookup: {
        from: "news",
        localField: "_id",
        foreignField: "league",
        as: "news",
      },
    },
    {
      $unwind: "$news",
    },
    {
      $match: {
        "news.pinned": 0,
        "news.status": "published",
        "news.isScheduled": false
      },
    },
    {
      $sort: {
        "news.createdAt": -1,
      },
    },
    {
      $limit: 1
    },
    {
      $group: {
        _id: "$_id",
        leagueTitle: { $first: "$title" },
        leagueSlug: { $first: "$slug" },
        isActive: { $first: "$isActive" },
        leagueOrder: { $first: "$order" },
        routes: { $first: "$slug" },
        slug: { $first: true },
        news: { $push: "$news" },
      },
    },
    {
      $project: {
        _id: true,
        leagueTitle: true,
        leagueSlug: true,
        isActive: true,
        leagueOrder: true,
        routes: true,
        slug: true,
        news: {
          _id: true,
          title: true,
          subTitle: true,
          authorId: true,
          tags: true,
          featuredImage: true,
          slug: true,
          isActive: true,
          order: true,
          meta_title: true,
          meta_des: true,
          meta_keyword: true,
          meta_tag: true,
          altText: true,
          isFeatured: true,
          pinned: true,
          publisheDate: true,
          isScheduled: true,
          status: true,
          archive: true,
          createdAt: true,
        },
      },
    },
  ]);
  const excludeIds = [ firstNews[0]?.news[0]?._id]
  const news = await League.aggregate([
    {
      $match: {
        status: "published",
      },
    },
    {
      $sort: {
        order: 1,

      },
    },
    {
      $lookup: {
        from: "news",
        localField: "_id",
        foreignField: "league",
        as: "news",
      },
    },
    {
      $unwind: "$news",
    },
    {
      $match: {
        "news.pinned": 0,
        "news.status": "published",
        "news.isScheduled": false,
        "news._id": { $nin: Pinnednews?.length>0?[]: excludeIds }
      }
    },
    {
      $sort: {
        "news.createdAt": -1,
      },
    },
    {
      $group: {
        _id: "$_id",
        leagueTitle: { $first: "$title" },
        leagueSlug: { $first: "$slug" },
        isActive: { $first: "$isActive" },
        leagueOrder: { $first: "$order" },
        routes: { $first: "$slug" },
        slug: { $first: "$slug" },
        news: { $push: "$news" },
      },
    },
    {
      $project: {
        _id: true,
        leagueTitle: true,
        leagueSlug: true,
        isActive: true,
        leagueOrder: true,
        routes: true,
        slug: true,
        news: {
          _id: true,
          title: true,
          subTitle: true,
          authorId: true,
          tags: true,
          featuredImage: true,
          slug: true,
          isActive: true,
          order: true,
          meta_title: true,
          meta_des: true,
          meta_keyword: true,
          meta_tag: true,
          altText: true,
          isFeatured: true,
          pinned: true,
          publisheDate: true,
          isScheduled: true,
          status: true,
          archive: true,
          createdAt: true,
        },
      },
    },
  ]);
  const newsordered = news.sort((a, b) => {
    return a.leagueOrder - b.leagueOrder;
  });
  // const news = await News.aggregate([
  //   {
  //     $lookup: {
  //       from: "leagues",
  //       localField: "league",
  //       foreignField: "_id",
  //       as: "league",
  //     },
  //   },
  //   {
  //     $unwind: "$league",
  //   },
  //   {
  //     $match: {
  //       "league.status": "published",
  //     },
  //   },
  //   {
  //     $sort:{
  //       "createdAt":-1
  //     }
  //   },

  //   {
  //     $group: {
  //       _id: { leagueSlug: "$league.slug", leagueTitle: "$league.title",leagueOrder:"$league.order" },

  //       newschild: {
  //         $push: "$$ROOT",
  //       },
  //     },
  //   },
  //   {
  //     $project: {
  //       _id: 0,
  //       leagueSlug: "$_id.leagueSlug",
  //       leagueTitle: "$_id.leagueTitle",
  //       routes :"$_id.leagueSlug",
  //       leagueOrder:"$_id.leagueOrder",
  //       slug:'$_id.leagueSlug',
  //       news:  '$newschild'
  //     },
  //   },
  // ]);

  // if (pageSize > 25)
  //   return res.send({ error: "Invalid page number or page size." });
  // const news = await News.find({league: req.params.league})
  //   .select("-content")
  //   .populate("authorId")
  //   .populate("league")
  //   .skip((pageNumber - 1) * pageSize)
  //   .limit(pageSize)
  //   .sort("order");
  
  return res.send({ pinned: Pinnednews?.length > 0 ? Pinnednews : firstNews, news:newsordered });

  // const news = await News.find().populate("author")
  // .populate("league").select("-content").sort("-createdAt");
  // res.send(news);
});
router.get("/one-league/:league", async (req, res) => {
  try {
    const { pageNumber = 0, pageSize = 4, } = req.query;
    //find league by slug
       const league = await League.findOne({ slug: req.params.league })

    if (!league) {
      return res.status(404).send({ message: "League not found" })
    }
    else {
    const news = await News.find({ league: league._id, statue: "published", isScheduled: false })

        .populate("authorId")
        .populate("league").select("-content -commentsCount -sidebarAds")
        .sort("-createdAt").lean().exec();

      return res.send(news);
    }

  } catch (error) {
    res.status(500).send({ message: error.message })
  }


  // const news = await News.find().populate("author")
  // .populate("league").select("-content").sort("-createdAt");
  // res.send(news);
});





router.get("/:id", async (req, res) => {
  if (mongoose.isValidObjectId(req.params.id)) {
    const news = await News.find({ isScheduled: false, status: 'published' }).select("id title slug").sort("-createdAt");

    const index = news.findIndex((n) => n.id === req.params.id);
    const prevIndex = news[index - 1];
    const nextIndex = news[index + 1];

    const response = {
      prev: prevIndex ? prevIndex : "",
      next: nextIndex ? nextIndex : "",
    };

    if (!response) return res.status(404).send({ error: "No news found!" });

    return res.send(response);
  } else {
    const news = await News.findOne({ slug: req.params.id })
      .populate("authorId")
      .populate("league");
    if (!news) return res.status(404).send({ error: "No news found!" });
    return res.send(news);
  }
});

router.post(
  "/",
  [auth, isContentAdmin, upload.single("image")],

  async (req, res) => {
    try {
      let newImage = "";

      if (req.file) newImage = baseUrl() + req.file.path.replace("\\", "/");

      const { error } = validate(req.body);
      if (error) {
        let imagePath = newImage.replace(baseUrl(), "");
        if (imagePath)
          try {
            fs.unlinkSync("./" + imagePath);
          } catch (err) { }
        return res.status(400).send({ message: error.details[0].message });
      }
      //setting the order
      req.body["order"] = (await News.countDocuments()) + 1;
      if (!req.body.league) {
        res.status(400).send({ message: "League is required" });
      }

      req.body["featuredImage"] = newImage;
      const user = await User.findById(req.body.authorId);
      if (!user) return res.status(400).send({ error: "Invalid author" });
      const news = new News(req.body);

      await news.save();

      res.send(news);
    } catch (error) {
      return res.status(500).send({
        message: error.code === 11000 ? "Slug Exist!" : error.message,
      });
    }
  }
);

router.put(
  "/:id",
  [auth, isContentAdmin, upload.single("image")],
  async (req, res) => {
    try {
      let newImage = "";
      let imagePath = "";

      if (req.file) newImage = baseUrl() + req.file?.path?.replace("\\", "/");

      imagePath = newImage.replace(baseUrl(), "");

      if (mongoose.isValidObjectId(req.params.id)) {
        if (imagePath)
          try {
            fs.unlinkSync("./" + imagePath);
          } catch (err) { }
        return res
          .status(400)
          .send({ message: "Send news slug instead of an ID to update news." });
      }

      const { error } = validateUpdate(req.body);
      if (error) {
        if (imagePath)
          try {
            fs.unlinkSync("./" + imagePath);
          } catch (err) { }
        return res.status(400).send({ message: error.details[0].message });
      }

      const user = await User.findById(req.body.authorId);
      if (!user) {
        let imagePath = newImage?.replace(baseUrl(), "");
        if (imagePath)
          try {
            fs.unlinkSync("./" + imagePath);
          } catch (err) { }
        return res.status(400).send({ error: "Invalid author" });
      }

      const oldPost = await News.findOne({ slug: req.params.id });
      if (newImage) {
        let oldImage = oldPost?.featuredImage?.replace(baseUrl(), "");
        if (oldImage)
          try {
            fs.unlinkSync("./" + oldImage);
          } catch (err) { }
      } else {
        newImage = oldPost.featuredImage;
      }
      req.body["featuredImage"] = newImage;
      if (req.body.pinned) {
        req.body["pinned"] = 1;
      }
      //unpin other news
      if (req.body.pinned === 1) {
        await News.findOneAndUpdate(
          { pinned: 1 },
          {
            $set: {
              pinned: 0,
            },
          }
        );
      }
      //unpin if sttus is draft or archive
      if (
        oldPost.pinned === 1 &&
        (req.body.status === "draft" || req.body.status === "archive")
      ) {
        req.body["pinned"] = 0;
      }

      const news = await News.findOneAndUpdate(
        { slug: req.params.id },

        req.body,

        { new: true }
      );

      if (!news) return res.status(404).send({ error: "No news found!" });

      res.send(news);
    } catch (error) {
      return res.status(500).send({
        message: error.code === 11000 ? "Slug Exist!" : error.message,
      });
    }
  }
);

//Update news order
router.put("/order/:id", [auth, isContentAdmin], async (req, res) => {
  try {
    const { error } = validateOrder(req.body);
    if (error)
      return res.status(400).send({ message: error.details[0].message });

    const news = await News.findOneAndUpdate(
      { slug: req.params.id },
      {
        $set: {
          order: req.body.order,
        },
      },
      { new: true }
    );

    if (!news) return res.status(404).send({ error: "No news found!" });

    res.send(news);
  } catch (error) {
    return res
      .status(500)
      .send({ message: error.code === 11000 ? "Slug Exist!" : error.message });
  }
});
router.post("/seed",[auth,isContentAdmin],async(req,res)=>{
  try {
    await News.updateMany({ pinned:  {$exists:false} }, { $set: { pinned: 0} });
    await News.updateMany({$set:{authorId:"63ce3b3e4291e1d651b14985"}})
    return res.status(200).send({message:"seeded succesfully"})
  } catch (error) {
    return res.status(200).send({message:error.message})
    
  }
})

router.delete(
  "/:id",
  [auth, isContentAdmin, validateObjectId],
  async (req, res) => {
    const news = await News.findByIdAndRemove(req.params.id);

    if (!news) return res.status(404).send({ message: "No news found!" });
    let imagePath = news.featuredImage?.replace(baseUrl(), "");
    if (imagePath)
      try {
        fs.unlinkSync("./" + imagePath);
      } catch (err) { }
    res.send({ message: "News deleted successfully." });
  }
);

module.exports = router;
