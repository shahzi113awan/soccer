const express = require("express");
const router = express.Router();

const { User } = require("../models/user");
const { Child, validate } = require("../models/childs");
const { League } = require("../models/league");
const validateObjectId = require("../middleware/validateObjectId");
const upload = require("../middleware/upload");
const { auth } = require("../middleware/auth");
const { isContentAdmin } = require("../middleware/admin");
const { baseUrl } = require("../utils/helpers");
const fs = require("fs");
const mongoose = require("mongoose");

router.get("/leagues", async (req, res) => {
  // console.log("leagues");
  try {
    const leaguesWithMatches = await League.aggregate([
      {
        $match: {
          status: "published",
        },
      },
      {
        $sort: {
          order: 1,
        },
      },
      {
        $lookup: {
          from: "children",
          localField: "_id",
          foreignField: "league",
          as: "matches",
        },
      },
      {
        $project: {
          _id: true,
          title: true,
          slug: true,
          isActive: true,
          order: true,
          matches: {
            _id: true,
            title: true,
            subTitle: true,
            author: true,
            category: true,
            altText: true,
            tags: true,
            slug: true,
            subtitle: true,
            excerpt: true,
            featuredImage: true,
            venueLocation: true,
            venueDateAndTime: true,
            isActive: true,
            scheduledPreview: true,
            createdAt: true,
            updatedAt: true,
            lastUpdate: true,
            league: true,
            status: true,
          },
        },
      },
    ]);
    return res.send(leaguesWithMatches);
  } catch (error) {
    return res.send(error.message);
  }
});

router.get("/:slug", async (req, res) => {
  const { pageNumber, pageSize } = req.query;
  const league = await League.findOne({ slug: req.params.slug });
  if (pageNumber && pageSize) {
    if (pageNumber < 1 || pageSize < 1 || pageSize > 25)
      return res.send({ error: "Invalid page number or page size." });
    const childs = await Child.find({ league: league._id })
      .select("-content")
      .populate("user")
      .populate("league")
      .skip((pageNumber - 1) * pageSize)
      .limit(pageSize)
      .sort("-createdAt");
    return res.send(childs);
  }
  const childs = await Child.find({ league: league._id })
    .select("-content")
    .sort("-createdAt");
  res.send(childs);
});

router.get("/getOne/:id", async (req, res) => {
  if (mongoose.isValidObjectId(req.params.id)) {
    const childs = await Child.find().sort("-createdAt");
    const index = childs.findIndex((n) => n.id === req.params.id);
    const prevIndex = previews[index - 1];
    const nextIndex = previews[index + 1];
    const response = {
      prev: prevIndex ? prevIndex : "",
      next: nextIndex ? nextIndex : "",
    };
    if (!response) return res.status(404).send({ error: "Not found!" });
    return res.send(response);
  } else {
    const child = await Child.findOne({ slug: req.params.id });
    if (!child) return res.status(404).send({ error: "No child found!" });
    res.send(child);
  }
});

router.post(
  "/:slug",
  [auth, isContentAdmin, upload.single("image")],
  async (req, res) => {
    try {
      let newImage = "";
      if (req.file) newImage = baseUrl() + req.file.path.replace("\\", "/");

      const { error } = validate(req.body);
      if (error) {
        let imagePath = newImage.replace(baseUrl(), "");
        if (imagePath)
          try {
            fs.unlinkSync("./" + imagePath);
          } catch (err) {}
        return res.status(400).send({ message: error.details[0].message });
      }

      const user = await User.findById(req.body.authorId);
      if (!user) return res.status(400).send({ error: "Invalid user." });

      //find League by slug
      const league = await League.findOne({ slug: req.params.slug });
      if (!league) return res.status(400).send({ error: "Invalid league." });
      else req.body["league"] = league._id;
      req.body["featuredImage"] = newImage;
      const child = new Child(req.body);
      await child.save();
      res.send(child);
    } catch (error) {
      return res.status(500).send({
        message: error.code === 11000 ? "Slug Exist!" : error.message,
      });
    }
  }
);

router.put(
  "/:id",
  [auth, isContentAdmin, upload.single("image")],
  async (req, res) => {
    try {
      let newImage = "";
      if (req.file) newImage = baseUrl() + req.file.path.replace("\\", "/");
      //find League by slug
      if (req.file) {
        req.body["featuredImage"] = newImage;
      }

      const child = await Child.findOneAndUpdate(
        { slug: req.params.id },
        req.body,
        {
          new: true,
        }
      );

      if (!child) return res.status(404).send({ error: "Not found!" });
      res.send(child);
    } catch (error) {
      return res.status(500).send({
        message: error.code === 11000 ? "Slug Exist!" : error.message,
      });
    }
  }
);

router.delete("/:id", [auth, isContentAdmin], async (req, res) => {
  const child = await Child.findByIdAndRemove(req.params.id);
  if (!child) return res.status(404).send({ error: "Not found!" });
  res.status(200).send({ message: "Deleted successfully!" });
});

module.exports = router;
