const express = require("express");
const router = express.Router();
const { moreTeamsUsa, validate } = require("../models/moreTeamUsa");
const validateObjectId = require("../middleware/validateObjectId");
const { auth } = require("../middleware/auth");
const { isAdmin } = require("../middleware/admin");
const upload = require("../middleware/upload");
const { baseUrl } = require("../utils/helpers");
const fs = require("fs");

router.get("/", async (req, res) => {
  const moreTeamsUsas = await moreTeamsUsa.find();
  res.send(moreTeamsUsas);
});

router.get("/:id", validateObjectId, async (req, res) => {
  const moreTeamUsa = await moreTeamUsa.findById(req.params.id);
  res.send(moreTeamUsa);
});

router.post("/", [auth, isAdmin, upload.single("image1")], async (req, res) => {
  console.log(req);
  let newImage = "";

  if (req.file) newImage = baseUrl() + req.file.path.replace("\\", "/");

  const { error } = validate(req.body);
  if (error) {
    let imagePath = newImage.replace(baseUrl(), "");
    if (imagePath)
      try {
        fs.unlinkSync("./" + imagePath);
      } catch (err) {}
    return res.status(400).send({ message: error.details[0].message });
  }

  const value = {
    image1: newImage,
    sections: req.body.value,
  };

  const moreTeamUsa = new moreTeamsUsa({
    key: req.body.key,
    value: value,
    heading: req.body.heading,
    description: req.body.description,
    link: req.body.link,
  });

  await moreTeamUsa.save();

  res.status(200).send(moreTeamUsa);
});

router.put(
  "/:id",
  [auth, isAdmin, validateObjectId, upload.single("image1")],
  async (req, res) => {
    let newImage = "";
    let imagePath = "";

    if (req.file) newImage = baseUrl() + req.file.path.replace("\\", "/");

    imagePath = newImage.replace(baseUrl(), "");

    const { error } = validate(req.body);

    if (error) {
      if (imagePath)
        try {
          fs.unlinkSync("./" + imagePath);
        } catch (err) {}

      return res.status(400).send({ message: error.details[0].message });
    }

    const oldPost = await moreTeamsUsa.findById(req.params.id);

    if (newImage) {
      let oldImage = oldPost.value.image1.replace(baseUrl(), "");

      if (oldImage)
        try {
          fs.unlinkSync("./" + oldImage);
        } catch (err) {}
    } else {
      newImage = oldPost.value.image1;
    }

    const value = {
      image1: newImage,
      sections: req.body.value,
    };
    if (req.body.pinned === 1) {
      await moreTeamsUsa.findOneAndUpdate(
        { pinned: 1 },
        {
          $set: {
            pinned: 0,
          },
        }
      );
    }

    const moreTeamUsa = await moreTeamsUsa.findByIdAndUpdate(
      req.params.id,
      {
        key: req.body.key,
        value: value,
        heading: req.body.heading,
        description: req.body.description,
        authorName: req.body.authorName,
      },
      { new: true }
    );

    if (!moreTeamUsa) return res.status(404).send({ error: "Not found!" });

    res.send(moreTeamUsa);
  }
);

router.delete("/:id", [auth, isAdmin, validateObjectId], async (req, res) => {
  const moreTeamUsa = await moreTeamsUsa.findByIdAndRemove(req.params.id);

  if (!moreTeamUsa) return res.status(404).send({ message: "Not found!" });
  let imagePath = moreTeamUsa.value.image1.replace(baseUrl(), "");
  if (imagePath)
    try {
      fs.unlinkSync("./" + imagePath);
    } catch (err) {}
  res.send(moreTeamUsa);
});

module.exports = router;
