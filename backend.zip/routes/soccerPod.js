const express = require("express");
const router = express.Router();
const { auth } = require("../middleware/auth");
const { isAdmin } = require("../middleware/admin");
const upload = require("../middleware/upload");
const {
  getAll,
  getOne,
  update,
  create,
  remove,
} = require("../controllers/soccerpod.controller");

router.get("/", getAll);
router.post("/", [auth, isAdmin, upload.single("image")], create);
router.get("/:id", getOne);
router.put("/:id", [auth, isAdmin, upload.single("image")], update);
router.delete("/:id", [auth, isAdmin], remove);

module.exports = router;
