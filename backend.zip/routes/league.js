const express = require("express");
const router = express.Router();
const validateObjectId = require("../middleware/validateObjectId");
const upload = require("../middleware/upload");
const { auth } = require("../middleware/auth");
const { isContentAdmin } = require("../middleware/admin");
const {
  getAll,
  getOne,
  create,
  update,
  remove,
  updateBulk,
} = require("../controllers/leagues.controller");

router.put("/bulk",[auth, isContentAdmin, upload.single("image")], updateBulk);
router.get("/", getAll);
router.get("/:id", getOne);
router.post("/", [auth, isContentAdmin, upload.single("image")], create);
router.put("/:id", [auth, isContentAdmin, upload.single("image")], update);
router.delete("/:id", [auth, isContentAdmin, validateObjectId], remove);

module.exports = router;
