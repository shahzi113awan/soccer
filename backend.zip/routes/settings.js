const express = require("express");
const router = express.Router();
const { Setting, validate } = require("../models/settings");
const validateObjectId = require("../middleware/validateObjectId");
const { auth } = require("../middleware/auth");
const { isAdmin } = require("../middleware/admin");
const upload = require("../middleware/upload");
const { baseUrl } = require("../utils/helpers");
const fs = require("fs");

router.get("/", async (req, res) => {
  const settings = await Setting.find();
  res.send(settings);
});

router.get("/:id", validateObjectId, async (req, res) => {
  const setting = await Setting.findById(req.params.id);
  res.send(setting);
});

router.post(
  "/",
  [auth, isAdmin, upload.single("bannerImage")],
  async (req, res) => {
    console.log("req--->", req);
    let newImage = "";
    let text = "";
    if (req.file) newImage = baseUrl() + req.file.path.replace("\\", "/");

    const { error } = validate(req.body);
    if (error) {
      let imagePath = newImage.replace(baseUrl(), "");
      if (imagePath)
        try {
          fs.unlinkSync("./" + imagePath);
        } catch (err) {}
      return res.status(400).send({ message: error.details[0].message });
    }

    const value = {
      bannerImage: newImage,
      sections: req.body.value,
    };

    const setting = new Setting({
      text: req.body.text,
      key: req.body.key,
      value: value,
      meta_title: req.body.meta_title,
      meta_des: req.body.meta_des,
      meta_keyword: req.body.meta_keyword,
      meta_tag: req.body.meta_tag,
    });

    await setting.save();

    res.status(200).send(setting);
  }
);

router.put(
  "/:id",
  [auth, isAdmin, validateObjectId, upload.single("bannerImage")],
  async (req, res) => {
    let newImage = "";
    let imagePath = "";
    let text = "";

    if (req.file) newImage = baseUrl() + req.file.path.replace("\\", "/");

    imagePath = newImage.replace(baseUrl(), "");
    //
    const { error } = validate(req.body);
    if (error) {
      if (imagePath)
        try {
          fs.unlinkSync("./" + imagePath);
        } catch (err) {}
      return res.status(400).send({ message: error.details[0].message });
    }

    const oldPost = await Setting.findById(req.params.id);

    if (newImage) {
      let oldImage = oldPost.value.bannerImage.replace(baseUrl(), "");
      if (oldImage)
        try {
          fs.unlinkSync("./" + oldImage);
        } catch (err) {}
    } else {
      newImage = oldPost.value.bannerImage;
    }

    const value = {
      bannerImage: newImage,
      sections: req.body.value,
    };

    const setting = await Setting.findByIdAndUpdate(
      req.params.id,
      {
        key: req.body.key,
        value: value,
        text: req.body.text,
        meta_title: req.body.meta_title,
        meta_des: req.body.meta_des,
        meta_keyword: req.body.meta_keyword,
        meta_tag: req.body.meta_tag,
      },
      { new: true }
    );

    if (!setting) return res.status(404).send({ error: "No setting found!" });

    res.send(setting);
  }
);

router.delete("/:id", [auth, isAdmin, validateObjectId], async (req, res) => {
  const setting = await Setting.findByIdAndRemove(req.params.id);

  if (!setting) return res.status(404).send({ message: "No setting found!" });
  let imagePath = setting.value.bannerImage.replace(baseUrl(), "");
  if (imagePath)
    try {
      fs.unlinkSync("./" + imagePath);
    } catch (err) {}
  res.send(setting);
});

module.exports = router;
