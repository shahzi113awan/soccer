const bcrypt = require("bcrypt");
const express = require("express");
const router = express.Router();
const { User, validate, validateLoginUser } = require("../models/user");
const { auth } = require("../middleware/auth");
const { isAdmin } = require("../middleware/admin");
const validateObjectId = require("../middleware/validateObjectId");
const _ = require("lodash");

router.get("/", async (req, res) => {
  const users = await User.find().where({ userRole: { $ne: "Super Admin" } });
  res.status(200).send(users);
});

router.get("/super", async (req, res) => {
  const superUser = await User.findOne({ userRole: "Super Admin" });
  if (superUser)
    return res
      .status(400)
      .send({ authToken: token, message: "  Super user is already exists." });

  const user = new User({
    name: "Soccerbx Team",
    email: "admin@soccerbx.com",
    password: "Mtp@123!@#",
    userRole: "Super Admin",
  });

  const salt = await bcrypt.genSalt(10);
  user.password = await bcrypt.hash(user.password, salt);
  await user.save();

  const token = user.generateAuthToken();
  res.status(200).send({ authToken: token });
});

router.get("/me", auth, async (req, res) => {
  const user = await User.findById(req.user._id).select("-password");

  if (!user)
    return res
      .status(400)
      .send({ message: "Authentication token is expired!" });
  res.send(user);
});

router.post("/login", async (req, res) => {
  const { error } = validateLoginUser(req.body);
  if (error) return res.status(400).send({ message: error.details[0].message });

  let user = await User.findOne({ email: req.body.email });
  if (!user)
    return res.status(400).send({ message: "Invalid email or password." });

  const match = await bcrypt.compare(req.body.password, user.password);

  if (match) {
    const token = user.generateAuthToken();
    return res.status(200).send({ _id: user._id, authToken: token });
  }

  res.status(400).send({ message: "Invalid email or password." });
});

router.post("/", [auth, isAdmin], async (req, res) => {
  const { error } = validate(req.body);
  if (error) return res.status(400).send({ message: error.details[0].message });

  if (!req.body.password)
    return res.status(400).send({ message: "Password is required!" });

  let user = await User.findOne({ email: req.body.email });
  if (user)
    return res
      .status(400)
      .send({ message: "User already exists with provided email." });

  user = new User(_.pick(req.body, ["name", "email", "password", "userRole"]));
  const salt = await bcrypt.genSalt(10);
  user.password = await bcrypt.hash(user.password, salt);
  await user.save();

  res.status(200).send({ id: user._id, name: user.name, email: user.email });
});

router.get("/:id", async (req, res) => {
  const user = await User.findById(req.params.id);
  res.status(200).send(user);
});

router.put("/:id", [validateObjectId, auth, isAdmin], async (req, res) => {
  const { error } = validate(req.body);
  if (error) return res.status(400).send({ message: error.details[0].message });

  const salt = await bcrypt.genSalt(10);

  if (req.body.password)
    var hashedPassword = await bcrypt.hash(req.body.password, salt);

  const withoutPassword = {
    name: req.body.name,
    email: req.body.email,
    userRole: req.body.userRole,
  };

  const withNewPassword = {
    name: req.body.name,
    email: req.body.email,
    password: hashedPassword,
    userRole: req.body.userRole,
  };

  const user = await User.findByIdAndUpdate(
    req.params.id,
    req.body.password ? withNewPassword : withoutPassword,
    { new: true }
  );

  if (!user) return res.status(404).send({ error: "No user found!" });

  res.send(user);
});

router.delete("/:id", [validateObjectId, auth, isAdmin], async (req, res) => {
  const user = await User.findByIdAndRemove(req.params.id);
  if (!user) return res.status(404).send({ message: "No user found!" });

  res.send(user);
});

module.exports = router;
