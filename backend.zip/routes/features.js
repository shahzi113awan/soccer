const express = require("express");
const router = express.Router();
const { Feature, validate } = require("../models/feature");
const { User } = require("../models/user");
const validateObjectId = require("../middleware/validateObjectId");
const upload = require("../middleware/upload");
const { auth } = require("../middleware/auth");
const { isContentAdmin } = require("../middleware/admin");
const { baseUrl } = require("../utils/helpers");
const fs = require("fs");
const mongoose = require("mongoose");

router.get("/", async (req, res) => {
  const { pageNumber, pageSize } = req.query;
  if (pageNumber && pageSize) {
    if (pageNumber < 1 || pageSize < 1 || pageSize > 25)
      return res.send({ error: "Invalid page number or page size." });
    const features = await Feature.find()
      .select("-content")
      .skip((pageNumber - 1) * pageSize)
      .limit(pageSize)
      .populate("authorId")
      .sort({ pinned: -1, createdAt: -1 });
    return res.send(features);
  }

  const features = await Feature.find()
    .select("-content")
    .sort({ pinned: -1, createdAt: -1 });
  res.send(features);
});

router.get("/:id", async (req, res) => {
  if (mongoose.isValidObjectId(req.params.id)) {
    const features = await Feature.find({ isScheduled: false, status: 'published' })
      .select("id title slug")
      .populate("authorId")
      .sort("-createdAt");

    const index = features.findIndex((n) => n.id === req.params.id);
    const prevIndex = features[index - 1];
    const nextIndex = features[index + 1];

    const response = {
      prev: prevIndex ? prevIndex : "",
      next: nextIndex ? nextIndex : "",
    };

    if (!response) return res.status(404).send({ error: "No feature found!" });
    return res.send(response);
  } else {
    const feature = await Feature.findOne({ slug: req.params.id });
    if (!feature) return res.status(404).send({ error: "No feature found!" });
    return res.send(feature);
  }
});

router.post(
  "/",
  [auth, isContentAdmin, upload.single("imageUrl")],
  async (req, res) => {
    try {
      let newImage = "";

      if (req.file) newImage = baseUrl() + req.file.path.replace("\\", "/");

      const { error } = validate(req.body);
      if (error) {
        let imagePath = newImage.replace(baseUrl(), "");
        if (imagePath)
          try {
            fs.unlinkSync("./" + imagePath);
          } catch (err) {}
        return res.status(400).send({ message: error.details[0].message });
      }

      // const slugExists = await Feature.findOne({ slug: req.body.slug }).select(
      //   "-content"
      // );

      // if (slugExists) {
      //   let imagePath = newImage.replace(baseUrl(), "");
      //   if (imagePath)
      //     try {
      //       fs.unlinkSync("./" + imagePath);
      //     } catch (err) {}
      //   return res
      //     .status(400)
      //     .send({ message: "Slug already exists. It should be unique." });
      // }

      const user = await User.findById(req.body.authorId);
      if (!user) return res.status(400).send({ error: "Invalid author" });
      req.body["featuredImage"] = newImage;
      const feature = new Feature(req.body);

      await feature.save();

      res.send(feature);
    } catch (error) {
      return res.status(400).send({
        message: error.code === 11000 ? "Slug Exist!" : error.message,
      });
    }
  }
);

router.put(
  "/:id",
  [auth, isContentAdmin, upload.single("imageUrl")],
  async (req, res) => {
    try {
      let newImage = "";
      let imagePath = "";

      if (req.file) newImage = baseUrl() + req.file.path?.replace("\\", "/");

      imagePath = newImage?.replace(baseUrl(), "");

      if (mongoose.isValidObjectId(req.params.id)) {
        if (imagePath)
          try {
            fs.unlinkSync("./" + imagePath);
          } catch (err) {}
        return res.status(400).send({
          message: "Send feature slug instead of an ID to update feature.",
        });
      }
      error = null;

      if (error) {
        if (imagePath)
          try {
            fs.unlinkSync("./" + imagePath);
          } catch (err) {}
        return res.status(400).send({ message: error.details[0].message });
      }

      const user = await User.findById(req.body.authorId);
      if (!user) {
        let imagePath = newImage?.replace(baseUrl(), "");
        if (imagePath)
          try {
            fs.unlinkSync("./" + imagePath);
          } catch (err) {}
        return res.status(400).send({ error: "Invalid author" });
      }

      const oldPost = await Feature.findOne({ slug: req.params.id });
      if (newImage) {
        let oldImage = oldPost?.featuredImage?.replace(baseUrl(), "");
        if (oldImage)
          try {
            fs.unlinkSync("./" + oldImage);
          } catch (err) {}
      } else {
        newImage = oldPost.featuredImage;
      }
      if (req.body.pinned) {
        req.body["pinned"] = 1;
      }
      //unpin other news

      if (req.body.pinned === 1) {
        await Feature.findOneAndUpdate(
          { pinned: 1 },
          {
            $set: {
              pinned: 0,
            },
          }
        );
      }
      if (
        oldPost.pinned === 1 &&
        (req.body.status === "draft" || req.body.status === "archive")
      ) {
        req.body["pinned"] = 0;
      }

      req.body["featuredImage"] = newImage;

      const feature = await Feature.findOneAndUpdate(
        { slug: req.params.id },
        req.body,
        { new: true }
      );

      if (!feature) return res.status(404).send({ error: "No feature found!" });

      res.send(feature);
    } catch (error) {
      return res.status(400).send({
        message: error.code === 11000 ? "Slug Exist!" : error.message,
      });
    }
  }
);

router.delete(
  "/:id",
  [auth, isContentAdmin, validateObjectId],
  async (req, res) => {
    try {
      const feature = await Feature.findByIdAndRemove(req.params.id);

      if (!feature)
        return res.status(404).send({ message: "No feature found!" });
      let imagePath = feature.featuredImage?.replace(baseUrl(), "");
      if (imagePath)
        try {
          fs.unlinkSync("./" + imagePath);
        } catch (err) {}
      res.send(feature);
    } catch (err) {
      res.status(400).send({ message: err.message });
    }
  }
);

module.exports = router;
