const express = require("express");
const router = express.Router();
const { Ad, validate } = require("../models/ad");
const { News } = require("../models/news");
const { Preview } = require("../models/preview");
const { Feature } = require("../models/feature");
const { User } = require("../models/user");
const validateObjectId = require("../middleware/validateObjectId");
const uploadMedia = require("../middleware/uploadMedia");
const { auth } = require("../middleware/auth");
const { isContentAdmin } = require("../middleware/admin");
const { baseUrl } = require("../utils/helpers");
const fs = require("fs");

router.get("/", async (req, res) => {
  const ads = await Ad.find().sort("-createdAt");
  res.status(200).send(ads);
});

router.get("/:id", validateObjectId, async (req, res) => {
  const ad = await Ad.findById(req.params.id);
  if (!ad) return res.status(404).send({ error: "No data found!" });

  const usaTime = new Date().toLocaleDateString("en-US", {
    timeZone: "America/New_York",
  });
  const adExpTime = new Date(ad?.expiryDate).getTime();

  if (!(adExpTime >= new Date(usaTime).getTime()))
    return res.status(400).send({ error: "Ad is expired." });

  res.status(200).send(ad);
});

router.post(
  "/",
  [auth, isContentAdmin, uploadMedia.single("url")],
  async (req, res) => {
    try {
   
      let newMedia = "";

    if (req.file) newMedia = baseUrl() + req.file.path.replace("\\", "/");

    const { error } = validate(req.body);
    if (error) {
      let mediaPath = newMedia.replace(baseUrl(), "");
      if (mediaPath)
        try {
          fs.unlinkSync("./" + mediaPath);
        } catch (err) {

          return res.status(400).send({ message: error.details[0].error });
        }
    }

    const creator = await User.findById(req.body.authorId);
    if (!creator) return res.status(400).send({ error: "Invalid creator" });

    const ad = new Ad({
      name: req.body.name,
      type: req.body.type,
      creator: {
        _id: creator.id,
        name: creator.name,
        userRole: creator.userRole,
      },
      url: newMedia,
      linkTo: req.body.linkTo,
      adFor: req.body.adFor,
      adPosition: req.body.adPosition,
      isActive: req.body.isActive,
      expiryDate: req.body.expiryDate,
      createdAt: Date.now(),
    });

    await ad.save();

    res.send(ad);
  
    } catch (error) {
      console.log(error)
      res.status(500).send({message:error.message})

    }
  }  
);

router.put(
  "/:id",
  [auth, isContentAdmin, validateObjectId, uploadMedia.single("url")],
  async (req, res) => {
    const shortCodeStrArr = req.body.shortcode.split(",");

    let newMedia = "";
    let mediaPath = "";

    if (req.file) newMedia = baseUrl() + req.file.path.replace("\\", "/");

    mediaPath = newMedia.replace(baseUrl(), "");

    const { error } = validate(req.body);
    if (error) {
      if (mediaPath)
        try {
          fs.unlinkSync("./" + mediaPath);
        } catch (err) {}
      return res.status(400).send({ message: error.details[0].message });
    }

    const creator = await User.findById(req.body.authorId);
    if (!creator) {
      let mediaPath = newMedia.replace(baseUrl(), "");
      if (mediaPath)
        try {
          fs.unlinkSync("./" + mediaPath);
        } catch (err) {}
      return res.status(400).send({ error: "Invalid creator" });
    }

    const oldAd = await Ad.findById(req.params.id);
    if (newMedia) {
      let oldMedia = oldAd?.url.replace(baseUrl(), "");
      if (oldMedia)
        try {
          fs.unlinkSync("./" + oldMedia);
        } catch (err) {

        }
    } else {
      newMedia = oldAd.url;
    }
let payload = {
  name: req.body.name,
  type: req.body.type,
  creator: {
    _id: creator.id,
    name: creator.name,
    userRole: creator.userRole,
  },
  shortcode: {
    id: shortCodeStrArr[0],
    type: shortCodeStrArr[1],
    location: shortCodeStrArr[2],
  },
  url: newMedia,
  adFor: req.body.adFor,
  adPosition: req.body.adPosition,
  isActive: req.body.isActive,
  expiryDate: req.body.expiryDate,
  lastUpdate: Date.now(),
}

if(!!req.body.linkTo){
  payload.linkTo = req.body.linkTo
}
    const ad = await Ad.findByIdAndUpdate(
      req.params.id,
      payload,
      { new: true }
    );

    if (!ad) return res.status(404).send({ error: "No data found!" });

    res.send(ad);
  }
);

router.delete(
  "/:id",
  [auth, isContentAdmin, validateObjectId],
  async (req, res) => {
    const ad = await Ad.findByIdAndRemove(req.params.id);
    // const ad = await Ad.findById(req.params.id);

    if (!ad) return res.status(404).send({ error: "No data found!" });
    const regex = new RegExp(`${ad._id}`, "i");

    if (ad.adFor === "news") {
      const news = await News.find({ sidebarAds: { $regex: regex } }).select(
        "-content"
      );
      news.forEach(async (item) => {
        let newAdsList = item.sidebarAds
          .split(",")
          .filter((a) => a !== ad.id)
          .join(",");
        await News.findByIdAndUpdate(item.id, {
          title: item.title,
          subTitle: item.subTitle,
          author: {
            _id: item.author._id,
            name: item.name,
          },
          sidebarAds: newAdsList,
        });
      });
    } else if (ad.adFor === "previews") {
      const previews = await Preview.find({
        sidebarAds: { $regex: regex },
      }).select("-content");
      previews.forEach(async (item) => {
        let newAdsList = item.sidebarAds
          .split(",")
          .filter((a) => a !== ad.id)
          .join(",");
        await Preview.findByIdAndUpdate(item.id, {
          title: item.title,
          subTitle: item.subTitle,
          author: {
            _id: item.author._id,
            name: item.name,
          },
          sidebarAds: newAdsList,
        });
      });
    } else if (ad.adFor === "features") {
      const features = await Feature.find({
        sidebarAds: { $regex: regex },
      }).select("-content");
      features.forEach(async (item) => {
        let newAdsList = item.sidebarAds
          .split(",")
          .filter((a) => a !== ad.id)
          .join(",");
        await Feature.findByIdAndUpdate(item.id, {
          title: item.title,
          subTitle: item.subTitle,
          author: {
            _id: item.author._id,
            name: item.name,
          },
          sidebarAds: newAdsList,
        });
      });
    }

    let mediaPath = ad.url.replace(baseUrl(), "");
    if (mediaPath)
      try {
        fs.unlinkSync("./" + mediaPath);
      } catch (err) {}
    res.send(ad);
  }
);

module.exports = router;
