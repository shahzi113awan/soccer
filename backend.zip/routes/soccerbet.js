const express = require("express");
const router = express.Router();
const { SoccerBet, validate } = require("../models/soccerbet");

const validateObjectId = require("../middleware/validateObjectId");
const { auth } = require("../middleware/auth");
const { isAdmin } = require("../middleware/admin");
const upload = require("../middleware/upload");
const { baseUrl } = require("../utils/helpers");
const fs = require("fs");

router.get("/", async (req, res) => {
  const data = await SoccerBet.find();
  res.send(data);
});

router.get("/:id", validateObjectId, async (req, res) => {
  const data = await SoccerBet.findById(req.params.id);
  res.send(data);
});

router.post("/", [auth, isAdmin, upload.single("image1")], async (req, res) => {
  let newImage = "";

  if (req.file) newImage = baseUrl() + req.file.path?.replace("\\", "/");

  const { error } = validate(req.body);
  if (error) {
    let imagePath = newImage?.replace(baseUrl(), "");
    if (imagePath)
      try {
        fs.unlinkSync("./" + imagePath);
      } catch (err) {}
    return res.status(400).send({ message: error.details[0].message });
  }

  const value = {
    image1: newImage,
    sections: req.body.value,
  };
  req.body["image"] = newImage;
  const data = new SoccerBet(req.body);

  await data.save();

  res.status(200).send(data);
});

router.put(
  "/:id",
  [auth, isAdmin, validateObjectId, upload.single("image1")],
  async (req, res) => {
    try {
      let newImage = "";
      let imagePath = "";

      if (req.file) newImage = baseUrl() + req.file.path?.replace("\\", "/");

      imagePath = newImage?.replace(baseUrl(), "");

      const { error } = validate(req.body);

      if (error) {
        if (imagePath)
          try {
            fs.unlinkSync("./" + imagePath);
          } catch (err) {}

        return res.status(400).send({ message: error.details[0].message });
      }

      const oldPost = await SoccerBet.findById(req.params.id);

      if (newImage) {
        let oldImage = oldPost?.image1?.replace(baseUrl(), "");

        if (oldImage)
          try {
            fs.unlinkSync("./" + oldImage);
          } catch (err) {}
      } else {
        newImage = oldPost.value.image1;
      }

      const value = {
        image1: newImage,
        sections: req.body.value,
      };
      req.body["image1"] = newImage;
      req.body["sections"] = req.body.value;

      const data = await SoccerBet.findByIdAndUpdate(req.params.id, req.body, {
        new: true,
      });

      if (!data) return res.status(404).send({ error: "Not found!" });

      res.send(data);
    } catch (err) {
      return res.status(400).send({ error: err.message });
    }
  }
);

// router.delete('/:id', [auth, isAdmin, validateObjectId], async (req, res) => {
//   const adBanner = await AdBanner.findByIdAndRemove(req.params.id);

//   if (!adBanner) return res.status(404).send({ message: 'No adBanner found!' });
//   let imagePath = adBanner.value.image.replace(baseUrl(), "");
//   if (imagePath) try { fs.unlinkSync("./" + imagePath) } catch (err) { }
//   res.send(adBanner);
// })

module.exports = router;
