const express = require("express");
const router = express.Router();
const { Page, validate } = require("../models/page");
const { User } = require("../models/user");
const validateObjectId = require("../middleware/validateObjectId");
const upload = require("../middleware/upload");
const { auth } = require("../middleware/auth");
const { isContentAdmin } = require("../middleware/admin");
const { baseUrl } = require("../utils/helpers");
const fs = require("fs");
const mongoose = require("mongoose");

router.get("/", async (req, res) => {
  const { pageNumber, pageSize } = req.query;
  if (pageNumber && pageSize) {
    if (pageNumber < 1 || pageSize < 1 || pageSize > 25)
      return res.send({ error: "Invalid page number or page size." });
    const page = await Page.find()
      .select("-content")
      .skip((pageNumber - 1) * pageSize)
      .limit(pageSize)
      .sort("-createdAt");
    return res.send(page);
  }

  const page = await Page.find().select("-content").sort("-createdAt");
  res.send(page);
});

router.get("/:id", async (req, res) => {
  if (mongoose.isValidObjectId(req.params.id)) {
    const page = await Page.find().select("id title slug").sort("-createdAt");

    const index = page.findIndex((n) => n.id === req.params.id);
    const prevIndex = page[index - 1];
    const nextIndex = page[index + 1];

    const response = {
      prev: prevIndex ? prevIndex : "",
      next: nextIndex ? nextIndex : "",
    };

    if (!response) return res.status(404).send({ error: "No page found!" });

    return res.send(response);
  } else {
    const page = await Page.findOne({ slug: req.params.id });
    if (!page) return res.status(404).send({ error: "No page found!" });
    res.send(page);
  }
});

router.post(
  "/",
  [auth, isContentAdmin, upload.single("image")],
  async (req, res) => {
    let newImage = "";

    if (req.file) newImage = baseUrl() + req.file.path.replace("\\", "/");

    const { error } = validate(req.body);
    if (error) {
      let imagePath = newImage.replace(baseUrl(), "");
      if (imagePath)
        try {
          fs.unlinkSync("./" + imagePath);
        } catch (err) {}
      return res.status(400).send({ message: error.details[0].message });
    }

    const slugExists = await Page.findOne({ slug: req.body.slug }).select(
      "-content"
    );

    if (slugExists) {
      let imagePath = newImage.replace(baseUrl(), "");
      if (imagePath)
        try {
          fs.unlinkSync("./" + imagePath);
        } catch (err) {}
      return res
        .status(400)
        .send({ message: "Slug already exists. It should be unique." });
    }

    const user = await User.findById(req.body.authorId);
    if (!user) return res.status(400).send({ error: "Invalid author" });

    const page = new Page({
      title: req.body.title,
      subTitle: req.body.subTitle,
      author: {
        _id: user._id,
        name: user.name,
        userRole: user.userRole,
      },
      content: req.body.content,
      excerpt: req.body.excerpt,
      category: req.body.category,
      featuredImage: newImage,
      slug: req.body.slug,
      isActive: req.body.isActive,
      scheduledPage: {
        isScheduled: req.body.isScheduled,
        scheduleTime: req.body.scheduleTime,
      },
      createdAt: Date.now(),
      meta_title: req.body.meta_title,
      meta_des: req.body.meta_des,
      meta_keyword: req.body.meta_keyword,
      meta_tag: req.body.meta_tag,
    });

    await page.save();

    res.send(page);
  }
);

router.put(
  "/:id",
  [auth, isContentAdmin, upload.single("image")],
  async (req, res) => {
    let newImage = "";
    let imagePath = "";

    if (req.file) newImage = baseUrl() + req.file.path.replace("\\", "/");

    imagePath = newImage.replace(baseUrl(), "");

    if (mongoose.isValidObjectId(req.params.id)) {
      if (imagePath)
        try {
          fs.unlinkSync("./" + imagePath);
        } catch (err) {}
      return res
        .status(400)
        .send({ message: "Send page slug instead of an ID to update page." });
    }

    const { error } = validate(req.body);
    if (error) {
      if (imagePath)
        try {
          fs.unlinkSync("./" + imagePath);
        } catch (err) {}
      return res.status(400).send({ message: error.details[0].message });
    }

    const user = await User.findById(req.body.authorId);
    if (!user) {
      if (imagePath)
        try {
          fs.unlinkSync("./" + imagePath);
        } catch (err) {}
      return res.status(400).send({ error: "Invalid author" });
    }

    const oldPost = await Page.findOne({ slug: req.params.id });
    if (newImage) {
      let oldImage = oldPost?.featuredImage.replace(baseUrl(), "");
      if (oldImage)
        try {
          fs.unlinkSync("./" + oldImage);
        } catch (err) {}
    } else {
      newImage = oldPost.featuredImage;
    }

    const page = await Page.findOneAndUpdate(
      { slug: req.params.id },
      {
        title: req.body.title,
        subTitle: req.body.subTitle,
        author: {
          _id: user._id,
          name: user.name,
          userRole: user.userRole,
        },
        content: req.body.content,
        excerpt: req.body.excerpt,
        category: req.body.category,
        tags: req.body.tags,
        featuredImage: newImage,
        slug: req.body.slug,
        isActive: req.body.isActive,
        scheduledPage: {
          isScheduled: req.body.isScheduled,
          scheduleTime: req.body.scheduleTime,
        },
        lastUpdate: Date.now(),
        meta_title: req.body.meta_title,
        meta_des: req.body.meta_des,
        meta_keyword: req.body.meta_keyword,
        meta_tag: req.body.meta_tag,
      },
      { new: true }
    );

    if (!page) return res.status(404).send({ error: "No page found!" });

    res.send(page);
  }
);

router.delete(
  "/:id",
  [auth, isContentAdmin, validateObjectId],
  async (req, res) => {
    const page = await Page.findByIdAndRemove(req.params.id);

    if (!page) return res.status(404).send({ message: "No page found!" });
    let imagePath = page.featuredImage.replace(baseUrl(), "");
    if (imagePath)
      try {
        fs.unlinkSync("./" + imagePath);
      } catch (err) {}
    res.send(page);
  }
);

module.exports = router;
