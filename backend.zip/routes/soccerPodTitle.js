const express = require("express");
const router = express.Router();
const { SoccerPodTitles, validateTitle } = require("../models/soccerPodTitle");

router.get("/", async (req, res) => {
  try {
    const data = await SoccerPodTitles.find();
    return res.send({ title: data[0]?.title || "" });
  } catch (err) {
    return res.status(400).send({ error: err.message });
  }
});

router.post("/", async (req, res) => {
  try {
    //check if there is no title
    const { error } = validateTitle(req.body);
    if (error) {
      return res.status(400).send({ message: error.details[0].message });
    }
    const title = await SoccerPodTitles.find().lean().exec();
    if (title.length > 0) {
      await SoccerPodTitles.findOneAndUpdate(title[0]._id, req.body);
      return res.status(200).send("success");
    } else {
      const data = SoccerPodTitles(req.body);
      await data.save();
      return res.status(200).send("success");
    }
  } catch (err) {
    return res.status(400).send({ error: err.message });
  }
});

module.exports = router;
