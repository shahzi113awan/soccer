var cron = require("node-cron");
const { League } = require("../models/league");
const { moreTeamsUsa } = require("../models/moreTeamUsa");
const { News } = require("../models/news");
const { Feature } = require("../models/feature");
const { Preview } = require("../models/preview");
const { SoccerPod } = require("../models/soccerPod");

/*
  Cron job for publishing -- Prevews with Draft/Publish logic
*/



cron.schedule("* * * * *", async () => {
  console.log("running a task every minute");

  const draftPreviews = await Preview.find({ isActive: false }).select(
    "-content"
  );

  const publishTodayPreviews = draftPreviews.filter(
    (p) => new Date(p.venueDateAndTime).getUTCDate() === new Date().getUTCDate()
  );

  publishTodayPreviews.forEach(async (item) => {
    await Preview.findByIdAndUpdate(item.id, {
      isActive: true,
      lastUpdate: Date.now(),
    });
  });
});
cron.schedule("* * * * *", async () => {
  console.log("running scheduler");
  const news = await News.find({
    publisheDate: { $lt: new Date().toISOString() },
    isScheduled: true,
  });

  const bulkArray = news?.map((item) => {
    return {
      updateOne: {
        filter: { _id: item._id },
        update: {
          $set: {
            isActive: true,
            isScheduled: false,
            publisheDate: null,
          },
        },
      },
    };
  });
  await News.bulkWrite(bulkArray);

  //same for moreTeamsUsa
  const moreTeamsUsafind = await Feature.find({
    publisheDate: { $lt: new Date() },
  });
  const bulkArrayTeams = moreTeamsUsafind?.map((item) => {
    return {
      updateOne: {
        filter: { _id: item._id },
        update: {
          $set: {
            isActive: true,
            isScheduled: false,
            publisheDate: null,
          },
        },
      },
    };
  });

  await Feature.bulkWrite(bulkArrayTeams);

  //same for leagues
  const leagues = await League.find({ publisheDate: { $lt: new Date() } });
  const bulkArrayLeagues = leagues?.map((item) => {
    return {
      updateOne: {
        filter: { _id: item._id },
        update: {
          $set: {
            isActive: true,
            isScheduled: false,
            publisheDate: null,
          },
        },
      },
    };
  });
  await League.bulkWrite(bulkArrayLeagues);
  //same for soccerPod
  const soccerPod = await SoccerPod.find({ publisheDate: { $lt: new Date() } });
  const bulkArraySoccerPod = soccerPod?.map((item) => {
    return {
      updateOne: {
        filter: { _id: item._id },
        update: {
          $set: {
            status: "published",
            isScheduled: false,
            publisheDate: null,
          },
        },
      },
    };
  });
  await SoccerPod.bulkWrite(bulkArraySoccerPod);
});
