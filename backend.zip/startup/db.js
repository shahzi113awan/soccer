const mongoose = require("mongoose");
const { logger } = require("../middleware/logger");
require("dotenv").config();

let db = "";

if (process.env.APP_NODE_ENV == "uat") {
  db = process.env.APP_DB_UAT;
} else if (process.env.APP_NODE_ENV == "production") {
  db = process.env.APP_DB_PROD;
} else {
  db = process.env.APP_DB_LOCAL;
}

mongoose
  .connect(db)
  .then(() => logger.info(`Mongodb ${process.env.NODE_ENV} Connected...`));
  

module.exports = mongoose;
