const { logger } = require("../middleware/logger");

module.exports = function () {
  process.on("uncaughtException", (ex) => {
    logger.log({ level: "error", message: ex.message });
    logger.on("finish", () => {
      process.exit(1);
    });
  });

  process.on("unhandledRejection", (ex) => {
    logger.log({ level: "error", message: ex.message });
    logger.on("finish", () => {
      process.exit(1);
    });
  });
};
