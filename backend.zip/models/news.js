const mongoose = require("mongoose");
const { UserSchema } = require("./user");
const Joi = require("joi");
const { string } = require("joi");
const Schema = mongoose.Schema;
const newsSchema = new Schema(
  {
    title: {
      type: String,
      required: true,
      trim: true,
      minlength: 2,
      maxlength: 120,
    },
    subTitle: {
      type: String,
      required: true,
      trim: true,
      minlength: 2,
      maxlength: 255,
    },
    authorId: {
      type: Schema.Types.ObjectId,
      ref: "User",
    },
    content: {
      type: String,
    },
    excerpt: {
      type: String,
      maxlength: 512,
    },
    category: {
      type: String,
      maxlength: 50,
    },
    tags: {
      type: [String],
      maxlength: 50,
    },
    featuredImage: {
      type: String,
      maxlength: 255,
    },
    commentsCount: {
      type: Number,
      min: 0,
      default: 0,
    },
    slug: {
      type: String,
      maxlength: 120,
      unique: true,
      required: true,
    },
    sidebarAds: {
      type: String,
      trim: true,
    },
    isActive: {
      type: Boolean,
      default: true,
    },
    scheduledPost: {
      type: Object,
    },
    createdAt: {
      type: Date,
    },
    lastUpdate: {
      type: Date,
    },
    order: {
      type: Number,
      default: -1,
    },
    draft: {
      type: Date,
    },
    publishedat: {
      type: Date,
    },
    meta_title: {
      type: String,
    },
    meta_des: {
      type: String,
    },
    meta_keyword: {
      type: String,
    },
    meta_tag: {
      type: [String],
      maxlength: 50,
    },
    altText: {
      type: String,
    },
    league: {
      type: Schema.Types.ObjectId,
      ref: "league",
    },
    isFeatured: {
      type: Boolean,
      default: false,
    },
    pinned: {
      type: Number,
      default: 0,
    },
    publisheDate: {
      type: Date,
    },
    isScheduled: {
      type: Boolean,
    },
    status: {
      type: String,
      enum: ["published", "archive", "draft"],
      default: "published",
    },
  },
  { timestamps: true }
);

const News = mongoose.model("News", newsSchema);

function validateNews(news) {
  const schema = Joi.object({
    title: Joi.string().min(2).max(255).required(),
    subTitle: Joi.string().min(2).max(255).required(),
    authorId: Joi.any().required(),
    content: Joi.string().allow(null, ""),
    excerpt: Joi.string().allow(null, ""),
    category: Joi.string().allow(null, ""),
    isFeatured: Joi.boolean(),
    tags: Joi.array().items(Joi.string().allow(null, "")),
    image: Joi.string().allow(null, ""),
    commentsCount: Joi.number().min(0),
    slug: Joi.string().required(),
    sidebarAds: Joi.string().allow(null, ""),
    isActive: Joi.boolean(),
    scheduledPost: Joi.object().allow(null, ""),
    postStatus: Joi.boolean(),
    order: Joi.number().integer().min(-1).default(-1).allow(null, ""),
    publishedat: Joi.date(),
    meta_title: Joi.string().allow(null, ""),
    meta_des: Joi.string().allow(null, ""),
    meta_keyword: Joi.string().allow(null, ""),
    meta_tag: Joi.array().items(Joi.string().allow(null, "")),
    altText: Joi.string().allow(null, ""),
    league: Joi.string().required("league is required"),
    pinned: Joi.number().allow(null, ""),
    publisheDate: Joi.date().allow(null, ""),
    isScheduled: Joi.boolean().allow(null, ""),
    _id: Joi.any().allow(null, ""),
    featuredImage: Joi.string().allow(null, ""),
    status: Joi.string()
      .valid("published", "archive", "draft")
      .default("draft"),
  });

  return schema.validate(news);
}
function updateValidation(news) {
  const schema = Joi.object({
    title: Joi.string().min(2).max(255).allow(null,""),
    subTitle: Joi.string().min(2).max(255).allow(null,""),
    authorId: Joi.any().allow(null,""),
    content: Joi.string().allow(null, ""),
    excerpt: Joi.string().allow(null, ""),
    category: Joi.string().allow(null, ""),
    isFeatured: Joi.boolean(),
    tags: Joi.array().items(Joi.string().allow(null, "")),
    image: Joi.string().allow(null, ""),
    commentsCount: Joi.number().min(0),
    slug: Joi.string().allow(null,""),
    sidebarAds: Joi.string().allow(null, ""),
    isActive: Joi.boolean(),
    scheduledPost: Joi.object().allow(null, ""),
    postStatus: Joi.boolean(),
    order: Joi.number().integer().min(-1).default(-1).allow(null, ""),
    publishedat: Joi.date(),
    meta_title: Joi.string().allow(null, ""),
    meta_des: Joi.string().allow(null, ""),
    meta_keyword: Joi.string().allow(null, ""),
    meta_tag: Joi.array().items(Joi.string().allow(null, "")),
    altText: Joi.string().allow(null, ""),
    league: Joi.string().allow(null,""),
    pinned: Joi.number().allow(null, ""),
    publisheDate: Joi.date().allow(null, ""),
    isScheduled: Joi.boolean().allow(null, ""),
    _id: Joi.any().allow(null, ""),
    featuredImage: Joi.string().allow(null, ""),
    status: Joi.string()
      .valid("published", "archive", "draft")
      .default("draft"),
  });

  return schema.validate(news);
}

exports.News = News;
exports.validate = validateNews;
exports.validateUpdate  = updateValidation
