const Joi = require("joi");
const mongoose = require("mongoose");
const jwt = require("jsonwebtoken");
require("dotenv").config();

const userSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
    trim: true,
    minlength: 2,
    maxlength: 200,
  },
  email: {
    type: String,
    trim: true,
    minlength: 5,
    maxlength: 120,
  },
  password: {
    type: String,
    minlength: 5,
    maxlength: 255,
  },
  userRole: {
    type: String,
    minlength: 2,
    maxlength: 20,
    enum: ["Super Admin", "Admin", "Content Admin", "View Only"],
    required: true,
  },
});

userSchema.methods.generateAuthToken = function () {
  const token = jwt.sign(
    { _id: this._id, name: this.name, userRole: this.userRole },
    process.env.APP_JWT_KEY,
    { expiresIn: "1d" }
  );
  return token;
};

const User = mongoose.model("User", userSchema);

function validateUser(user) {
  const schema = Joi.object({
    name: Joi.string().required(),
    email: Joi.string().email(),
    password: Joi.string(),
    userRole: Joi.string()
      .valid("Admin", "Content Admin", "View Only")
      .required(),
  });
  return schema.validate(user);
}

function validateLoginUser(user) {
  const schema = Joi.object({
    email: Joi.string().email().required(),
    password: Joi.string().required(),
  });
  return schema.validate(user);
}

exports.User = User;
exports.UserSchema = userSchema;
exports.validate = validateUser;
exports.validateLoginUser = validateLoginUser;
