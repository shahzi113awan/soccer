const { string } = require("joi");
const Joi = require("joi");
const mongoose = require("mongoose");

const soccerBetSchema = new mongoose.Schema({
  key: {
    type: String,

    trim: true,
    minlength: 2,
    maxlength: 200,
  },
  value: {
    type: Object,
  },
  heading: {
    type: String,
  },
  description: {
    type: String,
  },
  link: {
    type: String,
  },
  image1: {
    type: String,
  },
});

const SoccerBet = mongoose.model("SoccerBet", soccerBetSchema);

function validatesoccerBet(soccerBet) {
  const schema = Joi.object({
    key: Joi.string().min(2).max(200),
    value: Joi.string(),
    image1: Joi.string().allow(null, ""),
    heading: Joi.string().allow(null, ""),
    description: Joi.string().allow(null, ""),
    link: Joi.string().allow(null, ""),
  });
  return schema.validate(soccerBet);
}

exports.SoccerBet = SoccerBet;
exports.moresoccerBetSchema = soccerBetSchema;
exports.validate = validatesoccerBet;

// const { string } = require("joi");
// const Joi = require("joi");
// const mongoose = require("mongoose");

// const adBannersSchema = new mongoose.Schema({
//   key: {
//     type: String,
//     required: true,
//     trim: true,
//     minlength: 2,
//     maxlength: 200,
//   },
//   value: {
//     type: Object,
//     required: true,
//   }
// });

// const AdBanner = mongoose.model("AdBanner", adBannersSchema);

// function validateAdBanner(adBanner) {
//   const schema = Joi.object({
//     key: Joi.string().required().min(2).max(200),
//     value: Joi.string().required(),
//     image: Joi.string().allow(null, "")
//   });
//   return schema.validate(adBanner);
// }

// exports.AdBanner = AdBanner;
// exports.adBannersSchema = adBannersSchema;
// exports.validate = validateAdBanner;
