const { string } = require("joi");
const Joi = require("joi");
const mongoose = require("mongoose");

const fanduelSchema = new mongoose.Schema({
  key: {
    type: String,
    trim: true,
    minlength: 2,
    maxlength: 200,
  },
  value: {
    type: Object,
  },
  heading: {
    type: String,
  },

  link: {
    type: String,
    
  },
});

const Fanduel = mongoose.model("Fanduel", fanduelSchema);

function validateFanduel(fanduel) {
  const schema = Joi.object({
    key: Joi.string().min(2).max(200),
    value: Joi.string(),
    image: Joi.string().allow(null, ""),
    heading: Joi.string().allow(null, ""),
    link: Joi.string().allow(null, ""),
  });
  return schema.validate(fanduel);
}

exports.Fanduel = Fanduel;
exports.morefanduelSchema = fanduelSchema;
exports.validate = validateFanduel;
