const Joi = require("joi");
const mongoose = require("mongoose");

const soccerPodTitle = new mongoose.Schema(
  {
    title: {
      type: String,
      required: true,
    },
  },
  { timestamps: true }
);

const pod = mongoose.model("PodTitle", soccerPodTitle);

function validateTitle(pod) {
  const schema = Joi.object({
    title: Joi.string().required(),
  });
  return schema.validate(pod);
}

exports.SoccerPodTitles = pod;
exports.moresoccerPodTitle = soccerPodTitle;
exports.validateTitle = validateTitle;
