const mongoose = require("mongoose");
const { UserSchema } = require("./user");
const Joi = require("joi");

const featureSchema = new mongoose.Schema(
  {
    title: {
      type: String,
      required: true,
      trim: true,
      minlength: 2,
      maxlength: 120,
    },
    subTitle: {
      type: String,
      required: true,
      trim: true,
      minlength: 2,
      maxlength: 255,
    },
    authorId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
    },
    content: {
      type: String,
    },
    excerpt: {
      type: String,
      maxlength: 512,
    },
    category: {
      type: String,
      maxlength: 50,
    },
    tags: {
      type: [String],
      maxlength: 50,
    },
    featuredImage: {
      type: String,
      maxlength: 255,
    },
    commentsCount: {
      type: Number,
      min: 0,
      default: 0,
    },
    slug: {
      type: String,
      maxlength: 120,
      unique: true,
      required: true,
    },
    sidebarAds: {
      type: String,
      trim: true,
    },
    isActive: {
      type: Boolean,
      default: true,
    },
    scheduledFeature: {
      type: Object,
    },
    meta_title: {
      type: String,
    },
    meta_des: {
      type: String,
    },
    meta_keyword: {
      type: String,
    },

    meta_tag: {
      type: [String],
      maxlength: 50,
    },
    altText: {
      type: String,
    },
    createdAt: {
      type: Date,
    },
    lastUpdate: {
      type: Date,
    },
    publisheDate: {
      type: Date,
      date: Date.now,
    },
    isScheduled: {
      type: Boolean,
      default: false,
    },

    pinned: {
      type: Number,
      default: false,
    },
    status: {
      type: String,
      enum: ["published", "archive", "draft"],
      default: "published",
    },
  },
  { timestamps: true }
);

const Feature = mongoose.model("Feature", featureSchema);

function validateFeature(feature) {
  const schema = Joi.object({
    title: Joi.string().min(2).max(255).required(),
    subTitle: Joi.string().min(2).max(255).required(),
    authorId: Joi.string().required(),
    content: Joi.string().allow(null, ""),
    excerpt: Joi.string().allow(null, ""),
    category: Joi.string().allow(null, ""),
    tags: Joi.array().items(Joi.string().allow(null, "")),
    imageUrl: Joi.string().allow(null, ""),
    commentsCount: Joi.number().min(0),
    slug: Joi.string().required(),
    sidebarAds: Joi.string().allow(null, ""),
    isActive: Joi.boolean(),
    scheduledFeature: Joi.object().allow(null, ""),
    postStatus: Joi.boolean(),
    meta_title: Joi.string().allow(null, ""),
    meta_des: Joi.string().allow(null, ""),
    meta_keyword: Joi.string().allow(null, ""),
    altText: Joi.string().allow(null, ""),
    meta_tag: Joi.array().items(Joi.string().allow(null, "")),
    publisheDate: Joi.date().allow(null, ""),
    isScheduled: Joi.boolean(),
    pinned: Joi.number(),
    _id: Joi.string().allow(null, ""),
    status: Joi.string()
      .valid("published", "archive", "draft")
      .default("draft"),
  });

  return schema.validate(feature);
}

exports.Feature = Feature;
exports.validate = validateFeature;
