const { string } = require("joi");
const Joi = require("joi");
const mongoose = require("mongoose");

const moreTeamsUsaSchema = new mongoose.Schema({
  key: {
    type: String,
    required: true,
    trim: true,
    minlength: 2,
    maxlength: 200,
  },
  value: {
    type: Object,
  },

  heading: {
    type: String,
  },
  description: {
    type: String,
  },
  authorName: {
    type: String,
  },
  pinned: {
    type: Number,
    default: false,
  },
  publisheDate: {
    type: Date,
    default: Date.now,
  },
  status: {
    type: String,
    default: "published",
    enum: ["draft", "published", "archived"],
  },
});

const moreTeamsUsa = mongoose.model("moreTeamsUsa", moreTeamsUsaSchema);

function validatemoreTeamsUsa(moreTeamsUsa) {
  const schema = Joi.object({
    key: Joi.string().required().min(2).max(200),
    value: Joi.string(),
    image1: Joi.string().allow(null, ""),
    heading: Joi.string().allow(null, ""),
    description: Joi.string().allow(null, ""),
    authorName: Joi.string().allow(null, ""),
    pinned: Joi.number().allow(null, ""),
    publisheDate: Joi.date().allow(null, ""),
    status: Joi.string().allow(null, ""),
  });
  return schema.validate(moreTeamsUsa);
}

exports.moreTeamsUsa = moreTeamsUsa;
exports.moreTeamsUsaSchema = moreTeamsUsaSchema;
exports.validate = validatemoreTeamsUsa;
