const mongoose = require("mongoose");
const Joi = require("joi");
const { UserSchema } = require("./user");
const Schema = mongoose.Schema;

const childSchema = new Schema(
  {
    title: {
      type: String,
      required: true,
      trim: true,
      minlength: 2,
      maxlength: 120,
    },
    subTitle: {
      type: String,
      required: true,
      trim: true,
      minlength: 2,
      maxlength: 255,
    },
    author: {
      type: UserSchema,
    },
    content: {
      type: String,
    },
    excerpt: {
      type: String,
      maxlength: 512,
    },
    category: {
      type: String,
      maxlength: 50,
    },
    tags: {
      type: [String],
      maxlength: 50,
    },
    featuredImage: {
      type: String,
      maxlength: 255,
    },
    commentsCount: {
      type: Number,
      min: 0,
      default: 0,
    },
    slug: {
      type: String,
      maxlength: 255,
      unique: true,
      required: true,
    },
    sidebarAds: {
      type: String,
      trim: true,
    },
    venueLocation: {
      type: String,
      trim: true,
      maxlength: 120,
    },
    venueDateAndTime: {
      type: String,
      trim: true,
      
    },
    isActive: {
      type: Boolean,
      default: true,
    },
    scheduledPreview: {
      type: Object,
    },
    createdAt: {
      type: Date,
    },
    lastUpdate: {
      type: Date,
    },
    order: {
      type: Number,
      default: -1,
    },
    meta_title: {
      type: String,
    },
    altText: {
      type: String,
    },
    meta_des: {
      type: String,
    },
    meta_keyword: {
      type: String,
    },
    meta_tag: {
      type: [String],
      maxlength: 50,
    },
    league: {
      type: Schema.Types.ObjectId,
      ref: "league",
    },
    featuredImage: {
      type: String,
    },
    status: {
      type: String,
      enum: ["published", "archive", "draft"],
      default: "published",
    },
  },
  { timestamps: true }
);

const Child = mongoose.model("child", childSchema);

function validatechild(child) {
  const schema = Joi.object({
    title: Joi.string().min(2).max(120).required(),
    subTitle: Joi.string().min(2).max(255).required(),
    authorId: Joi.objectId(),
    content: Joi.string().allow(null, ""),
    excerpt: Joi.string().allow(null, ""),
    category: Joi.string().allow(null, ""),
    altText: Joi.string().allow(null, ""),
    tags: Joi.array().items(Joi.string().allow(null, "")),
    image: Joi.string().allow(null, ""),
    commentsCount: Joi.number().min(0),
    slug: Joi.string().required(),
    sidebarAds: Joi.string().allow(null, ""),
    venueLocation: Joi.string().max(120).allow(null, ""),
    venueDateAndTime: Joi.string().required(),
    isActive: Joi.boolean(),
    scheduledPreview: Joi.object().allow(null, ""),
    previewStatus: Joi.boolean(),
    createdAt: Joi.date(),
    lastUpdate: Joi.date(),
    league: Joi.objectId(),
    featuredImage: Joi.string().allow(null, ""),
    order: Joi.number().integer().min(-1).default(-1).allow(null, ""),
    meta_title: Joi.string().allow(null, ""),
    meta_des: Joi.string().allow(null, ""),
    meta_keyword: Joi.string().allow(null, ""),
    meta_tag: Joi.array().items(Joi.string().allow(null, "")),
    status: Joi.string()
      .valid("published", "archive", "draft")
      .default("draft"),
  });

  return schema.validate(child);
}

exports.Child = Child;
exports.childSchema = childSchema;
exports.validate = validatechild;
