const Joi = require("joi");
const mongoose = require("mongoose");
const { UserSchema } = require("./user");

const adsSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
    trim: true,
    minlength: 2,
    maxlength: 120,
  },
  type: {
    type: String,
    required: true,
    trim: true,
    minlength: 2,
    maxlength: 50,
  },
  creator: {
    type: UserSchema,
    required: true,
  },
  shortcode: {
    type: Object,
  },
  url: {
    type: String,
    trim: true,
  },
  linkTo: {
    type: String,
    // required: true,
    // trim: true,
    default:""
    // minlength: 2,
    // maxlength: 250
  },
  adFor: {
    type: String,
    required: true,
    trim: true,
    minlength: 2,
    maxlength: 120,
  },
  adPosition: {
    type: String,
    required: true,
    trim: true,
    minlength: 2,
    maxlength: 120,
  },
  isActive: {
    type: Boolean,
    default: true,
  },
  expiryDate: {
    type: Date,
    required: true,
  },
  createdAt: {
    type: Date,
  },
  lastUpdate: {
    type: Date,
  },
});

const Ad = mongoose.model("Ads", adsSchema);

function validateAd(ad) {
  const schema = Joi.object({
    name: Joi.string().trim().required().min(2).max(120),
    type: Joi.string().trim().required().min(2).max(50),
    authorId: Joi.objectId().required(),
    shortcode: Joi.string().allow(null, ''),
    url: Joi.string().allow(null, ''),
    linkTo: Joi.string().allow(null,''),
    adFor: Joi.string().trim().required().min(2).max(120),
    adPosition: Joi.string().trim().required().min(2).max(120),
    isActive: Joi.boolean(),
    expiryDate: Joi.date().required(),
    createdAt: Joi.date(),
    lastUpdate: Joi.date(),
  });
  return schema.validate(ad);
}

exports.Ad = Ad;
exports.adsSchema = adsSchema;
exports.validate = validateAd;
