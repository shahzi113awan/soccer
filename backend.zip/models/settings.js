const { string } = require("joi");
const Joi = require("joi");
const mongoose = require("mongoose");

const settingsSchema = new mongoose.Schema({
  key: {
    type: String,
    required: true,
    trim: true,
    minlength: 2,
    maxlength: 200,
  },
  value: {
    type: Object,
    required: true,
  },
  text: {
    type: String,
  },
  meta_title: {
    type: String,
  },
  meta_des: {
    type: String,
  },
  meta_keyword: {
    type: String,
  },
  meta_tag: {
    type: [String],
    maxlength: 50,
  },
});

const Setting = mongoose.model("Setting", settingsSchema);

function validateSetting(setting) {
  const schema = Joi.object({
    key: Joi.string().required().min(2).max(200),
    value: Joi.string().required(),
    bannerImage: Joi.string().allow(null, ""),
    text: Joi.string().allow(null, ""),
    image: Joi.string().allow(null, ""),
    meta_title: Joi.string().allow(null, ""),
    meta_des: Joi.string().allow(null, ""),
    meta_keyword: Joi.string().allow(null, ""),
    meta_tag: Joi.array().items(Joi.string().allow(null, "")),
  });
  return schema.validate(setting);
}

exports.Setting = Setting;
exports.settingsSchema = settingsSchema;
exports.validate = validateSetting;
