const Joi = require("joi");
const mongoose = require("mongoose");

const subscriberSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
    trim: true,
    minlength: 2,
    maxlength: 255,
  },
  email: {
    type: String,
    trim: true,
    required: true,
    unique: true,
    minlength: 5,
    maxlength: 255,
  },
  favoriteTeam: {
    type: String,
    trim: true,
    maxlength: 120,
  },
  favClubTeam: {
    type: String,
    trim: true,
    maxlength: 120,
  },
});

const Subscriber = mongoose.model("Subscriber", subscriberSchema);

function validateSub(user) {
  const schema = Joi.object({
    name: Joi.string().trim().required().min(2).max(255),
    email: Joi.string().trim().email().required().min(5).max(255),
    favoriteTeam: Joi.string().allow(null, "").trim().max(120),
    favClubTeam: Joi.string().allow(null, "").trim().max(120),
  });
  return schema.validate(user);
}

exports.Subscriber = Subscriber;
exports.subscriberSchema = subscriberSchema;
exports.validate = validateSub;
