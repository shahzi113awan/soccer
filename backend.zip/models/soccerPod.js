const Joi = require("joi");
const mongoose = require("mongoose");

const soccerPodSchema = new mongoose.Schema(
  {
    title: {
      type: String,
      required: true,
    },
    slug: {
      type: String,
      required: true,
      unique: true,
    },
    author: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
    },
    mediaLink: {
      type: String,
      required: true,
    },
    mediaType: {
      type: String,
      enum: ["video", "audio"],
      required: true,
    },
    thumbnail: {
      type: String,
      default: "",
    },

    status: {
      type: String,
      enum: ["published", "archive", "draft"],
      default: "published",
    },
    publisheDate: {
      type: Date,
      default: null,
    },
    isScheduled: {
      type: Boolean,
      default: false,
    },
    content: {
      type: String,
      default: null,
    },
    previousPod: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "SoccerPod",
      default: null,
    },
    nextPod: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "SoccerPod",
      default: null,
    },
  },
  { timestamps: true }
);

const SoccerPod = mongoose.model("SoccerPod", soccerPodSchema);

function validatesoccerPod(soccerPod) {
  const schema = Joi.object({
    title: Joi.string().required(),
    slug: Joi.string().required(),
    author: Joi.string().required(),
    mediaLink: Joi.string().allow(null, ""),
    mediaType: Joi.string().allow(null, ""),
    thumbnail: Joi.string(),
    status: Joi.string(),
    image: Joi.string().allow(null, ""),
    publisheDate: Joi.string().allow(null, ""),
    isScheduled: Joi.boolean().allow(null, ""),
    content: Joi.string().allow(null, ""),
    previousPod: Joi.string().allow(null, ""),
    nextPod: Joi.string().allow(null, ""),
  });
  return schema.validate(soccerPod);
}

exports.SoccerPod = SoccerPod;
exports.moresoccerPodSchema = soccerPodSchema;
exports.validate = validatesoccerPod;

// const { string } = require("joi");
// const Joi = require("joi");
// const mongoose = require("mongoose");

// const adBannersSchema = new mongoose.Schema({
//   key: {
//     type: String,
//     required: true,
//     trim: true,
//     minlength: 2,
//     maxlength: 200,
//   },
//   value: {
//     type: Object,
//     required: true,
//   }
// });

// const AdBanner = mongoose.model("AdBanner", adBannersSchema);

// function validateAdBanner(adBanner) {
//   const schema = Joi.object({
//     key: Joi.string().required().min(2).max(200),
//     value: Joi.string().required(),
//     image: Joi.string().allow(null, "")
//   });
//   return schema.validate(adBanner);
// }

// exports.AdBanner = AdBanner;
// exports.adBannersSchema = adBannersSchema;
// exports.validate = validateAdBanner;
