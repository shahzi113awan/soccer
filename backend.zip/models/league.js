const mongoose = require("mongoose");
const Joi = require("joi");
const { UserSchema } = require("./user");
const { childSchema } = require("./childs");

const leagueSchema = new mongoose.Schema({
  title: {
    type: String,
    required: true,
    trim: true,
    minlength: 2,
    maxlength: 120,
  },

  author: {
    type: UserSchema,
    required: true,
  },

  slug: {
    type: String,
    maxlength: 255,
    unique: true,
    required: true,
  },
  isActive: {
    type: Boolean,
    default: true,
  },
  createdAt: {
    type: Date,
  },
  lastUpdate: {
    type: Date,
  },
  publisheDate: {
    type: Date,
    default: Date.now,
  },
  status: {
    type: String,
    enum: ["published", "archive", "draft"],
    default: "published",
  },
  order: {
    type: Number,
    default: 0,
  },
});
leagueSchema.pre("save", async function (next) {
  // Check if the document is new (not yet saved to the database)
  if (this.isNew) {
    try {
      // Find the latest document in the collection to get the current max numberField value
      const latestDocument = await this.constructor.findOne(
        {},
        {},
        { sort: { order: -1 } }
      );
      const currentMaxorder = latestDocument ? latestDocument.order : 0;

      // Increment the order by 1 for the new document
      this.order = currentMaxorder + 1;
    } catch (err) {
      console.error("Error finding latest document:", err);
    }
  }

  next();
});
const League = mongoose.model("league", leagueSchema);

function validateleague(league) {
  const schema = Joi.object({
    title: Joi.string().min(2).max(120).required(),
    authorId: Joi.objectId().required(),
    slug: Joi.string().required(),
    isActive: Joi.boolean(),
    previewStatus: Joi.boolean(),
    createdAt: Joi.date(),
    lastUpdate: Joi.date(),

    publisheDate: Joi.date().allow(null, ""),
    status: Joi.string()
      .valid("published", "archive", "draft")
      .default("draft"),
  });

  return schema.validate(league);
}

exports.League = League;
exports.validate = validateleague;
