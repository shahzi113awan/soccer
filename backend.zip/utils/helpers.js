require('dotenv').config();

const baseUrl = () => {
  let baseURL = "";

  if (process.env.APP_NODE_ENV === "uat") {
    baseURL = process.env.APP_UAT_URL
  } else if (process.env.APP_NODE_ENV === "production") {
    baseURL = process.env.APP_PROD_URL
  } else {
    baseURL = process.env.APP_LOCAL_URL
  }

  return baseURL;
};

module.exports = { baseUrl };