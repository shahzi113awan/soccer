const { SoccerPod, validate } = require("../models/soccerPod");
const { SoccerPodTitles, validateTitle } = require("../models/soccerPodTitle");
const { User } = require("../models/user");
const { baseUrl } = require("../utils/helpers");
const fs = require("fs");
const mongoose = require("mongoose");

const getAll = async (req, res) => {
  try {
    const { pageNumber, pageSize } = req.query;

    if (pageNumber < 1 || pageSize < 1 || pageSize > 25)
      return res.send({ error: "Invalid page number or page size." });
    const soccerPods = await SoccerPod.find()
      .skip((pageNumber - 1) * pageSize)
      .limit(pageSize)
      .sort("-createdAt")
      .populate("author")
      .populate("nextPod");
    return res.send(soccerPods);
  } catch (error) {
    return res.status(500).send({ error: error.message });
  }
};

const getOne = async (req, res) => {
  try {
    if (mongoose.isValidObjectId(req.params.id)) {
      const soccerPod = await SoccerPod.findById(req.params.id)
        .populate("author")
        .populate("nextPod");
      if (!soccerPod)
        return res.status(404).send({ error: "No soccerPod found!" });
      res.send(soccerPod);
    } else {
      const soccerPod = await SoccerPod.findOne({
        slug: req.params.id,
      })
        .populate("author")
        .populate("nextPod");
      if (!soccerPod)
        return res.status(404).send({ error: "No soccerPod found!" });
      res.send(soccerPod);
    }
  } catch (error) {
    return res.status(500).send({ error: error.message });
  }
};

const create = async (req, res) => {
  try {
    const { error } = validate(req.body);
    if (error) {
      return res.status(400).send({ message: error.details[0].message });
    }
    let newImage = "";

    if (req.file) {
      newImage = baseUrl() + req.file.path?.replace("\\", "/");
      req.body["thumbnail"] = newImage;
    }
    //find previous and next Pod
    const next = await SoccerPod.find().sort("-createdAt").limit(1);
    if (next[0]?._id) {
      req.body["nextPod"] = next[0]?._id;
    }

    const pods = new SoccerPod(req.body);

    await pods.save();

    res.send(pods);
  } catch (error) {
    return res
      .status(500)
      .send({ message: error.code === 11000 ? "Slug Exist!" : error.message });
  }
};

const update = async (req, res) => {
  try {
    const { error } = validate(req.body);
    if (error) {
      return res.status(400).send({ message: error.details[0].message });
    }
    let newImage = "";
    let imagePath = "";

    if (req.file) {
      newImage = baseUrl() + req.file?.path?.replace("\\", "/");
      imagePath = newImage.replace(baseUrl(), "");
      req.body["thumbnail"] = newImage;
    }
    if (req.body.pinned) {
      req.body["pinned"] = 1;
    }
    //unpin other news
    if (req.body.pinned === 1) {
      await SoccerPod.findOneAndUpdate(
        { pinned: 1 },
        {
          $set: {
            pinned: 0,
          },
        }
      );
    }

    const news = await SoccerPod.findOneAndUpdate(
      { slug: req.params.id },

      req.body,

      { new: true }
    );

    if (!news) return res.status(404).send({ error: "No news found!" });

    res.send(news);
  } catch (error) {
    return res
      .status(500)
      .send({ message: error.code === 11000 ? "Slug Exist!" : error.message });
  }
};

const remove = async (req, res) => {
  try {
    const news = await SoccerPod.findByIdAndDelete(req.params.id);
    if (!news) return res.status(404).send({ error: "No news found!" });
    res.status(200).send({ message: "News deleted successfully!" });
  } catch (error) {
    return res.status(500).send({ message: error.message });
  }
};

//title
const getTitle = async (req, res) => {
  try {
    const title = await SoccerPodTitles.find();
    // if (!title) return res.status(404).send({ error: "No title found!" });
    res.send(title[0]);
  } catch (error) {
    return res.status(500).send({ error: error.message });
  }
};

const createTitle = async (req, res) => {
  try {
    const { error } = validateTitle(req.body);
    if (error) {
      return res.status(400).send({ message: error.details[0].message });
    }
    const title = await SoccerPodTitles.findOneAndUpdate(
      { _id: req.params.id },
      req.body,
      { new: true },
      {
        upsert: true,
      }
    );

    if (!title) return res.status(404).send({ error: "No title found!" });

    res.send(title);
  } catch (error) {
    return res.status(500).send({ message: error.message });
  }
};

module.exports = {
  getAll,
  getOne,
  create,
  update,
  remove,
  getTitle,
  createTitle,
};
