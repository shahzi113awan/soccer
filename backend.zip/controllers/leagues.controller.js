const { League, validate } = require("../models/league");
const { User } = require("../models/user");
const { baseUrl } = require("../utils/helpers");
const fs = require("fs");
const mongoose = require("mongoose");

const getAll = async (req, res) => {
  const { pageNumber, pageSize, pub } = req.query;
  const params = {};
  if (pageNumber && pageSize) {
    if (pageNumber < 1 || pageSize < 1 || pageSize > 25)
      return res.send({ error: "Invalid page number or page size." });
    const leagues = await League.find()
      .select("-content")
      .skip((pageNumber - 1) * pageSize)
      .limit(pageSize)
      .sort("createdAt");
     
    return res.send(leagues);
  }
  if (pub) {
    params.status = "published";
  }
   
  const leagues = await League.find({ ...params })
    .select("-content")
    .sort("createdAt");
  res.send(leagues);
};

const getOne = async (req, res) => {
  // if (mongoose.isValidObjectId(req.params.id)) {
  //   const leagues = await League.find()
  //     .select("id title slug")
  //     .sort("-createdAt");

  //   const index = leagues.findIndex((n) => n.id === req.params.id);
  //   const prevIndex = previews[index - 1];
  //   const nextIndex = previews[index + 1];

  //   const response = {
  //     prev: prevIndex ? prevIndex : "",
  //     next: nextIndex ? nextIndex : "",
  //   };

  //   if (!response) return res.status(404).send({ error: "Not found!" });
  //   return res.send(response);
  // } else {
    const league = await League.findOne({ slug: req.params.id });
    if (!league) return res.status(404).send({ error: "No league found!" });
    res.send(league);
  }
// };
const create = async (req, res) => {
  let newImage = "";

  if (req.file) newImage = baseUrl() + req.file.path.replace("\\", "/");

  // const { error } = validate(req.body);
  // if (error) {
  //   let imagePath = newImage.replace(baseUrl(), "");
  //   if (imagePath)
  //     try {
  //       fs.unlinkSync("./" + imagePath);
  //     } catch (err) {}
  //   return res.status(400).send({ message: error.details[0].message });
  // }

  const slugExists = await League.findOne({ slug: req.body.slug }).select(
    "-content"
  );

  if (slugExists) {
    let imagePath = newImage.replace(baseUrl(), "");
    if (imagePath)
      try {
        fs.unlinkSync("./" + imagePath);
      } catch (err) {}
    return res
      .status(400)
      .send({ message: "Slug already exists. It should be unique." });
  }

  const user = await User.findById(req.body.authorId);
  if (!user) return res.status(400).send({ error: "Invalid author" });

  const league = new League({
    title: req.body.title,
    author: {
      _id: user._id,
      name: user.name,
      userRole: user.userRole,
    },
    slug: req.body.slug,
    isActive: req.body.isActive,
    createdAt: Date.now(),
    children: req.body.children,
  });

  await league.save();

  res.send(league);
};

 

//Update Bulk array

const updateBulk = async (req, res) => {
console.log("nsakn")
   try{
    console.log(req.body)
    await League.bulkWrite(req.body.data);
   return res.send({message:"Updated Successfully"})
   }catch(err){
    console.log(err)
   return res.status(400).send({error:err.message})
    }
    };


 const update  =  async (req, res) => {
    try {
      let newImage = "";
      let imagePath = "";
  
      if (req.file) newImage = baseUrl() + req.file.path?.replace("\\", "/");
  
      imagePath = newImage.replace(baseUrl(), "");
  
      if (mongoose.isValidObjectId(req.params.id)) {
        if (imagePath)
          try {
            fs.unlinkSync("./" + imagePath);
          } catch (err) {}
        return res.status(400).send({
          message: "Send preview slug instead of an ID to update preview.",
        });
      }
  
      // const { error } =  (req.body);
      // if (error) {
      //   if (imagePath)
      //     try {
      //       fs.unlinkSync("./" + imagePath);
      //     } catch (err) {}
      //   return res.status(400).send({ message: error.details[0].message });
      // }
  
      const user = await User.findById(req.body.authorId);
      if (!user) {
        if (imagePath)
          try {
            fs.unlinkSync("./" + imagePath);
          } catch (err) {}
        return res.status(400).send({ error: "Invalid author" });
      }
  
      const oldPost = await League.findOne({ slug: req.params.id });
      if (newImage) {
        let oldImage = oldPost?.featuredImage.replace(baseUrl(), "");
        if (oldImage)
          try {
            fs.unlinkSync("./" + oldImage);
          } catch (err) {}
      } else {
        newImage = oldPost?.featuredImage;
      }
  
      const league = await League.findOneAndUpdate(
        { slug: req.params.id },
        
         req.body,
      
        { new: true }
      );
  
      if (!league) return res.status(404).send({ error: "No League found!" });
  
      res.send(league);
    } catch (error) {
      return res.status(400).send({ error: error.message });
    }
  
    };

 const remove = async (req, res) => {
    try {
        const league = await League.findByIdAndRemove(req.params.id);
        console.log(req.params.id,league)
          if (!league) return res.status(404).send({ message: 'No League found!' });
          let imagePath = league.featuredImage?.replace(baseUrl(), "");
          if (imagePath) try { fs.unlinkSync("./" + imagePath) } catch (err) { }
          res.send({message:'League deleted successfully!'});
    } catch (err) {
      return res.status(404).send({ message: "No feature found!" });
    }

    
    };

module.exports = {
  getAll,
  getOne,
  create,
  update,
  remove,
  updateBulk,
};
