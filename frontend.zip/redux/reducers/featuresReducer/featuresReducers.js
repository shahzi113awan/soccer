import { createSlice } from "@reduxjs/toolkit";
const getFeatures = createSlice({
  name: "features",
  initialState: {
    data: [],
  },
  reducers: {
    getFeaturesSuccess(state, action) {
      state.data = action.payload;
    },
    getFeaturesFail(state, action) {
      state.message = action.payload;
      delete state.data;
    },
  },
});

const { actions, reducer } = getFeatures;
export const { getFeaturesSuccess, getFeaturesFail } = actions;
export default reducer;
