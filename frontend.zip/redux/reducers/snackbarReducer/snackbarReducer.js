import { createSlice } from "@reduxjs/toolkit";
const openSnackBar = createSlice({
  name: "snackbar",
  initialState: {
    type: "info",
    message: null,
    open: false,
  },
  reducers: {
    showSnackbar(state, action) {
      state.type = action.payload.type;
      state.message = action.payload.message;
      state.open = action.payload.open;
    },
  },
});

const { actions, reducer } = openSnackBar;
export const { showSnackbar } = actions;
export default reducer;
