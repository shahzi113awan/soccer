import { combineReducers } from "redux";
import newsReducer from "../newsReducer/newsReducer";
import previewReducer from "../previewsReducer/previewsReducer";
import featuresReducer from "../featuresReducer/featuresReducers";
import snackbarReducer from "../snackbarReducer/snackbarReducer";

export const rootReducer = combineReducers({
  news: newsReducer,
  snackbar: snackbarReducer,
  previews: previewReducer,
  features: featuresReducer,
});
