import { createSlice } from "@reduxjs/toolkit";
const getPreviews = createSlice({
  name: "previews",
  initialState: {
    data: [],
  },
  reducers: {
    getPreviewsSuccess(state, action) {
      state.data = action.payload;
    },
    getPreviewsFail(state, action) {
      state.message = action.payload;
      delete state.data;
    },
  },
});

const { actions, reducer } = getPreviews;
export const {
  getPreviewsSuccess,
  getMorePreviewsPreviewsSuccess,
  getPreviewsFail,
} = actions;
export default reducer;
