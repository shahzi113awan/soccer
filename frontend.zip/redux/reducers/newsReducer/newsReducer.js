import { createSlice } from "@reduxjs/toolkit";
const getNews = createSlice({
  name: "news",
  initialState: {
    data: [],
    pageNumber: 1,
  },
  reducers: {
    getNewsSuccess(state, action) {
      state.data = action.payload;
    },
    getMoreNewsNewsSuccess(state, action) {
      state.data = [...state.data, ...action.payload.data];
      state.pageNumber = action.payload.pageNumber;
    },
    getNewsFail(state, action) {
      state.message = action.payload;
      delete state.data;
    },
  },
});

const { actions, reducer } = getNews;
export const { getNewsSuccess, getMoreNewsNewsSuccess, getNewsFail } = actions;
export default reducer;
