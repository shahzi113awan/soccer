import { createSlice } from "@reduxjs/toolkit";
const getLeagueNews = createSlice({
  name: "leagueNews",
  initialState: {
    data: [],
  },
  reducers: {
    getLeagueNewsSuccess(state, action) {
      state.data = action.payload;
    },
    getLeagueNewsFail(state, action) {
      state.message = action.payload;
      delete state.data;
    },
  },
});

const { actions, reducer } = getLeagueNews;
export const { getLeagueNewsSuccess, getLeagueNewsFail } = actions;
export default reducer;
