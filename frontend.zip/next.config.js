/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  generateTimeout: 100000, // set the timeout duration to 100 seconds
  staticPageGenerationTimeout: 180,
  images: {
    remotePatterns: [
      { protocol: "http", hostname: "localhost", port: "5000", pathname: "**" },
      {
        protocol: "http",
        hostname: "51.104.192.62",
        port: "5000",
        pathname: "**",
      },
      {
        protocol: "https",
        hostname: "api.soccerbx.com",
        pathname: "**",
      },
    ],
  },
  async headers() {
    return [
      {
        source: "/(.*).(jpg|jpeg|png|gif|ico|svg)", // Adjust the file extensions as per your static assets
        headers: [
          {
            key: "Cache-Control",
            value: "public, max-age=31536000, immutable", // Adjust the cache policy as per your requirements
          },
        ],
      },
    ];
  },
};

module.exports = nextConfig;
