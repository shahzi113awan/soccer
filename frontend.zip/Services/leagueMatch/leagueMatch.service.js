import { calls } from "../PromiseHandler/PromiseHandler";

export async function getSingleLeagueMatch(id) {
  try {
    const res = await calls(`child/getOne/${id}`, "get");
    return res;
  } catch (err) {
    return err;
  }
}
