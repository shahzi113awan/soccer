import { calls } from "../PromiseHandler/PromiseHandler";

export async function getSinglePreview(id) {
  try {
    const res = await calls(`previews/${id}`, "get");
    return res;
  } catch (err) {
    return err;
  }
}
