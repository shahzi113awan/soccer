import axios from "axios";

export const calls = async (path, method, data) => {
  try {
    const environment = process.env.NEXT_PUBLIC_NODE_ENV;
    let URL = "";

    if (environment === "uat") {
      URL = process.env.NEXT_PUBLIC_UAT
    } else if (environment === "production") {
      URL = process.env.NEXT_PUBLIC_PROD
    } else {
      URL = process.env.NEXT_PUBLIC_LOCAL
    }

    let response = await axios({
      method: method,
      url: `${URL}${path}`,
      data: data,
    });

    return response;

  } catch (err) {
    return err?.data?.message || "Something Went Wrong :(";
  }
};
