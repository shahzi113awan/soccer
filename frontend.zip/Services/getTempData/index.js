import axios from "axios";
import { calls } from "../PromiseHandler/PromiseHandler";

export const getTempData = async () => {
  try {
    const res = await calls("comments", "get", null);

    return res;
  } catch (err) {
    return err;
  }
};
