import Axios from "axios";
import toast from "react-hot-toast";

/* Error Show/Hide logic */
const handleError = (store, err = null) => {
  if (err?.message) toast.error(err?.message);
};

/* Function to validate|prepare|modify error object */
const prepareErrorObject = (error) => {
  let err =
    (error?.response?.data ?? error) || new Error("Something Went Wrong :(");
  if (typeof err === "object") {
    err.timestamp = Date.now();
    err.config = error?.config;
  } else {
    err = {};
    err.message = "Something went wrong :(";
    err.timestamp = Date.now();
  }
  return err;
};

const interceptor = {
  setupInterceptors: (store) => {
    Axios.interceptors.request.use(
      (config) => {
        if (config?.data) {
          //  do something with response
        }

        return config;
      },
      (error) => {
        handleError(store, error);
      }
    );

    // Response interceptor
    Axios.interceptors.response.use(
      (response) => {
        if (!response) return;
        const { data = {} } = response;
        // console.log("from interceptor", response);
        if (data.status >= 400) {
          const err = prepareErrorObject(data);
          handleError(store, err);
        }

        if (response?.message) {
          toast.success(err?.message);
        }

        return response;
      },
      (error) => {
        if (!error) return;

        const err = prepareErrorObject(error);
        handleError(store, err);

        return Promise.reject(error ? error["response"] : null);
      }
    );
  },
};
export default interceptor;
