import { calls } from "../PromiseHandler/PromiseHandler";

export async function subscribeNewsLetter(data) {
  try {
    const res = await calls("subscribers", "post", data);
    return res;
  } catch (err) {
    return err;
  }
}