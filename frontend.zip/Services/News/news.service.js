import axios from "axios";
import { calls } from "../PromiseHandler/PromiseHandler";

const BASE_URL = "news";

export const getNews = (pageNumber, pageSize = 11) => {
  const res = calls(
    `${BASE_URL}?pageNumber=${pageNumber}&pageSize=${pageSize}`,
    "get",
    null
  );
  return res;
};

export const getSingleNewsData = async (id) => {
  try {
    const res = await calls(`${BASE_URL}/${id}`, "get", null);
    return res;
  } catch (err) {
    return err;
  }
};
export const getAdImage = async (id) => {
  const res = await calls(`advertisements/${id}`, "get", null);
  return res;
};

export async function getSoccerPods() {
  try {
    const res = await calls(`pods`, "get");
    return res;
  } catch (err) {
    return err;
  }
}
export async function getSoccerPodsTitle() {
  try {
    const res = await calls(`pod/title`, "get");
    return res;
  } catch (err) {
    return err;
  }
}
export const getSingleSoccerPodData = async (slug) => {
  try {
    const res = await calls(`pods/${slug}`, "get", null);
    return res;
  } catch (err) {
    return err;
  }
};

export async function getLeagueNews() {
  try {
    const res = await calls(`news/leagues`, "get");
    return res;
  } catch (err) {
    return err;
  }
}
