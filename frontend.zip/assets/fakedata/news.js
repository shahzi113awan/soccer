export const news = [
    {
        "_id": "62bdc7b6a7033fef2f688c94",
        "title": "Erik The Red",
        "author": {
            "name": "Reutersn",
            "_id": "62b338443cb9dc8fa1347031"
        },
        "excerpt" : "Manager officially starts on Monday but has been holding talks",
        "content": "<p>Manager officially starts on Monday but has been holding talks</p>",
        "tags": [],
        "featuredImage": "/images/homepage/featured-news.jpg",
        "comments": [],
        "isActive": true,
        "__v": 0,
        "lastUpdate": "2022-06-30T15:57:01.425Z"
    },
    {
        "_id": "62bdc7b6a7033fef2f688c9",
        "title": "Here We Go",
        "author": {
            "name": "Kurt Pittman",
            "_id": "62b338443cb9dc8fa1347031"
        },
        "excerpt" : "Manager officially starts on Monday but has been holding talks",
        "content": "<p>Manager officially starts on Monday but has been holding talks</p>",
        "tags": [],
        "featuredImage": "/images/homepage/1.png",
        "comments": [],
        "isActive": true,
        "__v": 0,
        "lastUpdate": "2022-06-30T15:57:01.425Z"
    },
    {
        "_id": "62bdc7b6a7033fef2f688c95",
        "title": "Carvalho To Liverpool",
        "author": {
            "name": "Kurt Pittman",
            "_id": "62b338443cb9dc8fa1347031"
        },
        "excerpt" : "Manager officially starts on Monday but has been holding talks",
        "content": "<p>Manager officially starts on Monday but has been holding talks</p>",
        "tags": [],
        "featuredImage": "/images/homepage/1-1.png",
        "comments": [],
        "isActive": true,
        "__v": 0,
        "lastUpdate": "2022-06-30T15:57:01.425Z"
    },
    {
        "_id": "62bdc7b6a7033fef2f688c96",
        "title": "City Take Title",
        "author": {
            "name": "Kurt Pittman",
            "_id": "62b338443cb9dc8fa1347031"
        },
        "excerpt" : "Manager officially starts on Monday but has been holding talks",
        "content": "<p>Manager officially starts on Monday but has been holding talks</p>",
        "tags": [],
        "featuredImage": "/images/homepage/1-2.png",
        "comments": [],
        "isActive": true,
        "__v": 0,
        "lastUpdate": "2022-06-30T15:57:01.425Z"
    },
    {
        "_id": "62bdc7b6a7033fef2f688c97",
        "title": "Frantic Final Week",
        "author": {
            "name": "Kurt Pittman",
            "_id": "62b338443cb9dc8fa1347031"
        },
        "excerpt" : "Manager officially starts on Monday but has been holding talks",
        "content": "<p>Manager officially starts on Monday but has been holding talks</p>",
        "tags": [],
        "featuredImage": "/images/homepage/1-3.png",
        "comments": [],
        "isActive": true,
        "__v": 0,
        "lastUpdate": "2022-06-30T15:57:01.425Z"
    },
    {
        "_id": "62bdc7b6a7033fef2f688c98",
        "title": "Carvalho To Liverpool",
        "author": {
            "name": "Kurt Pittman",
            "_id": "62b338443cb9dc8fa1347031"
        },
        "excerpt" : "Manager officially starts on Monday but has been holding talks",
        "content": "<p>Manager officially starts on Monday but has been holding talks</p>",
        "tags": [],
        "featuredImage": "/images/homepage/featured-news.jpg",
        "comments": [],
        "isActive": true,
        "__v": 0,
        "lastUpdate": "2022-06-30T15:57:01.425Z"
    },
    {
        "_id": "62bdc7b6a7033fef2f688c99",
        "title": "Carvalho To Liverpool",
        "author": {
            "name": "Kurt Pittman",
            "_id": "62b338443cb9dc8fa1347031"
        },
        "excerpt" : "Manager officially starts on Monday but has been holding talks",
        "content": "<p>Manager officially starts on Monday but has been holding talks</p>",
        "tags": [],
        "featuredImage": "/images/homepage/featured-news.jpg",
        "comments": [],
        "isActive": true,
        "__v": 0,
        "lastUpdate": "2022-06-30T15:57:01.425Z"
    },
    {
        "_id": "62bdc7b6a7033fef2f688c1",
        "title": "Carvalho To Liverpool",
        "author": {
            "name": "Kurt Pittman",
            "_id": "62b338443cb9dc8fa1347031"
        },
        "excerpt" : "Manager officially starts on Monday but has been holding talks",
        "content": "<p>Manager officially starts on Monday but has been holding talks</p>",
        "tags": [],
        "featuredImage": "/images/homepage/featured-news.jpg",
        "comments": [],
        "isActive": true,
        "__v": 0,
        "lastUpdate": "2022-06-30T15:57:01.425Z"
    },
    {
        "_id": "62bdc7b6a7033fef2f688c24",
        "title": "Carvalho To Liverpool",
        "author": {
            "name": "Kurt Pittman",
            "_id": "62b338443cb9dc8fa1347031"
        },
        "excerpt" : "Manager officially starts on Monday but has been holding talks",
        "content": "<p>Manager officially starts on Monday but has been holding talks</p>",
        "tags": [],
        "featuredImage": "/images/homepage/featured-news.jpg",
        "comments": [],
        "isActive": true,
        "__v": 0,
        "lastUpdate": "2022-06-30T15:57:01.425Z"
    },
    {
        "_id": "62bdc7b6a7033fef2f688c34",
        "title": "Carvalho To Liverpool",
        "author": {
            "name": "Kurt Pittman",
            "_id": "62b338443cb9dc8fa1347031"
        },
        "excerpt" : "Manager officially starts on Monday but has been holding talks",
        "content": "<p>Manager officially starts on Monday but has been holding talks</p>",
        "tags": [],
        "featuredImage": "/images/homepage/featured-news.jpg",
        "comments": [],
        "isActive": true,
        "__v": 0,
        "lastUpdate": "2022-06-30T15:57:01.425Z"
    },
    {
        "_id": "62bdc7b6a7033fef2f688c44",
        "title": "Carvalho To Liverpool",
        "author": {
            "name": "Kurt Pittman",
            "_id": "62b338443cb9dc8fa1347031"
        },
        "excerpt" : "Manager officially starts on Monday but has been holding talks",
        "content": "<p>Manager officially starts on Monday but has been holding talks</p>",
        "tags": [],
        "featuredImage": "/images/homepage/featured-news.jpg",
        "comments": [],
        "isActive": true,
        "__v": 0,
        "lastUpdate": "2022-06-30T15:57:01.425Z"
    },
    {
        "_id": "62bdc7b6a7033fef2f688c54",
        "title": "Carvalho To Liverpool",
        "author": {
            "name": "Kurt Pittman",
            "_id": "62b338443cb9dc8fa1347031"
        },
        "excerpt" : "Manager officially starts on Monday but has been holding talks",
        "content": "<p>Manager officially starts on Monday but has been holding talks</p>",
        "tags": [],
        "featuredImage": "/images/homepage/featured-news.jpg",
        "comments": [],
        "isActive": true,
        "__v": 0,
        "lastUpdate": "2022-06-30T15:57:01.425Z"
    },
    {
        "_id": "62bdc7b6a7033fef2f688c64",
        "title": "Carvalho To Liverpool",
        "author": {
            "name": "Kurt Pittman",
            "_id": "62b338443cb9dc8fa1347031"
        },
        "excerpt" : "Manager officially starts on Monday but has been holding talks",
        "content": "<p>Manager officially starts on Monday but has been holding talks</p>",
        "tags": [],
        "featuredImage": "/images/homepage/featured-news.jpg",
        "comments": [],
        "isActive": true,
        "__v": 0,
        "lastUpdate": "2022-06-30T15:57:01.425Z"
    },


]
