import { useEffect, useState } from "react";
import Skeleton from "react-loading-skeleton";
import { FaFacebookF, FaInstagram, FaTwitter, FaShare } from "react-icons/fa";
import Link from "next/link";
import { useDispatch } from "react-redux";
import { MdOutlineChatBubble } from "react-icons/md";
import { AiOutlineArrowRight } from "react-icons/ai";
import { useRouter } from "next/router";
import "react-loading-skeleton/dist/skeleton.css";
import parse from "html-react-parser";
import { useSelector } from "react-redux";
import { FacebookShareButton } from "react-share";
import {
  getAdImage,
  getSingleNewsData,
} from "../../Services/News/news.service";
import { getFeaturesSuccess } from "../../redux/reducers/featuresReducer/featuresReducers";
import LatestNews from "../../components/pagesComponents/Features/LatestNews/LatestNews";
import { calls } from "../../Services/PromiseHandler/PromiseHandler";
import Head from "next/head";

const monthNames = [
  "",
  "January",
  "February",
  "March",
  "April",
  "May",
  "June",
  "July",
  "August",
  "September",
  "October",
  "November",
  "December",
];
const tempData = {
  _id: "62e7a56850e1afaf3853bb3c",
  title: "eyes on salah",
  subTitle:
    "Erling Haaland gives green light to Manchester City move after initial personal terms agreement",
  author: { name: "Kurt Pittman", _id: "62b338443cb9dc8fa1347031" },
  content:
    "<p>16/24 Soccerbx revealed earlier this year that City were winning the race for the 21-year-old. It is believed that the striker's representatives have agreed initial personal terms with City.</p>\r\n<p>There is still work to be done before a deal is finalised &mdash; such as payment to Dortmund, commission to Haaland&rsquo;s representatives and the details of his contract &mdash; and therefore the situation is not closed.</p>\r\n<p>City are thought to regard the reported developments as more speculation and have declined to comment.</p>\r\n<p>When asked about triggering Haaland's release clause on Tuesday, City manager Pep Guardiola responded: \"No answer to your question.&rdquo;</p>\r\n<p>Haaland, who was born in Leeds, has developed into one of Europe&rsquo;s most coveted strikers in recent seasons.</p>\r\n<p>He scored twice against Wolfsburg at the weekend and has now hit 33 goals for club and country this season.</p>\r\n<p>Haaland&rsquo;s father, Alf-Inge, played for City, Leeds and Nottingham Forestduring a 10-year spell in England.</p>\r\n<p>City pursued a striker last summer after the departure of Sergio Aguero, with the current Premier League champions eyeing the signature of Harry Kane.</p>\r\n<p>However, they were unable to prise him away from Tottenham.</p>",
  excerpt:
    "who was born in Leeds, has developed into one of Europe’s most coveted strikers in recent seasons.\r\n\r\nHe scored twice against Wolfsburg at the weekend and has now hit 33 goals for club and country this season.\r\n\r\nHaaland’s father, Alf-Inge, pla",
  tags: [],
  featuredImage:
    "http://51.104.192.62:5000/uploads/1659348327183--methode-times-prod-web-bin-48d58908-c0ba-11ec-b4e3-203ad1be3cbc-2.png",
  commentsCount: 0,
  slug: "haaland-approves-move-1",
  sidebarAds: "",
  isActive: true,
  createdAt: "2022-08-01T10:05:28.778Z",
  __v: 0,
  lastUpdate: "2022-08-02T08:41:33.841Z",
};

const tempOds = [
  {
    title: "Over 2.5 Match Goals",
    rating: 3,
    ods: "8/13",
    id: 1,
  },
  {
    title: "liverpool 3-2",
    rating: 1,
    ods: "22/1",
    id: 2,
  },
  {
    title: "Mohamed salah to score anytime",
    rating: 1,
    ods: "21/20",
    id: 3,
  },
];

const SoccerBet = () => {
  const dispatch = useDispatch();
  const [dataToShow, setDataToShow] = useState({});
  const [loading, setLoading] = useState(true);
  const [nextArticle, setNextArticle] = useState({});
  const [sidebarAds, setSidebarAds] = useState([]);
  const [content, setContent] = useState(null);
  const router = useRouter();
  const {
    query: { slug },
  } = router;

  //   const latest = useSelector((state) => state?.features?.data?.slice(0, 3));
  const latest = [
    {
      _id: "62e7a56850e1afaf3853bb3c",
      title: "Haaland approves move",
      subTitle:
        "Erling Haaland gives green light to Manchester City move after initial personal terms agreement",
      author: { name: "Kurt Pittman", _id: "62b338443cb9dc8fa1347031" },
      featuredImage:
        "http://51.104.192.62:5000/uploads/1659348327183--methode-times-prod-web-bin-48d58908-c0ba-11ec-b4e3-203ad1be3cbc-2.png",
      commentsCount: 0,
      slug: "haaland-approves-move-1",
      sidebarAds: "",
      isActive: true,
    },
    {
      _id: "62e7a56850e1afaf3853bb3c",
      title: "Haaland approves move",
      subTitle:
        "Erling Haaland gives green light to Manchester City move after initial personal terms agreement",
      author: { name: "Kurt Pittman", _id: "62b338443cb9dc8fa1347031" },
      featuredImage: "http://51.104.192.62:5000/uploads/1659347405862-xyz3.png",
      commentsCount: 0,
      slug: "haaland-approves-move-1",
      sidebarAds: "",
      isActive: true,
    },
    {
      _id: "62e7a56850e1afaf3853bb3c",
      title: "Haaland approves move",
      subTitle:
        "Erling Haaland gives green light to Manchester City move after initial personal terms agreement",
      author: { name: "Kurt Pittman", _id: "62b338443cb9dc8fa1347031" },
      featuredImage: "http://51.104.192.62:5000/uploads/1659347379343-xyz2.png",
      commentsCount: 0,
      slug: "haaland-approves-move-1",
      sidebarAds: "",
      isActive: true,
    },
  ];

  useEffect(() => {
    // iife
    (async () => {
      setLoading(true);
      const res = await calls(`page/soccerbet`, "get");
      setDataToShow(res?.data);
      setContent(res?.data?.content?.replace(/&nbsp;/g, " "));
      setLoading(false);
    })();
  }, []);

  const createdAt = () => {
    const d = new Date(dataToShow?.createdAt);

    return `${d?.getDate()} ${
      monthNames[d.getMonth() + 1]
    } ${d?.getFullYear()}`;
  };

  const updateTime = (date) => {
    const time = new Date(date);
    const today = new Date();
    // converting time to usa timeZone.
    const americanTime = new Date(
      time?.toLocaleString("en-US", {
        timeZone: "America/New_York",
      })
    );

    if (
      time?.getMonth() === today?.getMonth() &&
      time?.getDate() === today.getDate()
    ) {
      return `${americanTime.getHours()}:${
        americanTime.getMinutes() < 9
          ? "0" + americanTime.getMinutes()
          : americanTime.getMinutes()
      }`;
    }
    return `${time?.getDate()} ${
      monthNames[time.getMonth() + 1]
    } ${time?.getFullYear()}`;
  };
  return (
    <div>
      <Head>
        <title>SoccerBet</title>
      </Head>
      {loading ? (
        <div>
          <Skeleton height={200} width="100%" />
          <div className="flex">
            <div className="border-r border-black sm:h-[500px] w-[50%] h-[200px]">
              <Skeleton height="100%" width="100%" />
            </div>
            <div className="sm:h-[500px] w-[50%] h-[200px]">
              <Skeleton height="100%" width="100%" />
            </div>
          </div>
        </div>
      ) : !dataToShow?._id ? (
        <h4>No Data Found :(</h4>
      ) : (
        <>
          <div className="p-5 bg-black text-center linear-border-b-5">
            <img
              className="mx-auto"
              src="/images/soccer-bet-logo.svg"
              alt="SoccerBet"
            />
          </div>
          <div className="flex xs:flex-row">
            <div className="flex-1 flex w-full items-center justify-center bg-black max-w-[50%] py-3 sm:py-0">
              <ul className="text-center uppercase">
                <li>
                  {" "}
                  <h5 className="sm:text-[50px] text-[27px] md:text-[80px] sm:leading-[65px] leading-[23px] text-white">
                    {dataToShow?.title?.split(" ")?.[0] ?? ""}
                  </h5>
                </li>
                <li>
                  {" "}
                  <h5 className="sm:text-[50px] text-[27px] md:text-[80px] sm:leading-[65px] leading-[23px] text-white">
                    {dataToShow?.title?.split(" ")?.[1] ?? ""}
                  </h5>
                </li>
                <li>
                  {" "}
                  <h5 className="sm:text-[50px] text-[27px] md:text-[80px] sm:leading-[65px] leading-[23px] text-white">
                    {dataToShow?.title?.split(" ")?.[2] ?? ""}
                  </h5>
                </li>
              </ul>
            </div>
            <div className="flex-1">
              {loading && !dataToShow?.featuredImage ? (
                <Skeleton height={300} width="100%" />
              ) : (
                <img
                  src={
                    dataToShow?.featuredImage ||
                    "https://upload.wikimedia.org/wikipedia/commons/7/75/No_image_available.png"
                  }
                  alt={dataToShow?.title ?? ""}
                  width="100%"
                  className={`lg:h-[640px] sm:min-h-48 md:min-h-[400px] lg:w-[640px] sm:w-full w-full h-[187px]  object-cover ${
                    !Boolean(dataToShow?.featuredImage) && "no-image_img"
                  }`}
                />
              )}
            </div>
          </div>

          <div className="sm:px-10 px-3">
            <div className="md:col-span-2 mt-3 hidden sm:block text-[12px]">
              Photo Credit
            </div>
            <div className="mx-auto md:grid grid-cols-12 flex items-start justify-between hidden lg:mt-[16px]">
              <div className="md:col-span-2 " />
              <div className="md:col-span-10 flex justify-between items-top">
                <h1 className="text-left text-[24px] font-[500] leading-[28px]  uppercase">
                  <div className="max-w-[600px]">
                    {dataToShow?.subTitle || ""}
                  </div>
                </h1>
                {nextArticle?.next?._id && (
                  <div className="text-right mb-3 ml-auto">
                    <button
                      title={nextArticle?.next?.title ?? ""}
                      className={
                        !nextArticle?._id ? "text-black" : "cursor-pointer"
                      }
                      disabled={!nextArticle?.next?._id}
                      onClick={() => handleNextNews(nextArticle)}>
                      {" "}
                      <AiOutlineArrowRight />
                    </button>
                  </div>
                )}
              </div>
            </div>

            <div className="mx-auto grid grid-cols-12 mb-[56px] mt-3">
              <div className="md:col-span-2 col-span-12 border-b-2 md:border-b-0 sm:pb-3 sm:mb-6 mobile-linear-border">
                <div className="flex md:flex-col flex-row-reverse w-full justify-between md:max-w-[200px] mb-2">
                  <div className="flex py-1 pb-[8px] sm-linear-border items-center">
                    <span className="mr-2">
                      <FaShare />
                    </span>
                    <FacebookShareButton
                      url={
                        typeof window !== "undefined" && window?.location?.href
                      }
                      quote={"This is a testing quote"}
                      hashtag={"#soccerBx"}
                      description={"Thsi is a testing description"}
                      title={dataToShow?.subTitle ?? ""}>
                      <div className="h-[24px] w-[24px] flex items-center justify-center bg-black rounded-full ml-2">
                        <FaFacebookF className="fill-white" />
                      </div>
                    </FacebookShareButton>
                    <Link href="instagram.com">
                      <a
                        target="_blank"
                        className="h-[24px] w-[24px] flex items-center justify-center bg-black rounded-full ml-2">
                        <FaInstagram className="fill-white" />
                      </a>
                    </Link>

                    <a
                      target="_blank"
                      className="h-[24px] w-[24px] flex items-center justify-center bg-black rounded-full ml-2"
                      href={`https://twitter.com/intent/tweet?text=${
                        typeof window !== "undefined" && window?.location?.href
                      }`}
                      rel="noreferrer">
                      <FaTwitter className="fill-white" />
                    </a>
                  </div>
                  <div>
                    <strong className="text-[12px] mb-[16px] inline-block">
                      {/* {dataToShow?.author?.name ?? "Unknown"} */}
                      Soccerbx Team
                    </strong>
                    {<div className="text-[12px]">{createdAt()}</div>}
                    {dataToShow?.lastUpdate && (
                      <div className="text-[12px]">
                        Updated {updateTime(dataToShow?.lastUpdate)} EST
                      </div>
                    )}
                  </div>
                </div>
                {/* <div className="flex items-center py-[8px]">
                  <MdOutlineChatBubble />{" "}
                  <span className="text-[12px]">
                    {dataToShow?.comments?.length ?? 0}
                  </span>
                </div> */}
              </div>
              <div className="newsMain-content_f_ads sm:px-3 col-span-12 md:col-span-7">
                <div className="max-w-[600px]">
                  <h1 className="md:hidden block text-[24px] font-[500] leading-[28px] my-5 uppercase">
                    {dataToShow?.subTitle || ""}
                  </h1>

                  <div className="editorContent overflow-hidden">
                    {parse(content)}
                  </div>
                  {/* <div className="mt-5">
                    <h4 className="mb-4 bg-linear p-3 text-white text-center">
                      Big match odds
                    </h4>
                    {tempOds?.map((od) => (
                      <div className="linear-border my-2" key={od?.id}>
                        <strong className="block text-[18px] font-medium">
                          {od?.title}
                        </strong>
                        <div className="flex">
                          {[1, 2, 3]?.map((rate, i) => (
                            <div key={i++}>
                              <img
                                src={
                                  rate <= od?.rating
                                    ? "/images/star-fill.svg"
                                    : "/images/star-unfill.svg"
                                }
                                alt="rating"
                              />
                            </div>
                          ))}
                        </div>
                        <div className="my-3 flex justify-between items-center">
                          <div className="bg-[#CDCDCD] text-black py-1 px-2 rounded-[4px]">
                            <strong>{od?.ods} </strong>Ods when tipped
                          </div>
                          <button className="text-white rounded-[4px] bg-soccer-red p-2">
                            Place Bet
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                  <div className="my-6">
                    <img
                      src="/images/Mo-Salah-Footballer-1.png"
                      width="100%"
                      alt="Footballer"
                    />
                  </div>
                  <p className="mt-3 text-[24px] font-medium text-black text-center">
                    New Customer Special
                  </p>
                  <div className="my-6">
                    <img src="/images/customer-special.png" alt="" />
                  </div> */}
                </div>
              </div>
              <div className="md:col-span-3 col-span-12 border-b-2 md:border-b-0 sm:pb-3 sm:mb-6 flex flex-col">
                {sidebarAds?.length > 0 &&
                  sidebarAds?.map((ad, i) => (
                    <div key={i} className="my-4">
                      <a
                        rel="noreferrer"
                        target="_blank"
                        href={`//${ad?.linkTo}`}>
                        {ad?.type === "image" ? (
                          <img width="100%" src={ad?.url} alt="CHANGE_ME" />
                        ) : (
                          <video muted loop autoPlay width="100%">
                            <source src={ad?.url} type="video/mp4" />
                            Your browser does not support HTML video.
                          </video>
                        )}
                      </a>
                    </div>
                  ))}

                {/* <div className="mt-4 border-t">
                  <h3 className="text-2xl">LATEST</h3>
                  {latest?.map((l) => (
                    <div className="my-3" key={l?.id}>
                      <LatestNews
                        slug={`features/${l.slug}`}
                        type="image"
                        image={l?.featuredImage}
                        author="test author"
                        heading="Carvalho To Liverpool"
                      />
                    </div>
                  ))}
                </div> */}
              </div>
            </div>

            {/* <section className="bg-black py-7 my-[40px] linear-border-b-5 linear-border-t-5">
              <div className="">
                <div className="md:grid p-5 md:p-0 grid-cols-12 text-white">
                  <div className="col-span-2 hidden md:block"></div>
                  <div className="col-span-7 md:grid grid-cols-[170px_1fr] gap-8 md:max-w-[600px] mx-auto">
                    <div>
                      <img
                        className="mx-auto sm:w-[200px] sm:h-[200px] w-[131px] h-[161px]"
                        src="images/soccerbox-predicts.svg"
                        alt="soccerbox-predicts"
                      />
                    </div>
                    <div>
                      <p className=" mb-3">
                        The ten Hag revolution shudders to a temporary halt.
                        United improve on recent Premier League performances
                        against Liverpool, but are forced to settle for a narrow
                        defeat
                      </p>
                      <span className="py-2 block">Score:</span>
                      <div className="bg-linear p-3 mb-3  text-[18px] font-normal text-center">
                        Manchester United 1 Liverpool 2
                      </div>
                      <p className="my-4">
                        If you’re looking for more insight ahead of the game on
                        Monday evening, head over to our preview page for a more
                        in-depth look, or have a listen to our podcast for the
                        very latest betting tips and expert coverage.
                      </p>
                    </div>
                  </div>
                  <div className="col-span-3 hidden md:block"></div>
                </div>
              </div>
            </section> */}
          </div>
        </>
      )}
    </div>
  );
};

export default SoccerBet;

const getImageAndReplaceWithHtml = async (id) => {
  const data = await getAdImage(id);
  if (data?.data?.url) {
    if (data?.data?.type === "image") {
      return `<a class='py-4 block addFor-${
        data?.data?.category
      }' href='//${data?.data?.linkTo.trim()}' target="_blank"><img src=${
        data?.data?.url
      } alt="CHANGE_ME" width="100%"/></a>`;
    }
    if (data?.data?.type === "video") {
      return `<a class='py-4 block addFor-${
        data?.data?.category
      }' href='//${data?.data?.linkTo.trim()}' target="_blank">
      <video loop muted autoPlay playsinline src="${
        data?.data?.url
      }" width="100%">
  
  Your browser does not support HTML video.</video>
        </a>`;
    }
  }

  return "";
};

const replaceShortCodesWithAds = async (html) => {
  const tempArr = html?.split("~[SC~");
  const ids = [];
  tempArr?.forEach((f, i) => (i % 2 !== 0 ? ids.push(f.trim()) : f));
  if (ids?.length) {
    const updateHtml = await Promise.all(
      tempArr?.map(async (t) => {
        return ids?.includes(t.trim())
          ? await getImageAndReplaceWithHtml(t?.trim())
          : t?.replace(/\r?\n|\r/g, "");
      })
    );
    return updateHtml?.join("");
  }
  return html?.replace(/\r?\n|\r/g, "");
};
// export async function getServerSideProps(context) {
//   const { id } = context?.params;
//   const data = await calls(`features/${id}`, "get");
//   let newsData = "";
//   if (data?.data) {
//     // ads for small screens and main-content
//     newsData = await replaceShortCodesWithAds(data?.data?.content);
//   }
//   return {
//     props: {
//       data: data?.data || null,
//       featureData: newsData || "",
//     },
//   };
// }
