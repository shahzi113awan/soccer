import React from "react";
import TitleTable from "../../components/commonComponents/TitleTable/TitleTable";
const index = () => {
  return (
    <div className="bg-black">
      <div className="p-5 bg-black text-center linear-border-b-5">
        <img
          className="mx-auto"
          src="/images/soccerbox-predicts.svg"
          alt="SoccerBet"
        />
      </div>

      <section className="max-w-[806px] mx-auto">
        <h1 className="text-[24px] sm:text-[32.58px] text-white pt-5">
          Gameweek 2
        </h1>
        <h2 className="sm:text-[24px] my-2 text-white">
          Saturday 13 August 2022
        </h2>

        <div className="mt-5 pb-7 border-b border-white">
          <div
            className="sm:grid py-5 my-5"
            style={{ gridTemplateColumns: "1fr 2.4fr" }}
          >
            <div
              className="max-h-[210px] min-h-[150px] grid sm:block gap-[12px] px-3"
              style={{ gridTemplateColumns: "1fr 1.7fr" }}
            >
              <TitleTable
                fontSizes="text-[35px] sm:text-[50px]"
                title="mci v bou"
              />

              {/* small screen */}
              <div className="block sm:hidden bg-linear p-3 text-white text-[18px] font-normal">
                <div className="max-w-[456px]">
                  Manchester City v Bournemouth ETIHAD STADIUM - 12:30
                </div>
              </div>
            </div>
            <div className="px-3 ">
              <div className="hidden sm:block bg-linear p-3 mb-3 text-white text-[18px] font-normal">
                <div className="max-w-[456px]">
                  Manchester City v Bournemouth ETIHAD STADIUM - 12:30
                </div>
              </div>
              <div>
                <p className="text-white text-[16px] my-5">
                  Two words. One name. Erling Haaland. The Norwegian looked
                  sensational during City’s win at West Ham last Sunday
                  afternoon. The question is; who can stop him? It’s not a game
                  that Bournemouth manager Scott Parker will approach with much
                  confidence, given the gulf in class and respective transfer
                  budgets. Bournemouth’s aim is to survive in the Premier
                  League. City are expected to win it for the third year in
                  succession.
                </p>
                <h3 className="text-[20px] text-white">
                  Soccerbx predicts: 4-0
                </h3>
                <h3 className="text-[20px] text-[#01A4FF]">
                  Soccerbx Odds Engine predicts{" "}
                </h3>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default index;
