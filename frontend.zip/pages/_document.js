import { Html, Head, Main, NextScript } from "next/document";

export default function Document() {
  return (
    <Html>
      <Head>
        <link rel="preconnect" href="https://tags.crwdcntrl.net" />
        <link rel="preconnect" href="https://bcp.crwdcntrl.net" />
        <link rel="dns-prefetch" href="https://tags.crwdcntrl.net" />
        <link rel="dns-prefetch" href="https://bcp.crwdcntrl.net" />
        {/* <!-- Google tag (gtag.js) --> */}
        <script
          async
          src="https://www.googletagmanager.com/gtag/js?id=G-7CVZ0PD07W"
        />
        {/* lotame */}
        <script
          dangerouslySetInnerHTML={{
            __html: `
              ! function() {
                var lotameClientId = '16703';
                var lotameTagInput = {
                    data: {},
                    config: {
                      clientId: Number(lotameClientId)
                    }
                };
          
                
                var lotameConfig = lotameTagInput.config || {};
                var namespace = window['lotame_' + lotameConfig.clientId] = {};
                namespace.config = lotameConfig;
                namespace.data = lotameTagInput.data || {};
                namespace.cmd = namespace.cmd || [];
              } ();
       
            
              `,
          }}
        />
        {/* GA */}
        <script
          dangerouslySetInnerHTML={{
            __html: `
           
            window.dataLayer = window.dataLayer || [];
            function gtag(){dataLayer.push(arguments)}
            gtag('js', new Date());

            gtag('config', 'G-7CVZ0PD07W');
              `,
          }}
        />
        <script async src="https://tags.crwdcntrl.net/lt/c/16703/lt.min.js" />
        {/* <!-- Google Tag Manager --> */}
        <script
          dangerouslySetInnerHTML={{
            __html: `(function(w,d,s,l,i){w[l] = w[l] || [];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
          j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
          'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-W94SVZP');`,
          }}
        />
        {/* <!-- End Google Tag Manager --> */}
      </Head>

      <body>
        <Main />
        <NextScript />
        {/* <!-- Google Tag Manager (noscript) --> */}
        <noscript>
          <iframe
            src="https://www.googletagmanager.com/ns.html?id=GTM-W94SVZP"
            height="0"
            width="0"
            style={{ display: "none", visibility: "hidden" }}
          ></iframe>
        </noscript>
        {/* <!-- End Google Tag Manager (noscript) --> */}
      </body>
    </Html>
  );
}
