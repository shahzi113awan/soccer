import { useState, useEffect } from "react";
import Head from "next/head";
import { useSelector } from "react-redux";
import AdBanner from "../components/single/home/AdBanner";
import FeatureSection from "../components/single/home/FeatureSection";
import GoalFest from "../components/single/home/GoalFest";
import HeroSection from "../components/single/home/HeroSection";
import NewsSection from "../components/single/home/NewsSection";
import PreviewsSection from "../components/single/home/PreviewsSection";
import SoccerpodSection from "../components/single/home/SoccerpodSection";
import AdditionalArticleSecondTemplate from "./../components/single/home/AdditionalArticleSecondTemplate";
import AdditionalArticleThirdTemplate from "./../components/single/home/AdditionalArticleThirdTemplate";
import FeaturedArticle from "../components/shared/FeaturedArticle";
import ArticleSlider from "../components/single/home/ArticleSlider";
import { news } from "../assets/fakedata/news";
import { getNews } from "../Services/News/news.service";
// import { getNewsSuccess } from "../redux/reducers/newsReducer/newsReducer";
import BigImgCard from "../components/single/home/BigImgCard";
import { calls } from "../Services/PromiseHandler/PromiseHandler";
import SoccerBet from "../components/commonComponents/SoccerBet/SoccerBet";
import Skeleton from "react-loading-skeleton";
export default function Home({
  data,
  soccerPodData,
  goalFestData,
  fanduelData,
  // leagueData,
}) {
  // const dispatch = useDispatch();
  const [heroBanner, setHeroBanner] = useState(null);
  const [bannerHeading, setBannerHeading] = useState("soccerbet.io");
  const [metaTitle, setMetaTitle] = useState("");
  const [metaDescription, setMetaDescription] = useState("");
  const [metaKeyword, setMetaKeyword] = useState("");
  const [soccerPodHeading, setSoccerPodHeading] = useState("");
  const [soccerPodDescription, setSoccerPodDescription] = useState("");
  const [soccerPodImage, setSoccerPodImage] = useState("");
  const [soccerPodLink, setSoccerPodLink] = useState("");

  const [goalFestHeading, setGoalFestHeading] = useState("");
  const [goalFestDescription, setGoalFestDescription] = useState("");
  const [goalFestImage, setGoalFestImage] = useState("");

  const [fanduelHeading, setFanduelHeading] = useState("");
  const [fanduelLink, setFanduelLink] = useState("");
  const [fanduelImage, setFanduelImage] = useState("");
  const [allLeaguesWithMatches, setAlLeaguesWithMatches] = useState([]);
  const [allLeagueNews, setallLeagueNews] = useState([]);
  const [loadingLeagues, setLoadingLeagues] = useState(true);
  const [loadingNews, setLoadingNews] = useState(true);

  const [settings, setSettings] = useState([
    {
      name: "news",
    },
    {
      name: "previews",
    },
    {
      name: "goalFest",
    },
    {
      name: "module1",
    },
    {
      name: "listen",
    },

    {
      name: "adBanner",
    },
    {
      name: "module2",
    },
    {
      name: "adBanner",
    },
    {
      name: "module3",
    },
    {
      name: "slider",
    },
    {
      name: "module4",
    },
    {
      name: "adBanner",
    },
    {
      name: "fanduel",
    },
  ]);
  // const reduxState = useSelector((state) => state);
  // let mounted = false;

  useEffect(() => {}, []);
  const getComponent = (item) => {
    switch (item.name) {
      case "news":
        return (
          <div>
            {loadingNews ? (
              <>
                {["sk1"].map((x) => (
                  <div className="col-span-12 my-3 mx-3 md:mx-10" key={x}>
                    <Skeleton height={400} width="100%" />
                  </div>
                ))}
              </>
            ) : (
              <NewsSection allLeagueNews={allLeagueNews} />
            )}
          </div>
        );
      case "previews":
        return;
      // <div>
      //   <div className="border mt-4">
      //     <PreviewsSection />
      //   </div>
      //   <div className="border mt-4">
      //     <PreviewsSection />
      //   </div>
      // </div>;

      case "goalFest":
        return (
          <GoalFest
            goalFestHeading={goalFestHeading}
            goalFestDescription={goalFestDescription}
            goalFestImage={goalFestImage}
          />
        );
      case "module1":
        return (
          <>
            <FeatureSection />
            {/* <AdditionalArticles /> */}
          </>
        );
      case "listen":
        return (
          <SoccerpodSection
            soccerHeading={soccerPodHeading}
            soccerPodDescription={soccerPodDescription}
            soccerPodImage={soccerPodImage}
            soccerPodLink={soccerPodLink}
          />
        );
      case "slider":
        return <ArticleSlider />;
      case "adBanner":
        return <AdBanner />;
      case "module2":
        return (
          <>
            <BigImgCard news={news} />
            <AdditionalArticleSecondTemplate />
          </>
        );
      case "module3":
        return (
          <div className="p-4 lg:px-8 max-w-[1280px] mx-auto">
            <h3 className="text-[20px]">Module title</h3>
            <div className=" grid grid-cols-2 lg:grid-cols-4 gap-4">
              {news.slice(0, 4).map((n) => (
                <FeaturedArticle
                  className="border-b pb-4"
                  key={n._id}
                  author={n.author.name}
                  heading={n.title}
                  content={n.excerpt}
                  smCard
                  image={n.featuredImage}
                  imageClass="h-[115px] w-[164px] md:h-[300px] lg:h-[300px]"
                  leagueTag={n?.league?.slug}
                />
              ))}
            </div>
          </div>
        );
      case "module4":
        return <AdditionalArticleThirdTemplate />;
      case "fanduel":
        return (
          <SoccerBet
            fanduelHeading={fanduelHeading}
            fanduelLink={fanduelLink}
            fanduelImage={fanduelImage}
          />
        );
      default:
        return null;
    }
  };
  const getLayout = async () => {
    setBannerHeading(data?.bannerHeading ?? "soccerbet.io");
    setHeroBanner(data?.banner);
    setMetaTitle(data?.metaTitle);
    setMetaDescription(data?.metaDescription);
    setMetaKeyword(data?.metaKeyword);
    setSettings(data.settings ?? (settings || []));
    setSoccerPodHeading(soccerPodData?.soccerPodHeading ?? "");
    setSoccerPodDescription(soccerPodData?.soccerPodDescription ?? "");
    setSoccerPodImage(soccerPodData?.soccerPodImage ?? "");
    setSoccerPodLink(soccerPodData?.soccerPodLink ?? "");
    setGoalFestHeading(goalFestData?.goalFestHeading ?? "");
    setGoalFestDescription(goalFestData?.goalFestDescription ?? "");
    setGoalFestImage(goalFestData?.goalFestImage ?? "");
    setFanduelHeading(fanduelData?.fanduelHeading ?? "");
    setFanduelLink(fanduelData?.fanduelLink ?? "");
    setFanduelImage(fanduelData?.fanduelImage ?? "");
  };

  const fetchNewsData = async () => {
    setLoadingNews(true);
    try {
      const news = await getNews(1);
      const newsData = news?.data;
      setallLeagueNews(newsData ?? []);

      setLoadingNews(false);
    } catch (error) {
      console.log(error.message);
      setLoadingNews(false);
    }
    // if (reduxState?.news?.data?.length <= 0) {
    //   dispatch(getNewsSuccess(newsData));
    // }
  };

  const fetchLeagueData = async () => {
    setLoadingLeagues(true);
    try {
      const leagueRes = await calls("child/leagues", "get");
      const leaguesWithMatches = leagueRes?.data ?? [];
      setAlLeaguesWithMatches(leaguesWithMatches ?? []);
      setLoadingLeagues(false);
    } catch (error) {
      console.log(error.message);
      setLoadingLeagues(false);
    }
  };

  useEffect(() => {
    getLayout();
    fetchNewsData();
    fetchLeagueData();
  }, []);
  const containerFluids = ["goalFest"];
  const isAuth =
    typeof window !== "undefined" && document.cookie.indexOf("isAuth") > 0;

  return (
    <>
      <div>
        <Head>
          <title>Home | SoccerBx</title>
          <meta charset="utf-8" />

          <meta name="title" content={metaTitle ?? ""} />
          <meta name="description" content={metaDescription ?? ""} />
          {/* <!-- Mobile Stuff --> */}
          <meta httpEquiv="X-UA-Compatible" content="IE=edge" />
          <meta name="viewport" content="width=device-width, initial-scale=1" />
          <meta name="msapplication-tap-highlight" content="no" />

          {/* Chrome on Android */}
          <meta name="mobile-web-app-capable" content="yes" />
          <meta name="application-name" content="SoccerBx" />

          {/* <!-- Safari on iOS --> */}
          <meta name="apple-mobile-web-app-capable" content="yes" />
          <meta name="apple-mobile-web-app-status-bar-style" content="black" />
          <meta name="apple-mobile-web-app-title" content="CHANGE-ME" />

          {/* <!-- Windows 8 --> */}
          <meta name="msapplication-TileImage" content={heroBanner ?? ""} />
          <meta name="msapplication-TileColor" content="#FFFFFF" />

          <meta name="theme-color" content="#000000" />
        </Head>
        <HeroSection
          bigScreenImage={heroBanner ?? ""}
          bannerHeading={
            bannerHeading == "undefined" ? "soccerbet.io" : bannerHeading
          }
        />

        <div>
          {loadingLeagues ? (
            <>
              {["sk1"].map((x) => (
                <div className="col-span-12 my-3 mx-3 md:mx-10" key={x}>
                  <Skeleton height={350} width="100%" />
                </div>
              ))}
            </>
          ) : (
            <>
              {allLeaguesWithMatches?.map((league) => (
                <div key={league._id}>
                  {league?.matches?.length > 0 && (
                    <div className="border my-4">
                      <PreviewsSection
                        leagueSlug={league?.slug}
                        LeagueTitile={league?.title}
                        leagueMatches={league.matches}
                      />
                    </div>
                  )}
                </div>
              ))}
            </>
          )}
        </div>

        {settings
          ?.filter((x) => x?.isVisible)
          ?.map((item) => (
            <div
              key={item.key}
              className={`${
                !containerFluids?.includes(item?.name)
                  ? "max-w-[1280px] mx-auto"
                  : ""
              }`}>
              {getComponent(item)}
            </div>
          ))}
      </div>
    </>
  );
}

export async function getStaticProps() {
  const res = await calls("settings", "get");
  // const news = await getNews(1);
  const bannerHeading = res?.data?.[0]?.text ?? "";
  const banner = res?.data?.[0]?.value?.bannerImage ?? "";
  const metaTitle = res?.data?.[0]?.meta_title ?? "";
  const metaDescription = res?.data?.[0]?.meta_des ?? "";
  const metaKeyword = res?.data?.[0]?.meta_keyword ?? "";

  const settings = JSON.parse(res?.data?.[0]?.value?.sections) ?? [];

  const apiRes = await calls("soccerPod", "get");

  const soccerPodHeading = apiRes?.data?.[0]?.heading ?? "soccerbet.io";
  const soccerPodImage = apiRes?.data?.[0]?.image1 ?? "";
  const soccerPodDescription = apiRes?.data?.[0]?.description ?? "";
  const soccerPodLink = apiRes?.data?.[0]?.link ?? "";

  const apiResGoalFest = await calls("moreTeamUsa", "get");
  const goalFestHeading = apiResGoalFest?.data?.[0]?.heading ?? "";
  const goalFestImage = apiResGoalFest?.data?.[0]?.value?.image1 ?? "";
  const goalFestDescription = apiResGoalFest?.data?.[0]?.description ?? "";

  const fanduelRes = await calls("fanduel", "get");
  const fanduelHeading = fanduelRes?.data?.[0]?.heading ?? "";
  const fanduelImage = fanduelRes?.data?.[0]?.value?.image ?? "";
  const fanduelLink = fanduelRes?.data?.[0]?.link ?? "";

  // const leagueRes = await calls("child/leagues", "get");
  // const leaguesWithMatches = leagueRes?.data ?? [];

  // const newsData = news?.data;

  // const leagueData = {
  //   leaguesWithMatches,
  // };

  const data = {
    bannerHeading,
    settings,
    banner,
    // newsData,
    metaTitle,
    metaDescription,
    metaKeyword,
  };
  const soccerPodData = {
    soccerPodHeading,
    soccerPodDescription,
    soccerPodImage,
    soccerPodLink,
  };
  const goalFestData = {
    goalFestHeading,
    goalFestImage,
    goalFestDescription,
  };
  const fanduelData = {
    fanduelHeading,
    fanduelImage,
    fanduelLink,
  };

  return {
    props: {
      data,
      soccerPodData,
      goalFestData,
      fanduelData,
      // leagueData,
    },
    revalidate: 10,
  };
}
