import React from 'react';

const PrivacyPolicy = () => {
  return (
    <div className="lg:px-[0px] px-[15px] sm:px-[24px] mt-[48px] max-w-[806px] mx-auto section-tnc">
      <h1>Privacy Policy</h1>
      <p>
        At Soccerbx , LLC (Soccerbx, {"'we'"} {"us"} ) we process personal data
        about our customers, visitors to our websites and when you communicate
        with us or use our services {"'you'"}. We make efforts to handle your
        personal data with great care, keep it secure and comply with data
        protection laws.
      </p>
      <p>
        Soccerbx is engaged in content publishing, lead generation and general
        marketing in the sports marketplace The Policy explains when, why and
        how we process information which may relate to you ({"'personal data'"}
        ). It also provides important information on your statutory rights. This
        Policy is not intended to override the terms of any contract you have
        with us, nor rights you might have under data
      </p>
      <p>
        Soccerbx LLC having its registered office in Delaware and headquarters
        in Los Angeles California is principally responsible for looking after
        your personal data (your Data manager). While Soccerbx is mainly
        responsible, information may also be held in databases which can be
        accessed by other companies. When accessing your personal data, all
        companies will comply with the standards set out in this Policy.
      </p>
      <p>
        We may process the following personal data about you: <br />
        Name <br />
        Email address
        <br />
        Postal Address
        <br />
        IP Address
        <br />
        Location Data
        <br />
        Website usage
        <br />
        Gender
        <br />
        Age
        <br />
        Occupation
        <br />
      </p>
      <p>
        Any Information that you choose to provide us with, for example personal
        information about yourself, preferences, and interests Soccerbx will
        collect information directly from you when you communicate with us, use
        our services or visit our websites.
      </p>
      <p>We use your personal data to:</p>
      <ul>
        <li>Send you communications, and direct marketing </li>
        <li>
          Send you information or invitations for events related to Soccerbx
        </li>
        <li>Communicate with you, for example by phone or email.</li>
        <li>
          Analyze information in our systems and databases to improve the way we
          run our business and websites according to user preferences, to
          provide a better service and user experience.
        </li>
        <li>
          if we make available, register you for a chat forum or community in
          which you can provide comments
        </li>
        <li>Meet or exercise any of our legal obligations or rights.</li>
        <li>
          We will only process your personal data for the purposes set out in
          this Section 3 and where we are satisﬁed that:
        </li>
        <li>
          You have provided your consent to us using the data in that way, our
          use your personal data is necessary to support legitimate interests
          that we have as a business (carry our analytics, site improvement)
        </li>
      </ul>
      <h3>International Transfers</h3>
      <p>
        International Transfers mean that personal data is transferred to a
        country outside the European union.
      </p>
      <p>
        We may allow access to your personal data to third parties who may be
        located outside the USA{" "}
      </p>
      <p>
        We may also disclose your personal data if we receive a legal or
        regulatory request from a foreign law enforcement body outside the USA
      </p>
      <p>
        We will always take steps to ensure that any international transfer of
        information is managed to protect your rights and interests. Any
        requests for information that we receive from law enforcement or
        regulators will be carefully checked before personal data is disclosed.
      </p>
      <p>
        You have the right to ask us for more information about the safeguards
        we have put in place as mentioned above. Contact us if you wish further
        information.
      </p>
      <h3>Direct Marketing</h3>
      <p>
        We will use your personal data to send you direct marketing
        communications regarding Soccerbx . This may be in the form of email or
        targeted online advertisements.
        <br />
        <br />
        In some cases our processing of your personal data for marketing
        purposes will be based on our legitimate interests We required by law it
        will be based on your consent.
        <br />
        <br />
        You will always have a right to say no to further direct marketing, at
        any time. You can use the opt-out link that you find in all direct
        marketing communications, or by contacting us
        <br />
        <br />
        We take steps to limit direct marketing to a reasonable and
        proportionate level, and to send you communications that we believe may
        be of interest or relevance to you, based on the information we have
        about you.
        <br />
        <br />
        How long do we keep your personal data?
        <br />
        <br />
        We will retain your personal data for as long as reasonably necessary
        for the purposes listed in Section 3 of the Policy.
        <br />
        <br />
        In some circumstances we keep your personal data during a certain period
        to meet for example legal, tax or accounting requirements.
        <br />
        <br />
        We maintain a data retention policy for personal data in our care. Where
        your personal data is no longer required we will ensure it is either
        securely deleted or made anonymous.
        <br />
      </p>
      <h3>What are your rights?</h3>
      <div>
        You have a number of rights in relation to your personal data. More
        information about each of these rights can be found below.
        <br />
        <br />
        To exercise your rights you may contact us as by sending an email to
        cs@Soccerbx.com or writing to Soccerbx at the address set out xxxxx
        above.
        <br />
        <br />
        Please note the following if you wish to exercise your rights:
        <br />
        <br />
        To offer you a full range of functions when you visit our website,
        recognize your preferences, and make the use of our website more
        comfortable and convenient, we use “cookies.”
        <br />
        <br />
        <h4>Your Options</h4>
        <br />
        By using our website, you agree to the use and storage of cookies on
        your computer or device.
        <br />
        <br />
        You can generally view our website without cookies, but certain parts of
        the website may not work properly, or navigating be slower.
        <br />
        <br />
        If you do not wish cookies to be stored on your computer of device, you
        can deactivate the relevant option in the system setting of your browser
        at any time.
        <br />
        <br />
        Categories of cookies
        <br />
        <br />
        We us cookies for different purposes and with different functions.
      </div>
      <p>Some cookies are:</p>
      <ul>
        <li>Necessary in technical terms (technical necessity)</li>
        <li>Stored and used for a certain time period (storage duration)</li>
        <li>Placed and stored by us or a third party (cookie provider)</li>
      </ul>
      <h4>Storage duration</h4>
      <p>
        Session cookies: Some cookies are only needed for the duration of your
        website session, so called “session cookies”. They will be erased or
        become invalid as soon as you leave our website or your current session
        expires. Session cookies are used, for example, to retain certain
        information during your session.
        <br />
        <br />
        Permanent cookies: Some cookies are stored for a longer period. For
        example, it allows to recognize you when you access our website again at
        a later time and access saved settings. As a result, you can access
        webpage faster or with greater convenience, for example that you do not
        need t set certain options again, such as your chosen language.
        Permanent cookies are automatically delated after a predefined period.
        <br />
        <br />
        Flow cookies: These cookies are used for communication between our
        internal servers within Soccerbx . They are placed on your computer or
        device when you start navigating the website and deleted after the end
        of your navigation on the website. Flow cookies are given a unique
        identification number but does not allow us to draw any conclusions
        regarding the actual customer or user.
      </p>
      <h4>Cookies providers</h4>
      <p>
        Providers cookies: These are cookies are placed by us or the operator of
        our website, who is commissioned by us.
        <br />
        <br />
        Third-party cookies: “Third-party cookies” are stored and used by other
        organizations or websites , for example Web analytics tools. External
        providers may also use cookies to display advertising or to integrate
        content from social networks, such as social plugins. For further
        information on Web analytics tools and measurements of reach, please see
        below in this cookie policy.
        <br />
        <br />
        Use of cookies for Web analytics and reach measurement
        <br />
        <br />
        We use Google Analytics, a Web analytics service of Google Inc.
        (“Google”). Google Analytics uses cookies to identify the frequency of
        use of certain areas of our website and to identify preferences. The
        information regarding your use of this website that is generated by the
        cookie (including your truncated IP address) is transferred to a Google
        server in the United States and stored there. Google will use this
        information to analyze your use of the website, compile reposts on
        website activity for us, and perform further services associated with
        website use an Internet us. Google may also transmit this information to
        third parties where required by law or to the extent third parties
        process these data on behalf of Google.
        <br />
        <br />
        This add-on stores “opt-out” information on your device that serves to
        match up your deactivation of Google Analytics. Please note that this
        kind of “opt-out’ only leads to the deactivation of Google Analytics for
        the device and browser from which the opt out was activated. In
        addition, you may need to reactivate it if you delete cookies from your
        device.
      </p>
      <p>Our most common cookies are:</p>
      <p>
        <span>
          <b>Google:</b>
        </span>{" "}
        Placed by google to see how users interact with our site such as pages
        viewed , time on site , where user has visited.{" "}
      </p>
      <p>
        <span>
          <b>Facebook Pixel:</b>{" "}
        </span>
        Placed by Facebook and allows our site to optimize our audiences for
        advertising on campaigns delivered on facebook
      </p>
      <h4>Your Rights</h4>
      <p>You can ask Soccerbx at any time to</p>
      <ul>
        <li>Confirm whether we process your personal data</li>
        <li>Provide you with a copy of this data</li>
        <li>
          Provide you with other information as requested including how we use
          and protect it and how long we keep it for.
        </li>
        <li>You can ask to rectify any inaccurate data</li>
      </ul>
      <h4>Removal</h4>
      <p>
        You have the right to ask Soccerbx to remove your personal data but only
        where:
      </p>
      <ul>
        <li>It is no longer used for the purpose for which it was collected</li>
        <li>
          You have withdrawn your consent , if we collected data in this manner
        </li>
        <li>We processed your data unlawfully</li>
        <li>To comply with any legal request</li>
      </ul>
      <p>
        We are not required to remove your data if it may be needed to comply
        with any legal obligation or defense of any legal claim. There are
        additional reasons Soccerbx may not remove your data but we will
        endeavor to respect any request.
      </p>
      <h4>Objection</h4>
      <p>
        You can object to any processing of your personal data which we have
        legally collected and use for legitimate interests if you feel your
        rights outweigh our legitimate interest. We have the right however to
        assert our rights override your rights.
      </p>
      <h4>International</h4>
      <p>
        You have the right to ask us to provide you with a copy or reference to
        the safeguards under which your personal data is transferred outside the
        USA. We may redact any information that relates to commercial
        sensitivity.
      </p>
    </div>
  );
}

export default PrivacyPolicy;