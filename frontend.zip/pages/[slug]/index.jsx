import React, { useState, useEffect } from "react";
import AdBanner from "../../components/single/home/AdBanner";
import { calls } from "../../Services/PromiseHandler/PromiseHandler";
import Hero from "../../components/pagesComponents/Previews/Hero/Hero";
import PreviewCard from "../../components/pagesComponents/Previews/Card/Card";
import { useSelector } from "react-redux";
import Skeleton from "react-loading-skeleton";
import Head from "next/head";
import { useRouter } from "next/router";
import LeagueMatchCard from "../../components/pagesComponents/leagueMatchCard/Card/LeagueMatchCard";
import LeagueMatchHero from "../../components/pagesComponents/leagueMatchHero/LeagueMatchHero";

const League = () => {
  const [pastMatches, setPastMatches] = useState([]);
  const [upcomingMatches, setUpcomingMatches] = useState([]);
  const [currentMatch, setCurrentMatch] = useState([]);
  const [loading, setLoading] = useState(true);
  const router = useRouter();
  const { slug } = router.query;

  const fetchData = async () => {
    const res = await calls(`child/${slug}`, "get");
    const dataSet = [...res?.data];

    const usaTime = new Date().toLocaleString("en-US", {
      timeZone: "America/New_York",
    });

    const sortedArray = dataSet.sort((a, b) => {
      return (
        new Date(a.venueDateAndTime).getTime() -
        new Date(b.venueDateAndTime).getTime()
      );
    });

    const pastMatches = sortedArray?.filter((x) => {
      return (
        new Date(x.venueDateAndTime).getTime() <= new Date(usaTime).getTime() &&
        x?.status === "published"
      );
    });

    setPastMatches(pastMatches);
    const upcomingMatches = sortedArray?.filter((x) => {
      return (
        new Date(x.venueDateAndTime).getTime() >= new Date(usaTime).getTime() &&
        x?.status === "published"
      );
    });

    if (
      new Date(upcomingMatches[0]?.venueDateAndTime).getTime() - 3600000 <=
      new Date(usaTime).getTime()
    ) {
      pastMatches.push(upcomingMatches[0]);
      upcomingMatches.shift(1, 1);
    } else {
      if (
        new Date(
          pastMatches[pastMatches.length - 1]?.venueDateAndTime
        ).getTime() +
          7200000 <=
        new Date(usaTime).getTime()
      ) {
        if (upcomingMatches.length <= 0) {
          pastMatches.push(upcomingMatches[0]);
          upcomingMatches.shift(1, 1);
        }

        // upcomingMatches.shift(1, 1);
      }
    }

    setUpcomingMatches(upcomingMatches);

    let featuredtMatch = pastMatches[pastMatches.length - 1];

    if (pastMatches[pastMatches.length - 1]?.venueDateAndTime) {
      featuredtMatch = pastMatches[pastMatches.length - 1];
      setCurrentMatch(featuredtMatch);
      pastMatches.pop();
    } else if (!pastMatches[pastMatches.length - 1]?.venueDateAndTime) {
      featuredtMatch = pastMatches[pastMatches.length - 2];
      setCurrentMatch(featuredtMatch);
      pastMatches.pop();
      pastMatches.pop();
    }

    if (!featuredtMatch?.venueDateAndTime) {
      setCurrentMatch(upcomingMatches[0]);
      upcomingMatches.shift();
    }
    // let featuredtMatch = pastMatches[pastMatches.length - 1];
    // let featuredtMatchAlternative = pastMatches[pastMatches.length - 2];

    // if (featuredtMatch?.venueDateAndTime) {
    //   if (
    //     new Date(featuredtMatch?.venueDateAndTime).getTime() + 14400000 <
    //       new Date(usaTime).getTime() &&
    //     upcomingMatches[0]
    //   ) {
    //     setCurrentMatch(upcomingMatches[0]);
    //     upcomingMatches.shift();
    //   } else {
    //     setCurrentMatch(featuredtMatch);
    //     pastMatches.pop();
    //   }
    // } else if (!featuredtMatch?.venueDateAndTime) {
    //   if (
    //     new Date(featuredtMatchAlternative?.venueDateAndTime).getTime() +
    //       14400000 <
    //       new Date(usaTime).getTime() &&
    //     upcomingMatches[0]
    //   ) {
    //     setCurrentMatch(upcomingMatches[0]);
    //     upcomingMatches.shift();
    //   } else {
    //     setCurrentMatch(featuredtMatchAlternative);
    //     pastMatches.pop();
    //     pastMatches.pop();
    //   }
    // }
    // if (
    //   !featuredtMatch?.venueDateAndTime &&
    //   !featuredtMatchAlternative?.venueDateAndTime
    // ) {
    //   setCurrentMatch(upcomingMatches[0]);
    //   upcomingMatches.shift();
    // }
  };
  useEffect(() => {
    setLoading(false);
    slug && fetchData();
  }, [router.query]);

  return (
    <>
      <Head>
        <title>League | SoccerBx </title>
      </Head>

      {currentMatch ? (
        <div className="grid grid-cols-5">
          <div className="md:col-span-12 col-span-12">
            {loading ? (
              <div className="flex">
                <div className="border-r border-black sm:h-[500px] w-[50%] h-[200px]">
                  <Skeleton height="100%" width="100%" />
                </div>
                <div className="sm:h-[500px] w-[50%] h-[200px]">
                  <Skeleton height="100%" width="100%" />
                </div>
              </div>
            ) : (
              <LeagueMatchHero leagueSlug={slug} item={currentMatch} />
            )}
          </div>
        </div>
      ) : (
        <div></div>
      )}
      <div>
        <div className="grid grid-cols-12 gap-[15px] sm:px-3 xl:px-6 px-[16px] sm:mt-0 mt-2">
          {upcomingMatches
            // ?.filter((item) => item.status === "published")
            ?.map((item) => (
              <div
                key={item?._id}
                className="my-[10px] sm:my-[30px] mx-auto sm:col-span-6  lg:col-span-3 col-span-12 w-full">
                <LeagueMatchCard leagueSlug={slug} item={item} />
              </div>
            ))}
          {pastMatches
            // ?.filter((item) => item?.status === "published")
            ?.map((item) => (
              <div
                key={item?._id}
                className="my-[10px] sm:my-[30px] mx-auto sm:col-span-6  lg:col-span-3 col-span-12 w-full">
                <LeagueMatchCard leagueSlug={slug} item={item} />
              </div>
            ))}
        </div>
      </div>
    </>
  );
};

export default League;

// const fetchDate = async () => {
//   const res = await calls(`child/${slug}`, "get");

//   const dataSet = res?.data;

//   const usaTime = new Date().toLocaleString("en-US", {
//     timeZone: "America/New_York",
//   });

//   const sortedArray = dataSet?.sort((a, b) => {
//     return (
//       new Date(a.venueDateAndTime).getTime() -
//       new Date(b.venueDateAndTime).getTime()
//     );
//   });

//   const pastMatches = sortedArray?.filter((x) => {
//     return (
//       new Date(x.venueDateAndTime).getTime() <= new Date(usaTime).getTime()
//     );
//   });

//   setPastMatches(pastMatches);

//   const upcomingMatches = sortedArray?.filter((x) => {
//     return (
//       new Date(x.venueDateAndTime).getTime() >= new Date(usaTime).getTime()
//     );
//   });

//   if (
//     new Date(upcomingMatches[0]?.venueDateAndTime).getTime() - 3600000 <=
//     new Date(usaTime).getTime()
//   ) {
//     pastMatches.push(upcomingMatches[0]);
//     upcomingMatches.shift(1, 1);
//   } else {
//     if (
//       new Date(
//         pastMatches[pastMatches.length - 1]?.venueDateAndTime
//       ).getTime() +
//         7200000 <=
//       new Date(usaTime).getTime()
//     ) {
//       if (upcomingMatches.length <= 0) {
//         pastMatches.push(upcomingMatches[0]);
//       }

//       upcomingMatches.shift(1, 1);
//     }
//   }

//   setUpcomingMatches(upcomingMatches);

//   let currentMatch = pastMatches[pastMatches?.length - 1];

//   setCurrentMatch(currentMatch);

//   pastMatches.pop();
// };

// const fetchDate = async () => {
//   try {
//     const response = await calls(`child/${slug}`, "get");

//     if (!response?.data) {
//       throw new Error("No data found");
//     }

//     const sortedMatches = response.data
//       .map((match) => ({
//         ...match,
//         venueDateAndTime: new Date(match.venueDateAndTime),
//       }))
//       .sort((a, b) => b.venueDateAndTime - a.venueDateAndTime);

//     const now = new Date();
//     const pastMatches = [];
//     const upcomingMatches = [];

//     for (const match of sortedMatches) {
//       if (match.venueDateAndTime < now) {
//         pastMatches.push(match);
//       } else {
//         upcomingMatches.push(match);
//       }
//     }

//     // If the first upcoming match has already started, move it to pastMatches
//     if (
//       upcomingMatches.length > 0 &&
//       upcomingMatches[0].venueDateAndTime < now
//     ) {
//       pastMatches.push(upcomingMatches.shift());
//     }

//     setPastMatches(pastMatches);
//     setUpcomingMatches(upcomingMatches);
//     setLoading(false);
//   } catch (error) {
//     console.error("Error fetching data:", error);
//     // Handle error state here
//   }
// };

// useEffect(() => {
//   setLoading(false);
//   fetchDate();
// }, [slug]);
