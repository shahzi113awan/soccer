import React, { useEffect, useState } from "react";
import Skeleton from "react-loading-skeleton";
// import { useDispatch, useSelector } from "react-redux";
import "react-loading-skeleton/dist/skeleton.css";
import Link from "next/link";

import BigCard from "../../../components/pagesComponents/News/Cards/BigCard";
import { calls } from "../../../Services/PromiseHandler/PromiseHandler";
import Head from "next/head";

const AllNewsForLeagues = ({ data }) => {
  // const dispatch = useDispatch();
  // const router = useRouter();
  const [loading, setLoading] = useState(true);
  const [featuredNews, setFeaturedNews] = useState([]);
  const [allNews, setAllNews] = useState([]);

  // const {
  //   query: { slug, id },
  // } = router;

  const getFeatures = async () => {
    // const res = await calls(`news/one-league/${slug}`, "get");
    let allNews = data?.filter(
      (item) => item?.status === "published" && !item?.isScheduled
    );
    let featuredNews = allNews[0] ?? "";
    allNews.shift();
    setLoading(false);
    setAllNews(allNews);
    setFeaturedNews(featuredNews);
  };

  useEffect(() => {
    getFeatures();
  }, []);

  return (
    <>
      <Head>
        <title>All News | SoccerBx </title>
      </Head>
      {!allNews?.length && !loading ? (
        <h1>No Data Found :( </h1>
      ) : (
        <>
          <Link
            href={`/news/${featuredNews?.league?.slug}/${featuredNews?.slug}`}>
            <div className="cursor-pointer">
              <div className="flex xs:flex-row">
                <div className="flex-1 flex w-full items-center justify-center bg-black max-w-[50%]">
                  <ul className="text-center uppercase">
                    <li>
                      <h1 className="sm:text-[50px] text-[27px] md:text-[80px] sm:leading-[65px] leading-[23px] text-white">
                        {featuredNews?.title?.split(" ")?.[0] ?? ""}
                      </h1>
                    </li>
                    <li>
                      <h1 className="sm:text-[50px] text-[27px] md:text-[80px] sm:leading-[65px] leading-[23px] text-white">
                        {featuredNews?.title?.split(" ")?.[1] ?? ""}
                      </h1>
                    </li>
                    <li>
                      <h1 className="sm:text-[50px] text-[27px] md:text-[80px] sm:leading-[65px] leading-[23px] text-white">
                        {featuredNews?.title?.split(" ")?.[2] ?? ""}
                      </h1>
                    </li>
                  </ul>
                </div>
                <div className="flex-1 max-w-[50%]">
                  {loading && !featuredNews?.featuredImage ? (
                    <Skeleton height={300} width="100%" />
                  ) : (
                    <img
                      src={featuredNews?.featuredImage}
                      alt={featuredNews?.title ?? ""}
                      width="100%"
                      className={`lg:h-[640px] sm:min-h-48 md:min-h-[400px] lg:w-[640px] sm:w-full w-full h-[187px]  object-cover ${
                        !Boolean(featuredNews?.featuredImage) && "no-image_img"
                      }`}
                    />
                  )}
                </div>
              </div>
            </div>
          </Link>

          <div className="grid grid-cols-12 gap-3 mt-3 mb-5 px-5">
            {loading ? (
              <>
                {["sk1", "sk2", "sk3", "sk4"].map((x) => (
                  <div
                    className="sm:col-span-4 md:col-span-3 col-span-12 my-3"
                    key={x}>
                    <Skeleton height={200} width="100%" />
                  </div>
                ))}
              </>
            ) : (
              <>
                {allNews
                  ?.map((item) => (
                    <div
                      className="sm:col-span-4 md:col-span-3 col-span-12 my-3"
                      key={item?._id}>
                      <BigCard
                        img={item?.featuredImage}
                        slug={`/news/${item?.league?.slug}/${item?.slug}`}
                        author={item?.author?.name}
                        title={item?.title}
                        commentsLength={item?.commentsCount}
                        excerpt={item?.excerpt}
                        leagueTag={item.league?.slug || ""}
                        leagueId={item.league?.slug || ""}
                      />
                    </div>
                  ))}
              </>
            )}
          </div>
          <div className="flex justify-end my-2 ">
            <Link href="/news">
              <a className="flex items-center gap-2 text-white bg-soccer-red hover:bg-[#1D71B3] py-2 px-4 rounded-lg  focus:outline-none focus:ring-2 focus:ring-[#1D71B3] focus:ring-opacity-50">
                <svg className="w-5 h-5" viewBox="0 0 24 24">
                  <path
                    fill="currentColor"
                    d="M14.59 7.41L13.17 6L6.17 13L5.17 14L6.59 15.41L13.17 22L14.59 20.59L8.83 15H20V13H8.83L14.59 7.41Z"
                  />
                </svg>
                <span>Go Back</span>
              </a>
            </Link>
          </div>
        </>
      )}
    </>
  );
};

export default AllNewsForLeagues;

export async function getServerSideProps(ctx) {
  try {
    const res = await calls(`news/one-league/${ctx.query.slug}`, "get");

    const data = res?.data ?? [];
    return {
      props: {
        data,
      },
    };
  } catch (error) {
    console.error(error);
    return {
      props: {
        data: [],
      },
    };
  }
}
