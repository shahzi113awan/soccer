import { useEffect, useState } from "react";
import {
  getAdImage,
  getSingleNewsData,
} from "../../../../Services/News/news.service";
import { FaFacebookF, FaShare, FaTwitter, FaWhatsapp } from "react-icons/fa";
import Link from "next/link";
import { MdOutlineChatBubble } from "react-icons/md";
import Head from "next/head";
import { AiOutlineArrowRight } from "react-icons/ai";
import { useRouter } from "next/router";
import Skeleton from "react-loading-skeleton";
import "react-loading-skeleton/dist/skeleton.css";
import {
  FacebookShareButton,
  TwitterShareButton,
  WhatsappShareButton,
} from "react-share";
import parse from "html-react-parser";
import { calls } from "../../../../Services/PromiseHandler/PromiseHandler";

// geting image urls and wraping it in html
const getImageAndReplaceWithHtml = async (id) => {
  const data = await getAdImage(id);
  if (data?.data?.url) {
    if (data?.data?.type === "image") {
      return `<a class='py-4 block addFor-${
        data?.data?.adPosition
      }' href='//${data?.data?.linkTo.trim()}' target="_blank"><img src=${
        data?.data?.url
      } alt="CHANGE_ME" width="100%"/></a>`;
    }
    if (data?.data?.type === "video") {
      return `<a class='py-4 block addFor-${
        data?.data?.adPosition
      }' href='//${data?.data?.linkTo.trim()}' target="_blank">
      <video loop muted autoPlay playsinline src="${
        data?.data?.url
      }" width="100%">
  
  Your browser does not support HTML video.</video>
      </a>`;
    }
  }

  return "";
};

const replaceShortCodesWithAds = async (html) => {
  const tempArr = html?.split("~[SC~");

  const ids = [];
  tempArr?.forEach((f, i) => (i % 2 !== 0 ? ids.push(f.trim()) : f));
  if (ids?.length) {
    const updateHtml = await Promise.all(
      tempArr?.map(async (t) => {
        return ids?.includes(t.trim())
          ? await getImageAndReplaceWithHtml(t?.trim())
          : t?.replace(/\r?\n|\r/g, "");
      })
    );
    return updateHtml?.join("");
  }
  return html?.replace(/\r?\n|\r/g, "");
};
const monthNames = [
  "",
  "January",
  "February",
  "March",
  "April",
  "May",
  "June",
  "July",
  "August",
  "September",
  "October",
  "November",
  "December",
];
const SingleNews = ({ data }) => {
  const [dataToShow, setDataToShow] = useState({});
  const [shareURL, setShareURL] = useState("");
  const [loading, setLoading] = useState(true);
  const [nextArticle, setNextArticle] = useState({});
  const [sidebarAds, setSidebarAds] = useState([]);
  const [mainContent, setMainContent] = useState(null);
  const [metaTitle, setMetaTitle] = useState("");
  const [metaDescription, setMetaDescription] = useState("");
  const [metaKeyword, setMetaKeyword] = useState("");
  const [altText, setAltText] = useState("");
  const router = useRouter();

  const {
    query: { slug, id },
  } = router;
  const handleNextNews = (article) => {
    const { _id: id } = article?.next;

    if (id) {
      router.push(
        "/news/[slug]/[id]",
        `/news/${data?.league?.slug}/${nextArticle?.next?.slug}`,

        {
          shallow: true,
        }
      );
      getNextArticle(id);
    }
  };
  const getNextArticle = async (id) => {
    const res = await getSingleNewsData(id);
    setNextArticle(res?.data);
  };

  const resolvePromise = async (id) => {
    const data = await getAdImage(id);
    return data?.data;
  };
  const getSidebarAds = async (ids) => {
    const res = await Promise.all(
      ids?.split(",")?.map(async (id) => {
        return await resolvePromise(id);
      })
    );
    setSidebarAds(res.filter((x) => x));
  };
  let mounted = false;
  useEffect(() => {
    if (!mounted) {
      if (data?._id) {
        setDataToShow(data);
        setLoading(false);
        getNextArticle(data?._id);
        if (data?.sidebarAds?.length > 0) {
          getSidebarAds(data?.sidebarAds);
        }
      }
    }
    mounted = true;
  }, []);
  useEffect(() => {
    // iife
    (async () => {
      setLoading(true);
      const res = await getSingleNewsData(id);
      let content = await replaceShortCodesWithAds(res?.data?.content);
      let metaTitle = res?.data?.meta_title ?? "";
      let metaDescription = res?.data?.meta_des ?? "";
      let metaKeyword = res?.data?.meta_keyword ?? "";
      let altText = res?.data?.altText ?? "";

      const paragraphs = content?.match(/<p>(.*?)<\/p>/g) ?? [];
      paragraphs?.forEach(function (p) {
        if (p.includes("youtube.com/watch?v=")) {
          const videoId = p.split("v=")[1].split("&")[0];
          const iframe = `<iframe src="https://www.youtube.com/embed/${videoId}" frameBorder="0" width="100%" height="315" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowFullscreen></iframe>`;
          content = content.replace(p, iframe);
        }
        if (p.includes("youtu.be/")) {
          const videoId = p.split("be/")[1].split(" ")[0];
          const iframe = `<iframe src="https://www.youtube.com/embed/${videoId}" frameBorder="0" width="100%" height="315" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowFullscreen></iframe>`;
          content = content.replace(p, iframe);
        }
      });
      setAltText(altText);
      setMetaTitle(metaTitle);
      setMetaDescription(metaDescription);
      setMetaKeyword(metaKeyword);
      setMainContent(content?.replace(/&nbsp;/g, " "));
      setDataToShow(res?.data);
      setShareURL(
        typeof window !== "undefined"
          ? window?.location?.href
          : "https://www.soccerbx.com"
      );
      setLoading(false);
    })();
  }, [id, data, slug]);

  const createdAt = () => {
    const d = new Date(dataToShow?.createdAt);

    return `${d?.getDate()} ${
      monthNames[d.getMonth() + 1]
    } ${d?.getFullYear()}`;
  };

  const updateTime = (date) => {
    const time = new Date(date);
    const today = new Date();
    // converting time to usa timeZone.
    const americanTime = new Date(
      time?.toLocaleString("en-US", {
        timeZone: "America/New_York",
      })
    );

    if (
      time?.getMonth() === today?.getMonth() &&
      time?.getDate() === today.getDate()
    ) {
      return `${americanTime.getHours()}:${
        americanTime.getMinutes() < 9
          ? "0" + americanTime.getMinutes()
          : americanTime.getMinutes()
      }`;
    }
    return `${time?.getDate()} ${
      monthNames[time.getMonth() + 1]
    } ${time?.getFullYear()}`;
  };
  return (
    <div>
      <Head>
        <meta charset="utf-8" />
        <meta name="author" content={dataToShow?.author?.name ?? ""} />
        {/* <meta name="title" content={dataToShow?.title ?? ""} /> */}
        <meta name="title" content={metaTitle ?? ""} />

        {/* <meta name="description" content={dataToShow?.excerpt} /> */}
        <meta name="description" content={metaDescription ?? ""} />
        {/* <!-- Mobile Stuff --> */}
        <meta httpEquiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <meta name="msapplication-tap-highlight" content="no" />

        {/* Chrome on Android */}
        <meta name="mobile-web-app-capable" content="yes" />
        <meta name="application-name" content="SoccerBx" />

        {/* <!-- Safari on iOS --> */}
        <meta name="apple-mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-status-bar-style" content="black" />
        <meta name="apple-mobile-web-app-title" content="CHANGE-ME" />

        {/* <!-- Windows 8 --> */}
        <meta
          name="msapplication-TileImage"
          content={dataToShow?.featuredImage}
        />
        <meta name="msapplication-TileColor" content="#FFFFFF" />

        <meta name="theme-color" content="#000000" />

        {!loading && <title>{dataToShow?.title}</title>}

        <meta
          property="og:title"
          content={dataToShow?.title ?? "Soccerbet News"}
        />
        <meta
          property="og:description"
          content={
            dataToShow?.subTitle ??
            "We are a soccer company dedicated to serving the changing landscape of soccer in the USA"
          }
        />
        <meta
          property="og:image"
          content={
            dataToShow?.featuredImage ?? "/images/homepage/hero-bg-lg.jpg"
          }
        />
        <meta
          property="og:url"
          content={shareURL ?? "https://www.soccerbx.com"}
        />

        <meta name="og:card" content="summary_large_image" />
      </Head>
      {!dataToShow?._id && !loading ? (
        <h1>No Data Found :( </h1>
      ) : (
        <>
          <div className="flex flex-row-reverse">
            <div className="flex-1 bg-black  max-w-[50%]">
              {loading ? (
                <Skeleton className=" sm:h-[500px] h-[200px]" width="100%" />
              ) : (
                <picture>
                  <source srcSet={dataToShow?.featuredImage} />
                  <source srcSet={dataToShow?.featuredImage} />
                  <img
                    src={dataToShow?.featuredImage}
                    alt={altText ?? ""}
                    className={`lg:h-[640px] sm:min-h-48 md:min-h-[400px] lg:w-[640px] sm:w-full w-full h-[187px]  object-cover ${
                      !Boolean(dataToShow?.featuredImage) && "no-image_img"
                    }`}
                    role="presentation"
                  />
                </picture>
              )}
            </div>
            {loading ? (
              <div className="border-r border-black	 w-[50%]">
                <Skeleton className=" sm:h-[500px] h-[200px]" width="100%" />
              </div>
            ) : (
              <div className="flex-1 flex w-full items-center justify-center bg-black max-w-[50%]">
                <ul
                  className="text-center"
                  style={{ textTransform: "uppercase", lineHeight: "1" }}>
                  <li>
                    <h1 className="text-[33px] sm:text-[43px] md:text-[70px] lg:text-[100px] leading-[0.75] md:leading-[0.77] text-white">
                      {dataToShow?.title?.split(" ")?.[0] ?? ""}
                    </h1>
                  </li>
                  <li>
                    <h1 className="text-[33px] sm:text-[43px] md:text-[70px] lg:text-[100px] leading-[0.75] md:leading-[0.77] text-white">
                      {dataToShow?.title?.split(" ")?.[1] ?? ""}
                    </h1>
                  </li>
                  <li>
                    <h1 className="text-[33px] sm:text-[43px] md:text-[70px] lg:text-[100px] leading-[0.75] md:leading-[0.77] text-white">
                      {dataToShow?.title?.split(" ")?.[2] ?? ""}
                    </h1>
                  </li>
                </ul>
              </div>
            )}
          </div>

          <div className="sm:px-10 px-3">
            <div className="mx-auto md:grid grid-cols-12 flex items-start justify-between hidden">
              <div className="md:col-span-3 mt-3 hidden sm:block text-[12px]">
                Photo Credit
              </div>
              <div className="md:col-span-9 flex justify-between items-top lg:mt-[36px]">
                <h2 className="text-left text-[24px] font-[500] leading-[28px] uppercase ">
                  {/* <Link href={`/${dataToShow?.league?.slug ?? ""}`}> */}
                  <Link href={`/${dataToShow?.league?.slug}`}>
                    <p className="text-xs font-medium mr-1 mb-3 cursor-pointer">
                      <span className="bg-zinc-300 p-1 rounded-sm">
                        {dataToShow?.league?.slug}
                      </span>
                    </p>
                  </Link>
                  <div className="max-w-[600px]">
                    {dataToShow?.subTitle || ""}
                  </div>
                </h2>

                {nextArticle?.next?.slug && (
                  <div className="text-right mb-3 ml-auto inline-flex">
                    <button
                      title={nextArticle?.next?.title ?? ""}
                      className={`${
                        !nextArticle?._id ? "color-[#6B6B6B]" : "cursor-pointer"
                      } leading-[1] border-b-2 border-color-[#6B6B6B]`}
                      disabled={!nextArticle?.next?._id}
                      onClick={() => handleNextNews(nextArticle)}>
                      Next Story
                      {/* <AiOutlineArrowRight /> */}
                    </button>
                  </div>
                )}
              </div>
            </div>

            <div className="mx-auto grid grid-cols-12 mb-[56px]">
              <div className="md:col-span-3 col-span-12 border-b-2 md:border-b-0 sm:pb-3 sm:mb-6 mobile-linear-border">
                <div className="flex sm:flex-col flex-row-reverse items-start sm:items-stretch w-full justify-between sm:max-w-[200px] mt-[16px] md:mt-[38px]">
                  <div className="flex py-1 pb-[8px] sm-linear-border items-center">
                    <span className="mr-2">
                      <FaShare />
                    </span>
                    <FacebookShareButton
                      // url={window?.location?.href ?? "https://www.soccerbx.com"}
                      // url={
                      //   typeof window !== "undefined" &&
                      //   (window?.location?.href ?? "https://www.soccerbx.com")
                      // }
                      // quote={"This is a testing quote"}
                      // hashtag={"#soccerBx"}
                      // >

                      // title="Leicester v Liverpool "
                      // quote="Leicester v Liverpool subtile"
                      url={shareURL}>
                      <div className="h-[24px] w-[24px] flex items-center justify-center bg-black rounded-full">
                        <FaFacebookF className="fill-white" />
                      </div>
                    </FacebookShareButton>

                    <TwitterShareButton
                      title="Leicester v Liverpool "
                      url={shareURL}>
                      <div className="ml-2 h-[24px] w-[24px] flex items-center justify-center bg-black rounded-full">
                        <FaTwitter className="fill-white" />
                      </div>
                    </TwitterShareButton>

                    <WhatsappShareButton
                      title="Leicester v Liverpool "
                      url={shareURL}>
                      <div className="ml-2 h-[24px] w-[24px] flex items-center justify-center bg-black rounded-full">
                        <FaWhatsapp className="fill-white" />
                      </div>
                    </WhatsappShareButton>
                    {/* <a
                      target="_blank"
                      className="h-[24px] w-[24px] flex items-center justify-center bg-black rounded-full ml-2"
                      href={`https://twitter.com/intent/tweet?text=${
                        typeof window !== "undefined" && window?.location?.href
                      }`}
                      rel="noreferrer">
                      <FaTwitter className="fill-white" />
                    </a> */}
                  </div>
                  <div>
                    <strong className="text-[12px] mb-[16px] inline-block">
                      {/* {dataToShow?.author?.name ?? "Unknown"} */}
                      Soccerbx Team
                    </strong>
                    {<div className="text-[12px]">{createdAt()}</div>}
                    {dataToShow?.lastUpdate && (
                      <div className="text-[12px]">
                        Updated {updateTime(dataToShow?.lastUpdate)} EST
                      </div>
                    )}
                  </div>
                </div>
                {/* <div className="flex items-center py-[8px]">
                  <MdOutlineChatBubble />{" "}
                  <span className="text-[12px] pl-[3px]">
                    {dataToShow?.comments?.length ?? 0}
                  </span>
                </div> */}
              </div>

              <div className="mt-5 newsMain-content_f_ads col-span-12 md:col-span-6">
                <div className="flex flex-col sm:flex-row">
                  <div className=" max-w-[600px] break-words">
                    <h2 className="md:hidden text-[24px] font-[500] leading-[28px] uppercase">
                      {dataToShow?.subTitle || ""}
                    </h2>
                    <div
                      className="overflow-hidden editorContent"
                      style={{ wordBreak: "break-word" }}>
                      {parse(mainContent ?? "")}
                    </div>
                  </div>
                </div>
              </div>
              <div className="md:col-span-3 col-span-12 border-b-2 md:border-b-0 sm:pb-3 sm:mb-6 flex flex-col sm:block hidden md:pl-5">
                {sidebarAds?.length > 0 &&
                  sidebarAds?.map((ad, i) => (
                    <div key={i} className="my-4">
                      <a
                        rel="noreferrer"
                        target="_blank"
                        href={`//${ad?.linkTo}`}>
                        {ad?.type === "image" ? (
                          <img width="100%" src={ad?.url} alt="CHANGE_ME" />
                        ) : (
                          <video muted loop autoPlay width="100%">
                            <source src={ad?.url} type="video/mp4" />
                            Your browser does not support HTML video.
                          </video>
                        )}
                      </a>
                    </div>
                  ))}
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  );
};

export default SingleNews;

// export default function SingleNewsData({ data }) {
//   const [nextArticle, setNextArticle] = useState({});

//   const getNextArticle = async (id) => {
//     const res = await getSingleNewsData(id);

//     console.log("id", id);
//     setNextArticle(res?.data);
//     console.log("nextArticle--->>", res?.data);
//   };
//   useEffect(() => {
//     getNextArticle(data?._id);
//   }, []);
//   console.log("data in export function", data);
//   return (
//     <>
//       <Link href={`/news/${data?.league?.slug}/${nextArticle?.next?.slug}`}>
//         link to next article
//       </Link>
//       <br />
//       {nextArticle?.next?.slug}
//       <br />
//       {data?.slug} == {nextArticle?.next?.slug}
//     </>
//   );
// }

// export async function getStaticProps({ params }) {
//   const { slug } = params;
//   const data = await getSingleNewsData(slug);
//   return {
//     props: {
//       data: data?.data,
//     },
//   };
// }

// export async function getStaticPaths() {
//   const res = await calls("news");

//   console.log(res.data);

//   const paths = res?.data?.map((item) => ({
//     params: {
//       slug: item.slug.toString(),
//     },
//   }));

//   return {
//     paths,
//     fallback: true,
//   };
// }

export async function getServerSideProps(ctx) {
  const res = await getSingleNewsData(ctx.query.id);

  return {
    props: {
      data: res?.data,
    },
  };
}
