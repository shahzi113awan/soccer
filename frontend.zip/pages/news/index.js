import React, { useState } from "react";
import Head from "next/head";
import { getLeagueNews } from "../../Services/News/news.service";
import BigCard from "../../components/pagesComponents/News/Cards/BigCard";
import Loaders from "../../components/pagesComponents/News/Loaders/Loaders";
import Link from "next/link";
import Skeleton from "react-loading-skeleton";
import Image from "next/image";

const AllNews = ({ data }) => {
  const [loading, setLoading] = useState(false);
  console.log({ data });
  const filterData = data?.news;
  // ?? data?.[0]?.news?.[0];
  const latestHeaderNews = data?.[0]?.news.filter(
    (news) => news?.status === "published" && !news?.isScheduled
  );
  const headerData = data?.pinned[0]?.news[0];
  // [0] ?? latestHeaderNews ? latestHeaderNews[0] : "";
  // console.log("merge")
  return (
    <div>
      <Head>
        <title>News | SoccerBx </title>
      </Head>
      {headerData && (
        <Link href={`/news/${headerData?.slug}/${headerData?.slug ?? ""}`}>
          <a>
            <div className="flex xs:flex-row">
              <div className="flex-1 flex w-full items-center justify-center bg-black max-w-[50%]">
                <ul className="text-center uppercase">
                  <li>
                    <h1 className="text-[33px] sm:text-[43px] md:text-[70px] lg:text-[100px] leading-[0.75] md:leading-[0.77] text-white">
                      {headerData?.title?.split(" ")?.[0] ?? ""}
                    </h1>
                  </li>
                  <li>
                    <h1 className="text-[33px] sm:text-[43px] md:text-[70px] lg:text-[100px] leading-[0.75] md:leading-[0.77] text-white">
                      {headerData?.title?.split(" ")?.[1] ?? ""}
                    </h1>
                  </li>
                  <li>
                    <h1 className="text-[33px] sm:text-[43px] md:text-[70px] lg:text-[100px] leading-[0.75] md:leading-[0.77] text-white">
                      {headerData?.title?.split(" ")?.[2] ?? ""}
                    </h1>
                  </li>
                </ul>
              </div>
              <div className="flex-1">
                {loading ? (
                  <Skeleton height={300} width="100%" />
                ) : (
                  <div className="relative">
                    <div
                      className={`w-[160px] h-[187px] sm:w-[212px] sm:h-[187px] md:w-[384px] md:h-[400px] lg:w-[512px] lg:h-[640px] xl:w-[640px] xl:h-[640px] sm:min-h-48 md:min-h-[400px] object-cover ${
                        !Boolean(headerData?.featuredImage) && "no-image_img"
                      }`}>
                      <Image
                        src={headerData?.featuredImage}
                        layout="fill"
                        objectFit="cover"
                        objectPosition="center"
                        alt="CHANGE_ME"
                      />
                    </div>
                  </div>
                  // <img
                  //   src={headerData?.featuredImage}
                  //   alt={headerData?.title ?? ""}
                  //   width="100%"
                  //   className={`lg:h-[640px] sm:min-h-48 md:min-h-[400px] lg:w-[640px] sm:w-full w-full h-[187px] object-cover ${
                  //     !Boolean(headerData?.featuredImage) && "no-image_img"
                  //   }`}
                  // />
                )}
              </div>
            </div>
          </a>
        </Link>
      )}
      {data?.news.map((league) => (
        <div key={league._id} id={league?.leagueSlug} className="">
          {league?.news?.filter(
            (item) => item.status === "published" && !item.isScheduled
          ).length > 0 && (
            <div className="border p-3 mx-2 my-4">
              <h1 className="text-xl font-bold mb-2">
                {league?.leagueTitle ?? ""}
              </h1>
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-2">
                {league.news?.slice(0, 4)
                  .map((newsItem) => (
                newsItem._id !=headerData._id &&    <div key={newsItem._id} className="">
                      <BigCard
                        img={newsItem.featuredImage || ""}
                        slug={`/news/${league.leagueSlug}/${newsItem.slug}`}
                        author={newsItem.author?.name || ""}
                        title={newsItem.title || ""}
                        commentsLength={newsItem.commentsCount || 0}
                        excerpt={newsItem.excerpt || ""}
                        leagueTag={league.leagueSlug || ""}
                        leagueId={newsItem?.slug || ""}
                      />
                    </div>
                  ))}
              </div>
              {league.news.length > 4 && (
                <div className="flex justify-end my-2">
                  <Link href={`/news/${league?.leagueSlug}`}>
                    <a className="flex items-center gap-2 text-white bg-soccer-red hover:bg-[#1D71B3] py-2 px-4 rounded-lg  focus:outline-none focus:ring-2 focus:ring-[#1D71B3] focus:ring-opacity-50">
                      <span>See all</span>
                      <svg className="w-5 h-5" viewBox="0 0 24 24">
                        <path fill="currentColor" d="M9 18L15 12L9 6V18Z" />
                      </svg>
                    </a>
                  </Link>
                </div>
              )}
            </div>
          )}
        </div>
      ))}
      {/* <button onClick={handlePagination} className="btn btn-blu">Load more</button> */}
    </div>
  );
};

export default AllNews;

export async function getServerSideProps() {
  try {
    const res = await getLeagueNews();
    const data = res?.data ?? [];
    return {
      props: {
        data,
      },
    };
  } catch (error) {
    console.error(error);
    return {
      props: {
        data: [],
      },
    };
  }
}
