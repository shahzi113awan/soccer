import React from "react";
import Head from "next/head";
import Image from "next/image";

const SoccerAcademy = () => {
  const [isMounted, setIsMounted] = React.useState(false);
  React.useEffect(() => {
    setIsMounted(true);
  }, []);
  return (
    isMounted && (
      <>
        <Head>
          <title>Soccerbet Academy | SoccerBx </title>
        </Head>
        <div className="bg-black">
          <div className="sm:p-5 p-4 bg-black text-center linear-border-b-5">
            <img
              className="mx-auto"
              src="/images/soccerbet-logo.svg"
              alt="SoccerBet"
            />
          </div>

          <section className="sm:p-5 p-4 linear-border-b-5">
            <div className="py-5 flex justify-between">
              <div className="sm:pl-4 sm:border-l border-[#fff] flex-1 h-fit">
                <h1 className="text-[20px] sm:text-[26px] text-white uppercase">
                  U.S. Legal Sports Betting
                </h1>
                <p className="text-white">
                  Legal landscape as of June 23, 2022
                </p>
              </div>
              <div className="hidden sm:flex justify-between flex-1">
                <div>
                  <div className="flex items-start sm:items-center">
                    <div className="max-w-[18px] min-w-[18px]  min-h-[18px] max-h-[18px] h-[18px] bg-[#D40000]" />
                    <span className="pl-2 text-white text-[10px] leading-[12px]">
                      <div>Live, Legal</div> (30 states & DC)
                    </span>
                  </div>
                  <div className="flex items-start sm:items-center pt-3">
                    <div className="max-w-[18px] min-w-[18px]  min-h-[18px] max-h-[18px] h-[18px] bg-[#fff]" />
                    <span className="pl-2 text-white text-[10px] leading-[12px]">
                      <div>No Legislation in 2022</div> (3 states)
                    </span>
                  </div>
                </div>
                <div>
                  <div className="flex items-start sm:items-center">
                    <div className="max-w-[18px] min-w-[18px]  min-h-[18px] max-h-[18px] h-[18px] bg-[#D45C59]" />
                    <span className="pl-2 text-white text-[10px] leading-[12px]">
                      <div>Legal - Not Operational</div> (5 states)
                    </span>
                  </div>
                  <div className="flex items-start sm:items-center pt-3">
                    <div className="max-w-[18px] min-w-[18px]  min-h-[18px] max-h-[18px] h-[18px] bg-[#899999]" />
                    <span className="pl-2 text-white text-[10px] leading-[12px]">
                      <div>Dead Legislation in 2022</div> (9 states)
                    </span>
                  </div>
                </div>

                <div>
                  <div className="flex items-start sm:items-center">
                    <div className="max-w-[18px] min-w-[18px]  min-h-[18px] max-h-[18px] h-[18px] bg-[#DBA500]" />
                    <span className="pl-2 text-white text-[10px] leading-[12px]">
                      <div>Active or Pre-Filed </div>
                      <div>Legislation/Ballot </div>
                      (3 states)
                    </span>
                  </div>
                </div>
              </div>
            </div>
            <div className="relative h-full">
              <div className="w-[200px] h-[235px] sm:w-[393px] sm:h-[235px] md:w-[728px] md:h-[435px] lg:w-[984px] lg:h-[588px] xl:w-[1240px] xl:h-[741px]">
                <Image
                  src="/images/Soccerbx-map.svg"
                  layout="fill"
                  objectFit="cover"
                  objectPosition="center"
                  alt="map"
                />
              </div>
            </div>
            {/* <img src="/images/Soccerbx-map.svg" width="100%" alt="SoccerBx" /> */}
            <div className="sm:mx-5 my-5">
              <div className="flex pt-3 border-t border-[#fff]">
                <div className="sm:p-3 flex-[2]">
                  <div className="flex items-start sm:items-center">
                    <div className="max-w-[18px] min-w-[18px]  min-h-[18px] max-h-[18px] h-[18px] bg-[#D40000]" />
                    <span className="pl-2 text-white text-[10px] leading-[12px]">
                      <div>Live, Legal</div> (30 states & DC)
                    </span>
                  </div>
                  <ul className="pt-3 sm:columns-3">
                    <li className="text-white text-[14px]">Washington</li>
                    <li className="text-white text-[14px]">Oregon</li>
                    <li className="text-white text-[14px]">Nevada</li>
                    <li className="text-white text-[14px]">Arizona</li>
                    <li className="text-white text-[14px]">Montana</li>
                    <li className="text-white text-[14px]">Wyoming</li>
                    <li className="text-white text-[14px]">Colorado</li>
                    <li className="text-white text-[14px]">New Mexico</li>
                    <li className="text-white text-[14px]">North Dakota</li>
                    <li className="text-white text-[14px]">South Dakota</li>
                    <li className="text-white text-[14px]">Iowa</li>
                    <li className="text-white text-[14px]">Arkansas</li>
                    <li className="text-white text-[14px]">Louisiana</li>
                    <li className="text-white text-[14px]">Wisconsin</li>
                    <li className="text-white text-[14px]">Illinois</li>
                    <li className="text-white text-[14px]">Mississippi</li>
                    <li className="text-white text-[14px]">Michigan</li>
                    <li className="text-white text-[14px]">Indiana</li>
                    <li className="text-white text-[14px]">Tenessee</li>
                    <li className="text-white text-[14px]">New York</li>
                    <li className="text-white text-[14px]">Pennsylvania</li>
                    <li className="text-white text-[14px]">West Virginia</li>
                    <li className="text-white text-[14px]">Virginia</li>
                    <li className="text-white text-[14px]">North Carolina</li>
                    <li className="text-white text-[14px]">New Hampshire</li>
                    <li className="text-white text-[14px]">Rhode Island</li>
                    <li className="text-white text-[14px]">Conneticut</li>
                    <li className="text-white text-[14px]">New Jersey</li>
                    <li className="text-white text-[14px]">Delaware</li>
                    <li className="text-white text-[14px]">Maryland</li>
                  </ul>
                </div>
                <div className="flex-[2] sm:flex">
                  <div className="p-3 flex-1">
                    <div className="flex items-start sm:items-center">
                      <div className="max-w-[18px] min-w-[18px]  min-h-[18px] max-h-[18px] h-[18px] bg-[#D45C59]" />
                      <span className="pl-2 text-white text-[10px] leading-[12px]">
                        <div>Legal - Not Operational</div> (5 states)
                      </span>
                    </div>
                    <ul className="pt-1">
                      <li className="text-white text-[14px]">Nebraska</li>
                      <li className="text-white text-[14px]">Kansas</li>
                      <li className="text-white text-[14px]">Ohio</li>
                      <li className="text-white text-[14px]">Florida</li>
                      <li className="text-white text-[14px]">Maine</li>
                    </ul>
                    <div className="flex items-start sm:items-center">
                      <div className="max-w-[18px] min-w-[18px]  min-h-[18px] max-h-[18px] h-[18px] bg-[#DBA500]" />
                      <span className="sm: mt-3 pl-2 text-white text-[10px] leading-[12px]">
                        <div>Active or Pre-Filed </div>
                        <div>Legislation/Ballot (3 states)</div>
                      </span>
                    </div>
                    <ul className="pt-1">
                      <li className="text-white text-[14px]">California</li>
                      <li className="text-white text-[14px]">Alaska</li>
                      <li className="text-white text-[14px]">Massachusetts</li>
                    </ul>
                  </div>
                  <div className="p-3 flex-1">
                    <div className="flex items-start sm:items-center">
                      <div className="max-w-[18px] min-w-[18px]  min-h-[18px] max-h-[18px] h-[18px] bg-[#D45C59]" />
                      <span className="pl-2 text-white text-[10px] leading-[12px]">
                        <div>No Legislation in 2022</div> (3 states)
                      </span>
                    </div>
                    <ul className="pt-1">
                      <li className="text-white text-[14px]">Idaho</li>
                      <li className="text-white text-[14px]">Utah</li>
                      <li className="text-white text-[14px]">Texas</li>
                    </ul>
                    <div className="flex items-start sm:items-center">
                      <div className="max-w-[18px] min-w-[18px]  min-h-[18px] max-h-[18px] h-[18px] bg-[#899999]" />
                      <span className="sm: mt-3 pl-2 text-white text-[10px] leading-[12px]">
                        <div>Dead Legislation in 2022 </div> (9 states)
                      </span>
                    </div>
                    <ul className="pt-1">
                      <li className="text-white text-[14px]">Oklahoma</li>
                      <li className="text-white text-[14px]">Minnesota</li>
                      <li className="text-white text-[14px]">Missouri</li>
                      <li className="text-white text-[14px]">Kentucky</li>
                      <li className="text-white text-[14px]">Alabama</li>
                      <li className="text-white text-[14px]">Georgia</li>
                      <li className="text-white text-[14px]">South Carolina</li>
                      <li className="text-white text-[14px]">Vermont</li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </section>

          <section className="sm:p-5 p-4">
            <div className="py-5 flex justify-between">
              <div className="sm:pl-4 sm:border-l border-[#fff] flex-1 h-fit">
                <h3 className="text-[20px] sm:text-[26px] text-white uppercase">
                  U.S. Sports Betting: Mobile
                </h3>
                <p className="text-white">
                  Legal landscape as of June 23, 2022
                </p>
              </div>
              <div className="hidden sm:flex justify-between flex-1">
                <div>
                  <div className="flex items-start sm:items-center">
                    <div className="max-w-[18px] min-w-[18px]  min-h-[18px] max-h-[18px] h-[18px] bg-[#D40000]" />
                    <span className="pl-2 text-white text-[10px] leading-[12px]">
                      <div>Live, Legal</div> (30 states & DC)
                    </span>
                  </div>
                  <div className="flex items-start sm:items-center pt-3">
                    <div className="max-w-[18px] min-w-[18px]  min-h-[18px] max-h-[18px] h-[18px] bg-[#fff]" />
                    <span className="pl-2 text-white text-[10px] leading-[12px]">
                      <div>No Legislation in 2022</div> (9 states)
                    </span>
                  </div>
                </div>
                <div>
                  <div className="flex items-start sm:items-center">
                    <div className="max-w-[18px] min-w-[18px]  min-h-[18px] max-h-[18px] h-[18px] bg-[#D45C59]" />
                    <span className="pl-2 text-white text-[10px] leading-[12px]">
                      <div>Legal - Not Operational</div> (5 states)
                    </span>
                  </div>
                  <div className="flex items-start sm:items-center pt-3">
                    <div className="max-w-[18px] min-w-[18px]  min-h-[18px] max-h-[18px] h-[18px] bg-[#899999]" />
                    <span className="pl-2 text-white text-[10px] leading-[12px]">
                      <div>Dead Legislation in 2022</div> (13 states)
                    </span>
                  </div>
                </div>

                <div>
                  <div className="flex items-start sm:items-center">
                    <div className="max-w-[18px] min-w-[18px]  min-h-[18px] max-h-[18px] h-[18px] bg-[#DBA500]" />
                    <span className="pl-2 text-white text-[10px] leading-[12px]">
                      <div>Active or Pre-Filed </div>
                      <div>Legislation/Ballot </div>
                      (3 states)
                    </span>
                  </div>
                </div>
              </div>
            </div>
            <div className="relative h-full">
              <div className="w-[200px] h-[235px] sm:w-[393px] sm:h-[235px] md:w-[728px] md:h-[435px] lg:w-[984px] lg:h-[588px] xl:w-[1240px] xl:h-[741px]">
                <Image
                  src="/images/soccerbx-map-mobile.svg"
                  layout="fill"
                  objectFit="cover"
                  objectPosition="center"
                  alt="map"
                />
              </div>
            </div>
            {/* <img
              src="/images/soccerbx-map-mobile.svg"
              width="100%"
              alt="SoccerBx"
            /> */}
            <div className="flex mt-5 border-t border-white">
              <div className="sm:p-3 flex-1 pt-2">
                <div className="flex items-start sm:items-center">
                  <div className="max-w-[18px] min-w-[18px]  min-h-[18px] max-h-[18px] h-[18px] bg-[#D40000]" />
                  <span className="pl-2 text-white text-[10px] leading-[12px]">
                    <div>Live, Legal</div> (30 states & DC)
                  </span>
                </div>
                <ul className="pt-3 sm:columns-2">
                  <li className="text-white text-[14px]">Oregon</li>
                  <li className="text-white text-[14px]">Nevada</li>
                  <li className="text-white text-[14px]">Arizona</li>
                  <li className="text-white text-[14px]">Wyoming</li>
                  <li className="text-white text-[14px]">Colorado</li>
                  <li className="text-white text-[14px]">Iowa</li>
                  <li className="text-white text-[14px]">Arkansas</li>
                  <li className="text-white text-[14px]">Louisiana</li>
                  <li className="text-white text-[14px]">Illinois</li>
                  <li className="text-white text-[14px]">Michigan</li>
                  <li className="text-white text-[14px]">Indiana</li>
                  <li className="text-white text-[14px]">Tenessee</li>
                  <li className="text-white text-[14px]">New York</li>
                  <li className="text-white text-[14px]">Pennsylvania</li>
                  <li className="text-white text-[14px]">West Virginia</li>
                  <li className="text-white text-[14px]">Virginia</li>
                  <li className="text-white text-[14px]">North Carolina</li>
                  <li className="text-white text-[14px]">New Hampshire</li>
                  <li className="text-white text-[14px]">Rhode Island</li>
                  <li className="text-white text-[14px]">Conneticut</li>
                  <li className="text-white text-[14px]">New Jersey</li>
                </ul>
              </div>

              <div className="sm:flex flex-1 sm:flex-[2]">
                <div className="p-3 flex-1">
                  <div className="flex items-start sm:items-center">
                    <div className="max-w-[18px] min-w-[18px]  min-h-[18px] max-h-[18px] h-[18px] bg-[#D45C59]" />
                    <span className="pl-2 text-white text-[10px] leading-[12px]">
                      <div>Legal - Not Operational</div> (5 states)
                    </span>
                  </div>
                  <ul className="pt-1">
                    <li className="text-white text-[14px]">Nebraska</li>
                    <li className="text-white text-[14px]">Kansas</li>
                    <li className="text-white text-[14px]">Ohio</li>
                    <li className="text-white text-[14px]">Florida</li>
                    <li className="text-white text-[14px]">Maine</li>
                  </ul>
                  <div className="flex items-start sm:items-center">
                    <div className="max-w-[18px] min-w-[18px]  min-h-[18px] max-h-[18px] h-[18px] bg-[#DBA500]" />
                    <span className="sm: mt-3 pl-2 text-white text-[10px] leading-[12px]">
                      <div>Active or Pre-Filed </div>
                      <div>Legislation/Ballot (3 </div>
                      states)
                    </span>
                  </div>
                  <ul className="pt-1">
                    <li className="text-white text-[14px]">California</li>
                    <li className="text-white text-[14px]">Alaska</li>
                    <li className="text-white text-[14px]">Massachusetts</li>
                  </ul>
                </div>
                <div className="p-3 flex-1">
                  <div className="flex items-start sm:items-center">
                    <div className="max-w-[18px] min-w-[18px]  min-h-[18px] max-h-[18px] h-[18px] bg-[#D45C59]" />
                    <span className="pl-2 text-white text-[10px] leading-[12px]">
                      <div>No Legislation in 2022</div> (3 states)
                    </span>
                  </div>
                  <ul className="pt-1">
                    <li className="text-white text-[14px]">Idaho</li>
                    <li className="text-white text-[14px]">Utah</li>
                    <li className="text-white text-[14px]">Texas</li>
                  </ul>
                </div>
                <div className="p-3 flex-1">
                  <div className="flex items-start sm:items-center">
                    <div className="max-w-[18px] min-w-[18px]  min-h-[18px] max-h-[18px] h-[18px] bg-[#899999]" />
                    <span className="sm: mt-3 pl-2 text-white text-[10px] leading-[12px]">
                      <div>Dead Legislation in 2022 </div> (9 states)
                    </span>
                  </div>
                  <ul className="pt-1">
                    <li className="text-white text-[14px]">Oklahoma</li>
                    <li className="text-white text-[14px]">Minnesota</li>
                    <li className="text-white text-[14px]">Missouri</li>
                    <li className="text-white text-[14px]">Kentucky</li>
                    <li className="text-white text-[14px]">Alabama</li>
                    <li className="text-white text-[14px]">Georgia</li>
                    <li className="text-white text-[14px]">South Carolina</li>
                    <li className="text-white text-[14px]">Vermont</li>
                  </ul>
                </div>
              </div>
            </div>
          </section>

          <div className="linear-border-b-5" />
          <div className="sm:p-4 m-4 mb-0 sm:m-0">
            <h3 className="uppercase my-2 text-[20px] sm:text-[26px] text-white leading-[24px]">
              soccer betting odds explained
            </h3>
            <h4 className="text-white mt-4 sm:mt-0">
              USA Odds are based on a $100 bet.
            </h4>
            <div className="text-white">
              + 200 = Bet $100 you win $200 plus your money back = $300
            </div>
            <div className="text-white">
              - 200 = you must bet $200 to win a $100, plus your money back =
              $200
            </div>
            <div className="mt-6 overflow-x-auto relative hidden lg:block">
              <table className="w-full text-left ">
                <thead>
                  <tr className="border-b border-[#fff] align-top text-white">
                    <th scope="col" className="py-3">
                      Home Team
                    </th>
                    <th scope="col" className="py-3">
                      USA Odds
                    </th>
                    <th scope="col" className="py-3">
                      <div>
                        UK
                        <br />
                        Odds
                      </div>
                    </th>
                    <th scope="col" className="py-3 rounded-r-lg">
                      You bet
                    </th>
                    <th scope="col" className="py-3 rounded-r-lg">
                      <div>You win</div>
                      <small className="font-thin">(Plus money back)</small>
                    </th>
                    <th scope="col" className="py-3 rounded-r-lg">
                      Means
                    </th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td className="py-4 px-0 text-white font-medium">
                      Liverpool
                    </td>
                    <td className="text-white border-b border-[#fff]">100</td>
                    <td className="text-white border-b border-[#fff]">
                      Events
                    </td>
                    <td className="text-white border-b border-[#fff]">$100</td>
                    <td className="text-white border-b border-[#fff]">$100</td>
                    <td className="text-white border-b border-[#fff]">
                      <div>Could go either way</div>
                    </td>
                  </tr>
                  <tr>
                    <td className="py-4 px-0 text-white font-medium"></td>
                    <td className="text-white border-b border-[#fff]">-200</td>
                    <td className="text-white border-b border-[#fff]">1-2</td>
                    <td className="text-white border-b border-[#fff]">$200</td>
                    <td className="text-white border-b border-[#fff]">$100</td>
                    <td className="text-white border-b border-[#fff]">
                      <div>Should probably win</div>
                    </td>
                  </tr>
                  <tr>
                    <td className="py-4 px-0 text-white font-medium"></td>
                    <td className="text-white border-b border-[#fff]">-300</td>
                    <td className="text-white border-b border-[#fff]">1-3</td>
                    <td className="text-white border-b border-[#fff]">$300</td>
                    <td className="text-white border-b border-[#fff]">$100</td>
                    <td className="text-white border-b border-[#fff]">
                      <div>Really should win</div>
                    </td>
                  </tr>
                  <tr>
                    <td className="py-4 px-0 text-white font-medium"></td>
                    <td className="text-white border-b border-[#fff]">-400</td>
                    <td className="text-white border-b border-[#fff]">1-4</td>
                    <td className="text-white border-b border-[#fff]">$400</td>
                    <td className="text-white border-b border-[#fff]">$100</td>
                    <td className="text-white border-b border-[#fff]">
                      <div>Really really should win</div>
                    </td>
                  </tr>
                  <tr>
                    <td className="py-4 px-0 text-white font-medium"></td>
                    <td className="text-white border-b border-[#fff]">-500</td>
                    <td className="text-white border-b border-[#fff]">1-5</td>
                    <td className="text-white border-b border-[#fff]">$500</td>
                    <td className="text-white border-b border-[#fff]">$100</td>
                    <td className="text-white border-b border-[#fff]">
                      <div>Really really really should win</div>
                    </td>
                  </tr>
                  <tr>
                    <td className="py-4 px-0 text-white font-medium"></td>
                    <td className="text-white border-b border-[#fff]">-1000</td>
                    <td className="text-white border-b border-[#fff]">1-10</td>
                    <td className="text-white border-b border-[#fff]">
                      $1,000
                    </td>
                    <td className="text-white border-b border-[#fff]">$100</td>
                    <td className="text-white border-b border-[#fff]">
                      <div>Other team might as well not show up</div>
                    </td>
                  </tr>
                </tbody>
              </table>
              {/* table 2 */}
              <table className="mt-5 w-full text-left ">
                <thead>
                  <tr className="border-b border-[#fff] align-top text-white">
                    <th scope="col" className="py-3">
                      Away Team
                    </th>
                    <th scope="col" className="py-3">
                      USA Odds
                    </th>
                    <th scope="col" className="py-3">
                      <div>
                        UK
                        <br />
                        Odds
                      </div>
                    </th>
                    <th scope="col" className="py-3 rounded-r-lg">
                      You bet
                    </th>
                    <th scope="col" className="py-3 rounded-r-lg">
                      <div>You win</div>
                      <small className="font-thin">(Plus money back)</small>
                    </th>
                    <th scope="col" className="py-3 rounded-r-lg">
                      Means
                    </th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td className="py-4 px-0 text-white font-medium">
                      <div>Bournemouth</div>
                    </td>
                    <td className="text-white border-b border-[#fff]">+100</td>
                    <td className="text-white border-b border-[#fff]">
                      Events
                    </td>
                    <td className="text-white border-b border-[#fff]">$100</td>
                    <td className="text-white border-b border-[#fff]">$100</td>
                    <td className="text-white border-b border-[#fff]">
                      <div>Even chance of winning or losing</div>
                    </td>
                  </tr>
                  <tr>
                    <td className="py-4 px-0 text-white font-medium"></td>
                    <td className="text-white border-b border-[#fff]">+200</td>
                    <td className="text-white border-b border-[#fff]">2-1</td>
                    <td className="text-white border-b border-[#fff]">$100</td>
                    <td className="text-white border-b border-[#fff]">$200</td>
                    <td className="text-white border-b border-[#fff]">
                      <div>Will have to play well to win</div>
                    </td>
                  </tr>
                  <tr>
                    <td className="py-4 px-0 text-white font-medium"></td>
                    <td className="text-white border-b border-[#fff]">+300</td>
                    <td className="text-white border-b border-[#fff]">3-1</td>
                    <td className="text-white border-b border-[#fff]">$100</td>
                    <td className="text-white border-b border-[#fff]">$300</td>
                    <td className="text-white border-b border-[#fff]">
                      <div>Will have to play very well to win</div>
                    </td>
                  </tr>
                  <tr>
                    <td className="py-4 px-0 text-white font-medium"></td>
                    <td className="text-white border-b border-[#fff]">+400</td>
                    <td className="text-white border-b border-[#fff]">4-1</td>
                    <td className="text-white border-b border-[#fff]">$100</td>
                    <td className="text-white border-b border-[#fff]">$400</td>
                    <td className="text-white border-b border-[#fff]">
                      <div>Will have to play very well to win</div>
                    </td>
                  </tr>
                  <tr>
                    <td className="py-4 px-0 text-white font-medium"></td>
                    <td className="text-white border-b border-[#fff]">+500</td>
                    <td className="text-white border-b border-[#fff]">5-1</td>
                    <td className="text-white border-b border-[#fff]">$100</td>
                    <td className="text-white border-b border-[#fff]">$500</td>
                    <td className="text-white border-b border-[#fff]">
                      <div>Will have to play very very well to win</div>
                    </td>
                  </tr>
                  <tr>
                    <td className="py-4 px-0 text-white font-medium"></td>
                    <td className="text-white border-b border-[#fff]">+1000</td>
                    <td className="text-white border-b border-[#fff]">10-1</td>
                    <td className="text-white border-b border-[#fff]">$100</td>
                    <td className="text-white border-b border-[#fff]">
                      $1,000
                    </td>
                    <td className="text-white border-b border-[#fff]">
                      <div>Would be a huge upset</div>
                    </td>
                  </tr>
                </tbody>
              </table>

              {/* table 3 */}
              <table className="mt-4 w-full text-left ">
                <thead>
                  <tr className="border-b border-[#fff] align-top text-white">
                    <th scope="col" className="py-3">
                      Examples
                    </th>
                    <th scope="col" className="py-3">
                      Home Team win
                    </th>
                    <th scope="col" className="py-3">
                      Away Team Win
                    </th>
                    <th scope="col" className="py-3 rounded-r-lg">
                      Draw
                    </th>
                    <th scope="col" className="py-3 rounded-r-lg"></th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td className="py-4 px-0 text-white font-medium border-b border-[#fff]">
                      <div>Liverpool v</div>
                      West Ham
                    </td>
                    <td className="align-top p-0 text-white border-b border-[#fff]">
                      {" "}
                      <div className="py-2">-300 (1-3)</div>
                    </td>
                    <td className="align-top p-0 text-white border-b border-[#fff]">
                      <div className="py-2">+300 (3-1)</div>
                    </td>
                    <td className="align-top p-0 text-white border-b border-[#fff]">
                      <div className="py-2"> +200 (2-1)</div>
                      <div className="py-2"></div>
                    </td>

                    <td className="align-top p-0 text-white border-b border-[#fff]">
                      <div className="max-w-[450px]">
                        Liverpool strongly fancied to win. You would need to bet
                        $300 to win $100 if you agree Bookies think it is more
                        likely the draw than West Ham win.
                      </div>
                    </td>
                  </tr>
                  <tr>
                    <td className="py-4 px-0 text-white font-medium border-b border-[#fff]">
                      <div>Arsenal v </div>
                      Chelsea
                    </td>
                    <td className="align-top p-0 text-white border-b border-[#fff]">
                      {" "}
                      +200 (2-1)
                    </td>
                    <td className="align-top p-0 text-white border-b border-[#fff]">
                      <div className="py-2">+300 (3-1)</div>
                    </td>
                    <td className="align-top p-0 text-white border-b border-[#fff]">
                      <div className="py-2"> -200 (1-2)</div>
                    </td>

                    <td className="align-top p-0 text-white border-b border-[#fff]">
                      <div className="max-w-[450px]">
                        {" "}
                        Arsenal are just slighly fancied to win , but bookies
                        strongly thiink it will be a draw You make a bit more if
                        Chelsea win ($300 for a $100 bet) But youd need to bet
                        $200 to win a $100 if you facy the draw.
                      </div>
                    </td>
                  </tr>
                  <tr>
                    <td className="py-4 px-0 text-white font-medium border-b border-[#fff]">
                      <div>Man City v</div>
                      Notts Forest
                    </td>
                    <td className="align-top p-0 text-white border-b border-[#fff]">
                      {" "}
                      <div className="py-2">-400 (1-4)</div>
                    </td>
                    <td className="align-top p-0 text-white border-b border-[#fff]">
                      <div className="py-2">+600 (6-1)</div>
                    </td>
                    <td className="align-top p-0 text-white border-b border-[#fff]">
                      {" "}
                      <div className="py-2">+300 (3-1)</div>
                    </td>

                    <td className="align-top p-0 text-white border-b border-[#fff]">
                      <div className="py-2 max-w-[450px]">
                        {" "}
                        League Champions Man City strong strong favorites to
                        beat newly promoted Forest Bookies think Forest have
                        little chance and the even a draw unlikely{" "}
                      </div>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
            <table className=" hidden lg:block">
              <tr>
                <td className="py-4 px-0 text-white font-medium border-b border-[#fff]">
                  <div className="sm:w-[120px]">Messaging</div>
                </td>
                <td className="align-top p-0 text-white border-b border-[#fff]">
                  <div className="py-2">
                    Remember it&apos;s soccer, and anything can happen.
                    Leicester City were 5,000 -1 to win the league in 2016. No
                    one would have predicted that !. Betting on soccer should be
                    fun and entertaining and help you enjoy the game even more.
                    Don&apos;t bet more than you can afford, do a little
                    homework (soccerbx!) and enjoy your wins and yes even your
                    losses ...make it fun..
                  </div>
                </td>
              </tr>
            </table>

            <div className="text-white hidden lg:block my-6">
              <h5 className="text-[26px]">
                Example English Premier 2022-23 odds
              </h5>
              <span className="font-medium">Odds to win the League</span>
              <table className="table-fixed w-full">
                <thead>
                  <tr>
                    <th className="text-left">Finish</th>
                    <th className="text-left">Team</th>
                    <th className="text-left">
                      USA <div>Odds</div> <div>Based</div> on $100
                    </th>
                    <th className="text-left">
                      UK <div>Odds</div> <div>Example</div>
                    </th>
                    <th className="text-left">
                      Multiple <div>X if Bet</div> Wins
                    </th>
                    <th className="text-left">
                      <div>Amount</div> Bet $100
                    </th>
                    <th className="text-left">
                      <div>Amount</div> Win
                    </th>
                    <th className="text-left">
                      <div>Plus Bet</div> Back
                    </th>
                    <th className="text-left">
                      <div>Total</div> Back
                    </th>
                  </tr>
                </thead>
                <tbody>
                  <tr className="border-b border-t border-[#fff]">
                    <td className="font-medium">1</td>
                    <td className="font-medium">Man City</td>
                    <td> -182 </td>
                    <td></td>
                    <td></td>
                    <td>$100</td>
                    <td>$82</td>
                    <td>$100</td>
                    <td>$182</td>
                  </tr>
                  <tr className="border-b border-[#fff] py-2">
                    <td className="font-medium">2</td>
                    <td className="font-medium">Liverpool</td>
                    <td> +200</td>
                    <td>2-1</td>
                    <td>2</td>
                    <td>$100</td>
                    <td>$200</td>
                    <td>$100</td>
                    <td>$300</td>
                  </tr>
                  <tr className="border-b border-[#fff] py-2">
                    <td className="font-medium">3</td>
                    <td className="font-medium">Tottenham</td>
                    <td>+1300</td>
                    <td>13-1</td>
                    <td>13</td>
                    <td>$100</td>
                    <td>$1,300</td>
                    <td>$100</td>
                    <td>$1,400</td>
                  </tr>
                  <tr className="border-b border-[#fff] py-2">
                    <td className="font-medium">4</td>
                    <td className="font-medium">Chelsea</td>
                    <td>+1600</td>
                    <td>16-1</td>
                    <td>16</td>
                    <td>$100</td>
                    <td>$1,600</td>
                    <td>$100</td>
                    <td>$1,700</td>
                  </tr>
                  <tr className="border-b border-[#fff] py-2">
                    <td className="font-medium">5</td>
                    <td className="font-medium">Man United</td>
                    <td>+2000 </td>
                    <td>20-1 </td>
                    <td>20 </td>
                    <td>$100</td>
                    <td>$2,000</td>
                    <td>$100</td>
                    <td>$2,100</td>
                  </tr>
                  <tr className="border-b border-[#fff] py-2">
                    <td className="font-medium">6</td>
                    <td className="font-medium">Arsenal</td>
                    <td>+3000</td>
                    <td>30-1</td>
                    <td>30</td>
                    <td>$100</td>
                    <td>$3,000</td>
                    <td>$100</td>
                    <td>$3,100</td>
                  </tr>
                  <tr className="border-b border-[#fff] py-2">
                    <td className="font-medium">7</td>
                    <td className="font-medium">Newcastle</td>
                    <td>+6600</td>
                    <td>66-1</td>
                    <td>66</td>
                    <td>$100</td>
                    <td>$6,600</td>
                    <td>$100</td>
                    <td>$6,700</td>
                  </tr>
                  <tr className="border-b border-[#fff] py-2">
                    <td className="font-medium">8</td>
                    <td className="font-medium">West Ham</td>
                    <td>-10000 </td>
                    <td>100-1 </td>
                    <td>100 </td>
                    <td>$100</td>
                    <td>$10,000 </td>
                    <td>$100</td>
                    <td>$10,100 </td>
                  </tr>
                  <tr className="border-b border-[#fff] py-2">
                    <td className="font-medium">9</td>
                    <td className="font-medium">Leicester City</td>
                    <td>-15000</td>
                    <td>150-1</td>
                    <td>150</td>
                    <td>$100</td>
                    <td>$15,000</td>
                    <td>$100</td>
                    <td>$15,100</td>
                  </tr>
                  <tr className="border-b border-[#fff] py-2">
                    <td className="font-medium">10</td>
                    <td className="font-medium">Brighton</td>
                    <td>+20000 </td>
                    <td>200-1</td>
                    <td>200 </td>
                    <td>$100</td>
                    <td>$20,000 </td>
                    <td>$100</td>
                    <td>$20,100 </td>
                  </tr>
                  <tr className="border-b border-[#fff] py-2">
                    <td className="font-medium">11</td>
                    <td className="font-medium">Everton</td>
                    <td>+25000</td>
                    <td>250-1</td>
                    <td>250 </td>
                    <td>$100</td>
                    <td>$25,000 </td>
                    <td>$100</td>
                    <td>$25,100</td>
                  </tr>
                  <tr className="border-b border-[#fff] py-2">
                    <td className="font-medium">12</td>
                    <td className="font-medium"> Aston Villa</td>
                    <td>+25000</td>
                    <td>250-1</td>
                    <td>250 </td>
                    <td>$100</td>
                    <td>$25,000</td>
                    <td>$100</td>
                    <td>$25,100</td>
                  </tr>
                  <tr className="border-b border-[#fff] py-2">
                    <td className="font-medium">13</td>
                    <td className="font-medium">Wolves</td>
                    <td>35000</td>
                    <td>350-1</td>
                    <td>350 </td>
                    <td>$100</td>
                    <td>$35,000</td>
                    <td>$100</td>
                    <td>$35,100</td>
                  </tr>
                  <tr className="border-b border-[#fff] py-2">
                    <td className="font-medium">14</td>
                    <td className="font-medium">Crystal Palace</td>
                    <td>+50000</td>
                    <td>500-1</td>
                    <td>500 </td>
                    <td>$100</td>
                    <td>$50,000</td>
                    <td>$100</td>
                    <td>$50,100</td>
                  </tr>
                  <tr className="border-b border-[#fff] py-2">
                    <td className="font-medium">15</td>
                    <td className="font-medium">Southampton</td>
                    <td>+50000</td>
                    <td>500-1</td>
                    <td>500 </td>
                    <td>$100</td>
                    <td>$50,000</td>
                    <td>$100</td>
                    <td>$50,100</td>
                  </tr>
                  <tr className="border-b border-[#fff] py-2">
                    <td className="font-medium">16</td>
                    <td className="font-medium">Leeds</td>
                    <td>+75000</td>
                    <td>750-1</td>
                    <td>750 </td>
                    <td>$100</td>
                    <td>$75,000</td>
                    <td>$100</td>
                    <td>$75,100</td>
                  </tr>
                  <tr className="border-b border-[#fff] py-2">
                    <td className="font-medium">17</td>
                    <td className="font-medium">Fulham</td>
                    <td>+100000</td>
                    <td>1,000-1</td>
                    <td>1,000 </td>
                    <td>$100</td>
                    <td>$100.000</td>
                    <td>$100</td>
                    <td>$100,100</td>
                  </tr>
                  <tr className="border-b border-[#fff] py-2">
                    <td className="font-medium">18</td>
                    <td className="font-medium">Notts Forest</td>
                    <td>+100000</td>
                    <td>1,000-1</td>
                    <td>1,000 </td>
                    <td>$100</td>
                    <td>$100.000</td>
                    <td>$100</td>
                    <td>$100,100</td>
                  </tr>
                  <tr className="border-b border-[#fff] py-2">
                    <td className="font-medium">19</td>
                    <td className="font-medium">Brentford</td>
                    <td>+100000</td>
                    <td>1,000-1</td>
                    <td>1,000 </td>
                    <td>$100</td>
                    <td>$100.000</td>
                    <td>$100</td>
                    <td>$100,100</td>
                  </tr>
                  <tr className="border-b border-[#fff] py-2">
                    <td className="font-medium">20</td>
                    <td className="font-medium">Bournemouth</td>
                    <td>+100000</td>
                    <td>1,000-1</td>
                    <td>1,000 </td>
                    <td>$100</td>
                    <td>$100.000</td>
                    <td>$100</td>
                    <td>$100,100</td>
                  </tr>
                </tbody>
              </table>
            </div>

            {/* small screen content */}
            <div className="overflow-x-auto relative block lg:hidden">
              <table className="w-full text-left ">
                <thead>
                  <h4 className="font-medium text-white text-[16px] my-4">
                    Home Team
                  </h4>
                  <h4 className="font-medium text-white text-[16px]">
                    Liverpool
                  </h4>
                  <tr className="border-b border-[#fff] align-top text-white">
                    <th scope="col" className="py-3">
                      USA <div>Odds</div>
                    </th>
                    <th scope="col" className="py-3">
                      <div>
                        UK
                        <br />
                        Odds
                      </div>
                    </th>
                    <th scope="col" className="py-3 rounded-r-lg">
                      You <div>bet</div>
                    </th>
                    <th scope="col" className="py-3 rounded-r-lg">
                      <div>You win</div>
                      <small className="font-thin">(Plus money back)</small>
                    </th>
                    {/* <th scope="col" className="py-3 rounded-r-lg">
                 Means
               </th> */}
                  </tr>
                </thead>
                <tbody>
                  <tr className="border-b border-[#fff]">
                    <td className="align-top p-0 text-white ">
                      {" "}
                      <div className="py-2">100</div>
                    </td>
                    <td className="align-top p-0 text-white ">
                      <div className="py-2 mx-2">Events</div>
                    </td>
                    <td className="align-top p-0 text-white ">
                      <div className="py-2 "> $100</div>
                    </td>
                    <td className="align-top p-0 text-white ">
                      <div className="py-2">$100</div>
                    </td>
                  </tr>
                  <h4 className="font-medium text-white text-[16px]">Means</h4>
                  <tr className="border-b border-[#fff]">
                    {" "}
                    <span className="font-lighter text-white text-[14px] whitespace-nowrap">
                      Could go either way
                    </span>
                  </tr>
                  <tr className="border-b border-[#fff]">
                    <td className="align-top p-0 text-white">
                      {" "}
                      <div className="py-2">-200</div>
                    </td>
                    <td className="align-top p-0 text-white">
                      <div className="py-2">1-2</div>
                    </td>
                    <td className="align-top p-0 text-white">
                      <div className="py-2">$200</div>
                    </td>
                    <td className="align-top p-0 text-white">
                      <div className="py-2">$100</div>
                    </td>
                  </tr>

                  <tr className="border-b border-[#fff]">
                    <div className="text-white py-2 text-[14px]">
                      Should probably win
                    </div>
                  </tr>
                  <tr className="border-b border-[#fff]">
                    <td className="align-top p-0 text-white">
                      {" "}
                      <div className="py-2">-300</div>
                    </td>
                    <td className="align-top p-0 text-white">
                      <div className="py-2">1-3</div>
                    </td>
                    <td className="align-top p-0 text-white">
                      <div className="py-2">$300</div>
                    </td>
                    <td className="align-top p-0 text-white">
                      <div className="py-2">$100</div>
                    </td>
                  </tr>
                  <tr className="border-b border-[#fff]">
                    <div className="text-white py-2 text-[14px]">
                      Really should win
                    </div>
                  </tr>
                  <tr className="border-b border-[#fff]">
                    <td className="align-top p-0 text-white">
                      {" "}
                      <div className="py-2">-400</div>
                    </td>
                    <td className="align-top p-0 text-white">
                      <div className="py-2">1-4</div>
                    </td>
                    <td className="align-top p-0 text-white">
                      <div className="py-2">$400</div>
                    </td>
                    <td className="align-top p-0 text-white">
                      <div className="py-2">$100</div>
                    </td>
                  </tr>
                  <tr className="border-b border-[#fff]">
                    <div className="text-white py-2 text-[14px]">
                      Really really should win
                    </div>
                  </tr>
                  <tr className="border-b border-[#fff]">
                    <td className="align-top p-0 text-white">
                      {" "}
                      <div className="py-2">-500</div>
                    </td>
                    <td className="align-top p-0 text-white">
                      <div className="py-2">1-5</div>
                    </td>
                    <td className="align-top p-0 text-white">
                      <div className="py-2">$500</div>
                    </td>
                    <td className="align-top p-0 text-white">
                      <div className="py-2">$100</div>
                    </td>
                  </tr>
                  <tr className="border-b border-[#fff]">
                    <div className="text-white py-2 text-[14px]">
                      Really really really should win
                    </div>
                  </tr>

                  <tr>
                    <td className="align-top p-0 text-white border-b border-[#fff]">
                      {" "}
                      <div className="py-2">-1000</div>
                    </td>
                    <td className="align-top p-0 text-white border-b border-[#fff]">
                      <div className="py-2">1-10</div>
                    </td>
                    <td className="align-top p-0 text-white border-b border-[#fff]">
                      <div className="py-2 mx-2">$1,000</div>
                    </td>
                    <td className="align-top p-0 text-white border-b border-[#fff]">
                      <div className="py-2">$100</div>
                    </td>
                  </tr>
                  <tr className="text-white text-[14px] border-b border-[#fff]">
                    Other team might as well not show up
                  </tr>
                </tbody>
              </table>
              <table className="mt-4 w-full text-left">
                <thead>
                  <h4 className="font-medium text-white text-[16px]">
                    Away Team
                  </h4>
                  <h4 className="font-medium text-white text-[16px]">
                    Bournemouth
                  </h4>
                  <tr className="border-b border-[#fff] align-top text-white">
                    <th scope="col" className="py-3">
                      USA <div>Odds</div>
                    </th>
                    <th scope="col" className="py-3">
                      <div>
                        UK
                        <br />
                        Odds
                      </div>
                    </th>
                    <th scope="col" className="py-3 rounded-r-lg">
                      You bet
                    </th>
                    <th scope="col" className="py-3 rounded-r-lg">
                      <div>You win</div>
                      <small className="font-thin">(Plus money back)</small>
                    </th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td className="align-top p-0 text-white border-b border-[#fff]">
                      {" "}
                      <div className="py-2">+100</div>
                    </td>
                    <td className="align-top p-0 text-white border-b border-[#fff]">
                      <div className="py-2 px-2">Events</div>
                      <div className="py-2"></div>
                    </td>
                    <td className="align-top p-0 text-white border-b border-[#fff]">
                      <div className="py-2"> $100</div>
                      <div className="py-2"></div>
                    </td>
                    <td className="align-top p-0 text-white border-b border-[#fff]">
                      <div className="py-2">$100</div>
                      <div className="py-2"></div>
                    </td>
                  </tr>
                  <tr>
                    <h4 className="font-medium text-white text-[16px]">
                      Means
                    </h4>
                  </tr>
                  <tr className="text-white border-b border-[#fff]">
                    Even chance of winning or losing
                  </tr>

                  <tr>
                    <td className="align-top p-0 text-white border-b border-[#fff]">
                      {" "}
                      <div className="py-2 border-b border-[#fff]">+200</div>
                    </td>
                    <td className="align-top p-0 text-white border-b border-[#fff]">
                      <div className="py-2 border-b border-[#fff]">2-1</div>
                    </td>
                    <td className="align-top p-0 text-white border-b border-[#fff]">
                      <div className="py-2 border-b border-[#fff]">$100</div>
                    </td>
                    <td className="align-top p-0 text-white border-b border-[#fff]">
                      <div className="py-2 border-b border-[#fff]">$200</div>
                    </td>
                  </tr>
                  <tr className="border-b border-[#fff]">
                    {" "}
                    <div className="py-2 text-white text-[14px]">
                      Will have to play well to win{" "}
                    </div>
                  </tr>
                  <tr className="border-b border-[#fff]">
                    <td className="align-top p-0 text-white">
                      {" "}
                      <div className="py-2">+300</div>
                    </td>
                    <td className="align-top p-0 text-white">
                      <div className="py-2">3-1</div>
                    </td>
                    <td className="align-top p-0 text-white">
                      <div className="py-2">$100</div>
                    </td>
                    <td className="align-top p-0 text-white">
                      <div className="py-2">$300</div>
                    </td>
                  </tr>
                  <tr className="border-b border-[#fff]">
                    <div className="py-2 text-white text-[14px]">
                      Will have to play very well to win{" "}
                    </div>
                  </tr>
                  <tr className="border-b border-[#fff]">
                    <td>
                      {" "}
                      <div className="py-2 text-white">+400</div>
                    </td>
                    <td>
                      <div className="py-2 text-white">4-1</div>
                    </td>
                    <td>
                      {" "}
                      <div className="py-2 text-white">$100</div>
                    </td>
                    <td>
                      {" "}
                      <div className="py-2 text-white">$400</div>
                    </td>
                  </tr>

                  <tr className="border-b border-[#fff]">
                    <div className="py-2 text-white text-[14px]">
                      Will have to play very well to win{" "}
                    </div>
                  </tr>
                  <tr className="border-b border-[#fff]">
                    <td>
                      {" "}
                      <div className="py-2 text-white">+500</div>
                    </td>
                    <td>
                      <div className="py-2 text-white">5-1</div>
                    </td>
                    <td>
                      {" "}
                      <div className="py-2 text-white">$100</div>
                    </td>
                    <td>
                      {" "}
                      <div className="py-2 text-white">$500</div>
                    </td>
                  </tr>
                  <tr className="border-b border-[#fff]">
                    <div className="py-2  text-white text-[14px]">
                      Will have to play very very well to win
                    </div>
                  </tr>

                  <tr>
                    <td className="align-top p-0 text-white border-b border-[#fff]">
                      {" "}
                      <div className="py-2 border-b border-[#fff]">+1000</div>
                    </td>
                    <td className="align-top p-0 text-white border-b border-[#fff]">
                      <div className="py-2 border-b border-[#fff]">10-1</div>
                    </td>
                    <td className="align-top p-0 text-white border-b border-[#fff]">
                      <div className="py-2 border-b border-[#fff]">$100</div>
                    </td>
                    <td className="align-top p-0 text-white border-b border-[#fff]">
                      <div className="py-2 border-b border-[#fff]">$1,000</div>
                    </td>
                    <td className="align-bottom p-0 text-white border-b border-[#fff]"></td>
                  </tr>

                  <tr className="p-2 text-white border-b border-[#fff] pb-3">
                    Would be a huge upset
                  </tr>
                </tbody>
              </table>
              <h4 className="my-3 font-medium text-white text-[16px]">
                Examples
              </h4>

              <div className="flex justify-between border-b border-[#fff] py-2">
                <div className="font-medium text-white">Home Team win</div>
                <div className="font-medium text-white">Away Team Win</div>
                <div className="font-medium text-white">Draw</div>
              </div>

              <h4 className="my-3 font-medium text-white text-[16px]">
                Liverpool v West Ham
              </h4>

              <div className="py-2 border-b border-[#fff]">
                <div className="flex justify-between">
                  <div className="text-white">-300 (1-3)</div>
                  <div className="text-white">+300 (3-1)</div>
                  <div className="text-white">+200 (2-1)</div>
                </div>
                <p className="mt-5 text-white text-[16px]">
                  Liverpool strongly fancied to win. You would need to bet $300
                  to win $100 if you agree Bookies think it is more likely the
                  draw than West Ham win.
                </p>
              </div>
              <h4 className="my-3 font-medium text-white text-[16px]">
                Arsenal v Chelsea
              </h4>
              <div className="my-2 border-b border-[#fff] ">
                <div className="flex justify-between">
                  <div className="text-white">+200 (2-1)</div>
                  <div className="text-white">+300 (3-1)</div>
                  <div className="text-white">-200 (1-2)</div>
                </div>
                <p className="mt-5 text-white text-[16px]">
                  Arsenal are just slighly fancied to win , but bookies strongly
                  thiink it will be a draw You make a bit more if Chelsea win
                  ($300 for a $100 bet) But youd need to bet $200 to win a $100
                  if you facy the draw.
                </p>
              </div>
              <h4 className="my-3 font-medium text-white text-[16px]">
                Man City v Notts Forest
              </h4>
              <div className="my-2 border-b border-[#fff] py-2">
                <div className="flex justify-between">
                  <div className="text-white">-400 (1-4)</div>
                  <div className="text-white">+600 (6-1)</div>
                  <div className="text-white">+300 (3-1)</div>
                </div>
                <p className="mt-5 text-white text-[16px]">
                  League Champions Man City strong strong favorites to beat
                  newly promoted Forest Bookies think Forest have little chance
                  and the even a draw unlikely
                </p>
              </div>
              <div className="sm:w-[120px] text-white font-medium">
                Messaging
              </div>
              <div className="py-2 text-white pb-3 border-b border-[#fff]">
                Remember it&apos;s soccer, and anything can happen. Leicester
                City were 5,000 -1 to win the league in 2016. No one would have
                predicted that !. Betting on soccer should be fun and
                entertaining and help you enjoy the game even more. Don&apos;t
                bet more than you can afford, do a little homework (soccerbx!)
                and enjoy your wins and yes even your losses ...make it fun..
              </div>
            </div>
            <div className="max-w-[800px] mx-auto mt-3 text-white">
              <div className="font-medium">
                What type of Bets can you place on Soccer?
              </div>
              <div className="my-2 font-medium">Money line</div> This is a bet
              on the outcome of a single game : either you bet a team to win,
              lose or as Draw. The odds might not be great for say Man City to
              beat Bournemouth . But you can parlay multiple games to give you a
              more exciting “return”. Very popular bet in the world of soccer
              betting. While an anathema in America , 1/4 of all games end in a
              draw. Don’t be afraid to bet it.{" "}
              <div className="font-medium mt-3">Goals Scored (over under)</div>{" "}
              A few options here. Bet how many goals your team will score. How
              many goals will be scored in the entire game. The Sportsbook will
              set a number for goals for a game. Brighton v Leicester: 4 goals.
              Bet there will be more than 4, (the over) and you win. If
              it&apos;s less than 4 you lose. Equally if you bet the “under” ie
              there will be less that 4 goals and there are less: you win. if if
              more that 4 you lose.
              <div className="my-3">
                If it’s exactly 4 its a &quot;push&quot; and you get your money
                back .
              </div>
              <div className="font-medium mt-2">Parlays/ Teaser</div>
              Very popular bet , better odds , Basically you bet on the outcome
              of several games (or events) in a sort of roll up. Harder to win
              though.
              <div className="font-medium mt-3">Spread</div>
              How much will the favorite “win by” 1, 2, 5 goals. Example
              Sportsbooks , say Man City will win by more than 3 goals against
              Villa . Man City the big favorite. You either agree or disagree.
              (Villa actually tied 1-1) you beat the spread if you bet Villa.
              <div className="font-medium mt-3">Double Result</div>
              You can bet on the score at Halftime and the Final score at the
              same time. United to be winning at Half Time and Full Time. Or
              losing at halt time and drawing full time.
              <div className="font-medium mt-3">Prop Bets</div>
              Bets offered in inside the game. Who scores first (player or
              team), time of first goal, number of corners etc.
              <div className="font-medium mt-3">Same Game</div>
              Parlays Player Props , mix and match bets for better odds. Which
              player will score first , how many shots on goal will there be.
              <div className="font-medium mt-3">
                Bet on Future Games / Tournaments
              </div>
              Who will win the World Cup in Qatar., The FA Cup, MLS Cup ,
              Champions League etc.
              <div className="mt-3">In Game Live Betting</div>
              Becoming one of the most popular ways to bet and to increase the
              interest in a game your watching on TV/Streaming. Could be “next
              team to score”. &quot;will there be another goal before halftime”.
              Sportsbooks can get very creative. Might liven up even the dullest
              game.
              <div className="font-medium my-3">
                How Do I set up and account
              </div>
              <div className="font-medium mt-2">
                Opening and account : First Deposit and ongoing
              </div>
              Most sportsbooks accept a variety of ways for you to open an
              account and make deposits: Each Sportsbook does it slightly
              differently and there are various state laws. Fortunately the
              Sportsbooks have very thorough and legal sign ups process and will
              guide you through. Most accept: Credit /Debit Cards, Paypal,
              Venmo, Bank/ wire transfers. Once deposited (usually instant) you
              can start betting. Withdrawals cane made anytime via Paypal,
              Pre-Paid cards , Venmo with various “cash out” options, check,
              online banking. Often takes 1-5 days.
              <div className="my-3">
                Sportsbooks will offer many ways to entice you to open an
                account. The most common are
              </div>
              <div className="font-medium my-3">
                Usual Type of Offers and Promotion to sign up.
              </div>
              <div className="font-medium mt-3">Free Bets :</div>
              As it states : Have one free bet on a game : bet $100 on Liverpool
              to beat Everton for no risk to you.
              <div className="font-medium mt-3">Risk Free Bet:</div>
              Bet with your own money on Liverpool to beat Everton, if you lose
              you get your money back.
              <div className="font-medium mt-3">Deposit Match:</div>
              Open your new account with $100 and the Sportsbook with match it
              with their $100 (Usually limits apply).
              <div className="font-medium mt-3">Betting Credits:</div>
              The bonuses / free credits are normally applied as credits after
              the new bettor has made a deposit or first bet.
              <div className="font-medium mt-3">Support</div>
              Most good sportsbook offer 24/7 customer service to help with any
              issues you may have , either when signing up or ongoing while
              betting.
              <div className="font-medium mt-3">Bet Legally</div>
              <div className="font-medium">
                Firstly you must be over 21+ to bet
              </div>
              Also betting is only legal in the states highlighted in our
              Academy. You must be in a state that has approved betting on
              sports to place a bet. (Most sportsbooks will automatically stop
              you signing up if you are from non approved State.)
              <div className="font-medium mt-3">Gamble Responsibly</div>
              Every Sportsbook has links to guides on how to bet responsibly.
              And links to sites that can help if you feel addicted.
              <i className="block font-medium mt-3">
                Soccerbx, urges that if you are going to bet , bet sensibly, set
                limits, bet small , have fun…. use the tools Sportsbooks have to
                help you control your betting.
              </i>
            </div>
          </div>
        </div>
      </>
    )
  );
};

export default SoccerAcademy;
