import { useEffect, useState } from "react";
import Skeleton from "react-loading-skeleton";
import { FaFacebookF, FaWhatsapp, FaTwitter, FaShare } from "react-icons/fa";
import Link from "next/link";
import { useDispatch } from "react-redux";
import { MdOutlineChatBubble } from "react-icons/md";
import { AiOutlineArrowRight } from "react-icons/ai";
import { useRouter } from "next/router";
import "react-loading-skeleton/dist/skeleton.css";
import parse from "html-react-parser";
import { useSelector } from "react-redux";
import {
  FacebookShareButton,
  TwitterShareButton,
  WhatsappShareButton,
} from "react-share";
import {
  getAdImage,
  getSingleNewsData,
} from "../../Services/News/news.service";
import { getFeaturesSuccess } from "../../redux/reducers/featuresReducer/featuresReducers";
import LatestNews from "../../components/pagesComponents/Features/LatestNews/LatestNews";
import { calls } from "../../Services/PromiseHandler/PromiseHandler";
import Head from "next/head";

const monthNames = [
  "",
  "January",
  "February",
  "March",
  "April",
  "May",
  "June",
  "July",
  "August",
  "September",
  "October",
  "November",
  "December",
];

const Feature = ({ data, featureData }) => {
  const dispatch = useDispatch();
  const [dataToShow, setDataToShow] = useState({});
  const [loading, setLoading] = useState(true);
  const [shareURL, setShareURL] = useState("");

  const [nextArticle, setNextArticle] = useState({});
  const [content, setContent] = useState(null);
  const [sidebarAds, setSidebarAds] = useState([]);
  const [metaTitle, setMetaTitle] = useState("");
  const [metaDescription, setMetaDescription] = useState("");
  const [metaKeyword, setMetaKeyword] = useState("");
  const [altText, setAltText] = useState("");
  const router = useRouter();
  const {
    query: { slug, id },
  } = router;

  const latest = useSelector((state) =>
    state?.features?.data
      ?.filter((x) => x?._id !== dataToShow?._id)
      ?.slice(0, 4)
  );

  const handleNextFeature = (article) => {
    const { _id: id, slug } = article?.next;
    if (id) {
      router.push("/team-usa/[id]", `/team-usa/${slug}`, {
        shallow: true,
      });
      getNextArticle(id);
    }
  };
  const getNextArticle = async (id) => {
    const res = await calls(`features/${id}`, "get", null);
    setNextArticle(res?.data);
  };
  const getApiCalls = async (id) => {
    const res = await calls(`features/${id}`, "get", null);
    if (latest?.length <= 0) {
      const features = await calls("features", "get");
      dispatch(getFeaturesSuccess(features?.data ?? []));
    }
    setNextArticle(res?.data);
  };

  const resolvePromise = async (id) => {
    const data = await getAdImage(id);
    return data?.data;
  };
  const getSidebarAds = async (ids) => {
    const res = await Promise.all(
      ids?.split(",")?.map(async (id) => {
        return await resolvePromise(id);
      })
    );
    setSidebarAds(res.filter((x) => x));
  };

  useEffect(() => {
    if (data?._id) {
      setDataToShow(data);
      setContent(data?.content?.replace(/&nbsp;/g, " "));
      setLoading(false);
      getApiCalls(data?._id);
      if (data?.sidebarAds?.length > 0) {
        getSidebarAds(data?.sidebarAds);
      }
    }
  }, []);
  useEffect(() => {
    // iife
    (async () => {
      setLoading(true);
      const res = await calls(`features/${id}`, "get");
      let metaTitle = res?.data?.meta_title ?? "";
      let metaDescription = res?.data?.meta_des ?? "";
      let metaKeyword = res?.data?.meta_keyword ?? "";
      let altText = res?.data?.altText ?? "";

      let content = res?.data?.content;

      const paragraphs = content.match(/<p>(.*?)<\/p>/g);

      paragraphs?.forEach(function (p) {
        if (p.includes("youtube.com/watch?v=")) {
          const videoId = p.split("v=")[1].split("&")[0];
          const iframe = `<iframe src="https://www.youtube.com/embed/${videoId}" frameBorder="0" width="100%" height="315" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowFullscreen></iframe>`;
          content = content.replace(p, iframe);
        }
        if (p.includes("youtu.be/")) {
          const videoId = p.split("be/")[1].split(" ")[0];
          const iframe = `<iframe src="https://www.youtube.com/embed/${videoId}" frameBorder="0" width="100%" height="315" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowFullscreen></iframe>`;
          content = content.replace(p, iframe);
        }
      });
      setAltText(altText);
      setMetaTitle(metaTitle);
      setMetaDescription(metaDescription);
      setMetaKeyword(metaKeyword);
      setDataToShow(res?.data);
      setShareURL(
        typeof window !== "undefined"
          ? window?.location?.href
          : "https://www.soccerbx.com"
      );
      setContent(content.replace(/&nbsp;/g, " "));
      setLoading(false);
    })();
  }, [id, data, slug]);

  const createdAt = () => {
    const d = new Date(dataToShow?.createdAt);

    return `${d?.getDate()} ${
      monthNames[d.getMonth() + 1]
    } ${d?.getFullYear()}`;
  };

  const updateTime = (date) => {
    const time = new Date(date);
    const today = new Date();
    // converting time to usa timeZone.
    const americanTime = new Date(
      time?.toLocaleString("en-US", {
        timeZone: "America/New_York",
      })
    );

    if (
      time?.getMonth() === today?.getMonth() &&
      time?.getDate() === today.getDate()
    ) {
      return `${americanTime.getHours()}:${
        americanTime.getMinutes() < 9
          ? "0" + americanTime.getMinutes()
          : americanTime.getMinutes()
      }`;
    }
    return `${time?.getDate()} ${
      monthNames[time.getMonth() + 1]
    } ${time?.getFullYear()}`;
  };
  return (
    <div>
      <Head>
        <meta charset="utf-8" />
        <meta name="author" content={dataToShow?.author?.name ?? ""} />
        {/* <meta name="title" content={dataToShow?.title ?? ""} /> */}
        <meta name="title" content={metaTitle ?? ""} />

        {/* <meta name="description" content={dataToShow?.excerpt} /> */}
        <meta name="description" content={metaDescription ?? ""} />
        {/* <!-- Mobile Stuff --> */}
        <meta httpEquiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <meta name="msapplication-tap-highlight" content="no" />

        {/* Chrome on Android */}
        <meta name="mobile-web-app-capable" content="yes" />
        <meta name="application-name" content="SoccerBx" />

        {/* <!-- Safari on iOS --> */}
        <meta name="apple-mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-status-bar-style" content="black" />
        <meta name="apple-mobile-web-app-title" content="CHANGE-ME" />

        {/* <!-- Windows 8 --> */}
        <meta
          name="msapplication-TileImage"
          content={dataToShow?.featuredImage}
        />
        <meta name="msapplication-TileColor" content="#FFFFFF" />

        <meta name="theme-color" content="#000000" />

        {!loading && <title>{dataToShow?.title}</title>}

        <meta
          property="og:title"
          content={dataToShow?.title ?? "Soccerbet Team USA"}
        />
        <meta
          property="og:description"
          content={
            dataToShow?.subTitle ??
            "We are a soccer company dedicated to serving the changing landscape of soccer in the USA"
          }
        />
        <meta
          property="og:image"
          content={
            dataToShow?.featuredImage ?? "/images/homepage/hero-bg-lg.jpg"
          }
        />
        <meta
          property="og:url"
          content={shareURL ?? "https://www.soccerbx.com"}
        />

        <meta name="og:card" content="summary_large_image" />
      </Head>
      {loading ? (
        <div className="flex">
          <div className="border-r border-black sm:h-[500px] w-[50%] h-[200px]">
            <Skeleton height="100%" width="100%" />
          </div>
          <div className="sm:h-[500px] w-[50%] h-[200px]">
            <Skeleton height="100%" width="100%" />
          </div>
        </div>
      ) : !dataToShow?._id ? (
        <h1>No Data Found :( </h1>
      ) : (
        <>
          <div className="flex xs:flex-row">
            <div className="flex-1 flex w-full items-center justify-center bg-black max-w-[50%] py-3 sm:py-0">
              <ul className="text-center uppercase">
                <li>
                  <h1 className="sm:text-[50px] text-[27px] md:text-[80px] sm:leading-[65px] leading-[23px] text-white">
                    {dataToShow?.title?.split(" ")?.[0] ?? ""}
                  </h1>
                </li>
                <li>
                  <h1 className="sm:text-[50px] text-[27px] md:text-[80px] sm:leading-[65px] leading-[23px] text-white">
                    {dataToShow?.title?.split(" ")?.[1] ?? ""}
                  </h1>
                </li>
                <li>
                  <h1 className="sm:text-[50px] text-[27px] md:text-[80px] sm:leading-[65px] leading-[23px] text-white">
                    {dataToShow?.title?.split(" ")?.[2] ?? ""}
                  </h1>
                </li>
              </ul>
            </div>
            <div className="flex-1  max-w-[50%]">
              {loading && !dataToShow?.featuredImage ? (
                <Skeleton height={300} width="100%" />
              ) : (
                <img
                  src={dataToShow?.featuredImage}
                  alt={altText ?? ""}
                  width="100%"
                  className={`lg:h-[640px] sm:min-h-48 md:min-h-[400px] lg:w-[640px] sm:w-full w-full h-[187px]  object-cover ${
                    !Boolean(dataToShow?.featuredImage) && "no-image_img"
                  }`}
                />
              )}
            </div>
          </div>

          <div className="sm:px-10 px-3">
            <div className="mx-auto md:grid grid-cols-12 flex items-start justify-between hidden">
              <div className="md:col-span-2 mt-3 hidden sm:block text-[12px]">
                Photo Credit
              </div>
              <div className="max-w-[600px] md:col-span-7">
                <h2 className="mt-[32px] text-left text-[24px] font-[500] leading-[28px] sm:px-3 uppercase">
                  {dataToShow?.subTitle || ""}
                </h2>
              </div>
              {nextArticle?.next?._id && (
                <div className="sm:pt-7">
                  <button
                    className={`${
                      !nextArticle?._id ? "color-[#6B6B6B]" : "cursor-pointer"
                    } leading-[1] border-b-2 border-color-[#6B6B6B]`}
                    title={nextArticle?.next?.title ?? ""}
                    disabled={!nextArticle?.next?._id}
                    onClick={() => handleNextFeature(nextArticle)}>
                    <span className="flex items-center">
                      Next Story
                      <img src="/images/next-arrow-slate.svg" />
                    </span>
                  </button>
                </div>
              )}
            </div>
            <div className="mx-auto grid grid-cols-12 mb-[56px]">
              <div className="md:col-span-2 col-span-12 border-b-2 md:border-b-0 sm:pb-3 sm:mb-6 sm:pr-3 mobile-linear-border">
                <div className="flex md:flex-col flex-row-reverse w-full justify-between md:max-w-[200px] mt-[16px] md:mt-[35px] items-start sm:items-stretch">
                  <div className="flex pb-1 pb-[8px] sm-linear-border items-center">
                    <span className="mr-2">
                      <FaShare />
                    </span>
                    <FacebookShareButton
                      // url={window?.location?.href ?? "https://www.soccerbx.com"}
                      // url={
                      //   typeof window !== "undefined" &&
                      //   (window?.location?.href ?? "https://www.soccerbx.com")
                      // }
                      // quote={"This is a testing quote"}
                      // hashtag={"#soccerBx"}
                      // >

                      // title="Leicester v Liverpool "
                      // quote="Leicester v Liverpool subtile"
                      url={shareURL}>
                      <div className="h-[24px] w-[24px] flex items-center justify-center bg-black rounded-full">
                        <FaFacebookF className="fill-white" />
                      </div>
                    </FacebookShareButton>

                    <TwitterShareButton
                      title="Leicester v Liverpool "
                      url={shareURL}>
                      <div className="ml-2 h-[24px] w-[24px] flex items-center justify-center bg-black rounded-full">
                        <FaTwitter className="fill-white" />
                      </div>
                    </TwitterShareButton>

                    <WhatsappShareButton
                      title="Leicester v Liverpool "
                      url={shareURL}>
                      <div className="ml-2 h-[24px] w-[24px] flex items-center justify-center bg-black rounded-full">
                        <FaWhatsapp className="fill-white" />
                      </div>
                    </WhatsappShareButton>
                    {/* <FacebookShareButton
                      url={
                        typeof window !== "undefined" && window?.location?.href
                      }
                      quote={"This is a testing quote"}
                      hashtag={"#soccerBx"}
                      description={"Thsi is a testing description"}
                      title={dataToShow?.subTitle ?? ""}>
                      <div className="h-[24px] w-[24px] flex items-center justify-center bg-black rounded-full ml-2">
                        <FaFacebookF className="fill-white" />
                      </div>
                    </FacebookShareButton>
                    <Link href="instagram.com">
                      <a
                        target="_blank"
                        className="h-[24px] w-[24px] flex items-center justify-center bg-black rounded-full ml-2">
                        <FaInstagram className="fill-white" />
                      </a>
                    </Link>

                    <a
                      target="_blank"
                      className="h-[24px] w-[24px] flex items-center justify-center bg-black rounded-full ml-2"
                      href={`https://twitter.com/intent/tweet?text=${
                        typeof window !== "undefined" && window?.location?.href
                      }`}
                      rel="noreferrer">
                      <FaTwitter className="fill-white" />
                    </a> */}
                  </div>
                  <div>
                    <strong className="text-[12px] mb-[16px] inline-block">
                      {/* {dataToShow?.author?.name ?? "Unknown"} */}
                      Soccerbx Team
                    </strong>
                    {<div className="text-[12px]">{createdAt()}</div>}
                    {dataToShow?.lastUpdate && (
                      <div className="text-[12px]">
                        Updated {updateTime(dataToShow?.lastUpdate)} EST
                      </div>
                    )}
                  </div>
                </div>
                {/* <div className="flex items-center py-[8px]">
                  <MdOutlineChatBubble />{" "}
                  <span className="text-[12px]">
                    {dataToShow?.comments?.length ?? 0}
                  </span>
                </div> */}
              </div>
              <div className="overflow-hidden newsMain-content_f_ads sm:px-3 col-span-12 md:col-span-7">
                <div className="max-w-[600px] md:mt-[14px] ">
                  <h2 className="text-left text-[24px] font-[500] leading-[28px] sm:px-3 uppercase md:hidden block">
                    {dataToShow?.subTitle || ""}
                  </h2>
                  <div className="editorContent overflow-hidden">
                    {parse(featureData)}
                  </div>
                </div>
              </div>
              <div className="md:mt-[35px] md:col-span-3 col-span-12 border-b-2 md:border-b-0 sm:pb-3 sm:mb-6 flex flex-col">
                {sidebarAds?.length > 0 &&
                  sidebarAds?.map((ad, i) => (
                    <div key={i} className="my-4">
                      <a
                        rel="noreferrer"
                        target="_blank"
                        href={`//${ad?.linkTo}`}>
                        {ad?.type === "image" ? (
                          <img width="100%" src={ad?.url} alt="CHANGE_ME" />
                        ) : (
                          <video muted loop autoPlay width="100%">
                            <source src={ad?.url} type="video/mp4" />
                            Your browser does not support HTML video.
                          </video>
                        )}
                      </a>
                    </div>
                  ))}

                <div className="border-t">
                  <h4 className="text-2xl">More stories</h4>
                  {latest?.map((l) => (
                    <div className="my-3" key={l?.id}>
                      <LatestNews
                        slug={`team-usa/${l.slug}`}
                        type="image"
                        image={l?.featuredImage}
                        author={l?.author?.name}
                        heading={l?.title}
                        commentsCount={l?.commentsCount}
                      />
                    </div>
                  ))}
                </div>
                {/* <div className="mt-5 border-t">
                  <h3 className="text-2xl">MORE STORIES</h3>
                  <div className="mt-3">
                    <Link href="temp">
                      <a>
                        {" "}
                        <h4 className="my-1 text-base">kane score again</h4>
                      </a>
                    </Link>
                    <Link href="temp">
                      <a>
                        <h4 className="my-1 text-base">frantic final week</h4>
                      </a>
                    </Link>
                    <Link href="temp">
                      <a>
                        <h4 className="my-1 text-base">
                          carvalho to liverpool
                        </h4>
                      </a>
                    </Link>
                    <Link href="temp">
                      <a>
                        <h4 className="my-1 text-base">city take title</h4>
                      </a>
                    </Link>
                  </div>
                </div> */}
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  );
};

export default Feature;

const getImageAndReplaceWithHtml = async (id) => {
  const data = await getAdImage(id);
  if (data?.data?.url) {
    if (data?.data?.type === "image") {
      return `<a class='py-4 block addFor-${
        data?.data?.category
      }' href='//${data?.data?.linkTo.trim()}' target="_blank"><img src=${
        data?.data?.url
      } alt="CHANGE_ME" width="100%"/></a>`;
    }
    if (data?.data?.type === "video") {
      return `<a class='py-4 block addFor-${
        data?.data?.category
      }' href='//${data?.data?.linkTo.trim()}' target="_blank">
      <video loop muted autoPlay playsinline src="${
        data?.data?.url
      }" width="100%">
  
  Your browser does not support HTML video.</video>
        </a>`;
    }
  }

  return "";
};

const replaceShortCodesWithAds = async (html) => {
  const tempArr = html?.split("~[SC~");
  const ids = [];
  tempArr?.forEach((f, i) => (i % 2 !== 0 ? ids.push(f.trim()) : f));
  if (ids?.length) {
    const updateHtml = await Promise.all(
      tempArr?.map(async (t) => {
        return ids?.includes(t.trim())
          ? await getImageAndReplaceWithHtml(t?.trim())
          : t?.replace(/\r?\n|\r/g, "");
      })
    );
    return updateHtml?.join("");
  }
  return html?.replace(/\r?\n|\r/g, "");
};
export async function getServerSideProps(context) {
  const { id } = context?.params;
  const data = await calls(`features/${id}`, "get");
  let newsData = "";
  if (data?.data) {
    // ads for small screens and main-content
    newsData = await replaceShortCodesWithAds(data?.data?.content);
  }
  return {
    props: {
      data: data?.data || null,
      featureData: newsData || "",
    },
  };
}
