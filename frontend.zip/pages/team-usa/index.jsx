import React, { useEffect, useState } from "react";
import Skeleton from "react-loading-skeleton";
import { useDispatch, useSelector } from "react-redux";
import "react-loading-skeleton/dist/skeleton.css";
import Link from "next/link";
import AdBanner from "../../components/single/home/AdBanner";
import BigCard from "../../components/pagesComponents/News/Cards/BigCard";
import { calls } from "../../Services/PromiseHandler/PromiseHandler";
import { getFeaturesSuccess } from "../../redux/reducers/featuresReducer/featuresReducers";
import Head from "next/head";

const Features = () => {
  const dispatch = useDispatch();

  const [loading, setLoading] = useState(true);

  const getFeatures = async () => {
    const res = await calls("features", "get");
    setLoading(false);
    dispatch(getFeaturesSuccess(res?.data ?? []));
  };

  const features = useSelector((state) => state.features?.data);

  useEffect(() => {
    if (features?.length <= 0) {
      getFeatures();
    }
    if (features?.length > 0) {
      setLoading(false);
    }
  }, []);

  const featureNews = features?.filter(
    (item) => item.pinned && item?.status === "published" && !item.isScheduled
  );

  const latestHeaderNews = features?.filter(
    (news) => news?.status === "published" && !news.isScheduled
  );
  const headerData = featureNews?.[0] ?? latestHeaderNews[0];

  return (
    <>
      <Head>
        <title>Team USA | SoccerBx </title>
      </Head>
      {!features?.length && !loading ? (
        <h1>No Data Found :( </h1>
      ) : (
        <>
          <Link href={`/team-usa/${headerData?.slug}`}>
            <div className="cursor-pointer">
              <div className="flex xs:flex-row">
                <div className="flex-1 flex w-full items-center justify-center bg-black max-w-[50%]">
                  <ul className="text-center uppercase">
                    <li>
                      <h1 className="sm:text-[50px] text-[27px] md:text-[80px] sm:leading-[65px] leading-[23px] text-white">
                        {headerData?.title?.split(" ")?.[0] ?? ""}
                      </h1>
                    </li>
                    <li>
                      <h1 className="sm:text-[50px] text-[27px] md:text-[80px] sm:leading-[65px] leading-[23px] text-white">
                        {headerData?.title?.split(" ")?.[1] ?? ""}
                      </h1>
                    </li>
                    <li>
                      <h1 className="sm:text-[50px] text-[27px] md:text-[80px] sm:leading-[65px] leading-[23px] text-white">
                        {headerData?.title?.split(" ")?.[2] ?? ""}
                      </h1>
                    </li>
                  </ul>
                </div>
                <div className="flex-1 max-w-[50%]">
                  {loading && !headerData?.featuredImage ? (
                    <Skeleton height={300} width="100%" />
                  ) : (
                    <img
                      src={headerData?.featuredImage}
                      alt={headerData?.title ?? ""}
                      width="100%"
                      className={`lg:h-[640px] sm:min-h-48 md:min-h-[400px] lg:w-[640px] sm:w-full w-full h-[187px]  object-cover ${
                        !Boolean(headerData?.featuredImage) && "no-image_img"
                      }`}
                    />
                  )}
                </div>
              </div>
            </div>
          </Link>

          <div className="grid grid-cols-12 gap-3 mt-3 mb-5 px-5">
            {loading ? (
              <>
                {["sk1", "sk2", "sk3", "sk4"].map((x) => (
                  <div
                    className="sm:col-span-4 md:col-span-3 col-span-12 my-3"
                    key={x}>
                    <Skeleton height={200} width="100%" />
                  </div>
                ))}
              </>
            ) : (
              <>
                {features
                  ?.filter(
                    (item) => item.status === "published" && !item.isScheduled
                  )
                  .slice(1)
                  ?.map((item) => (
                    <div
                      className="sm:col-span-4 md:col-span-3 col-span-12 my-3"
                      key={item?._id}>
                      <BigCard
                        img={item?.featuredImage}
                        slug={`/team-usa/${item?.slug}`}
                        author={item?.author?.name}
                        title={item?.title}
                        commentsLength={item?.commentsCount}
                        excerpt={item?.excerpt}
                      />
                    </div>
                  ))}
                {/* <div className="col-span-12">
              <AdBanner />
            </div> */}
              </>
            )}
          </div>
        </>
      )}
    </>
  );
};

export default Features;
