import React, { useEffect, useState } from "react";
import Header from "../components/single/Header";
import Footer from "../components/single/Footer";
import CookieConsent from "react-cookie-consent";
 
export default function Layout({ children }) {
  const [isMounted, setIsMounted] = useState(false);
  useEffect(() => {
    setIsMounted(true);
  }, []);
  return (
    <React.Fragment>
      <Header />

      <CookieConsent
        location="bottom"
        buttonText="Accept"
        cookieName="myAwesomeCookieName2"
        style={{ background: "#000" }}
        buttonStyle={{
          color: "#fff",
          border: "1px solid #fff",
          backgroundColor: "transparent",
        }}
        expires={150}
        enableDeclineButton
        declineButtonText="Decline"
        declineButtonStyle={{
          backgroundColor: "var(--soccer-red)",
          border: "1px solid #fff",
        }}
      >
        This website uses cookies to enhance the user experience.
      </CookieConsent>
      <main className="max-w-[1280px] mx-auto">{children}</main>
      <Footer />
    </React.Fragment>
  );
}
