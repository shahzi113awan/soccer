import Link from "next/link";
import React, { useState, useEffect } from "react";
import { validateEmail } from "../../utills/ValidateEmail";
import toast from "react-hot-toast";
import { useRouter } from "next/router";

const containerStyling = {
  background:
    "linear-gradient(68.29deg, #BA1622 0.47%, #B71825 9.81%, #AD1D2E 19.14%, #9D273D 26.91%, #863452 34.69%, #69456D 42.98%, #4F5485 52.31%, #435B91 60.6%, #3265A1 70.45%, #266CAC 80.82%, #1F70B2 91.19%, #1D71B4 100%)",
  position: "fixed",
  left: 0,
  right: 0,
  top: 0,
  height: "100vh",
  bottom: 0,
  width: "100%",
  zIndex: 51,
};

const Index = () => {
  const [showLoginForm, setShowLoginForm] = useState(false);
  const [errors, setErrors] = useState({});
  const [values, setValues] = useState({});
  const handleChange = (e) => {
    const { name, value } = e.target;
    setErrors({
      ...errors,
      [name]: !values[name],
    });

    setValues({
      ...values,
      [name]: value,
    });
  };
  const userExist = () =>
    values?.email === "admin@soccerbx.com" && values?.password === "root@123@";

  const handleSubmit = (e) => {
    e.preventDefault();
    toast.remove();

    if (
      userExist() &&
      validateEmail(values?.email) &&
      values?.password?.length > 3
    ) {
      var date = new Date(),
        expires = "expires=";
      date.setDate(date.getDate() + 1);
      expires += date.toGMTString();
      document.cookie = "isAuth" + "=" + true + "; " + expires + "; path=/";

      router.push("/");
    } else {
      toast.error("Please enter valid credentials");
    }
  };
  const router = useRouter();
  const isAuth =
    typeof window !== "undefined" && document.cookie.indexOf("isAuth") > 0;
  useEffect(() => {
    if (!!isAuth) {
      router.push("/");
    }
  }, []);
  return (
    <section
      className="h-[100vh] flex flex-col items-center justify-center px-3"
      style={containerStyling}
    >
      <div className="max-w-[650px] w-full">
        {showLoginForm ? (
          <form className="login-form max-w-[400px] mx-auto">
            <div className="py-4">
              {" "}
              <input
                className={`rounded-none w-full text-white p-2 bg-transparent border-b ${
                  errors?.name && "border-red-700"
                }`}
                type="email"
                value={values?.email}
                onChange={handleChange}
                placeholder={!values?.email ? "Email" : ""}
                name="email"
                id="email"
              />
            </div>
            <div className="py-4">
              {" "}
              <input
                className={`rounded-none w-full text-white p-2 bg-transparent border-b ${
                  errors?.name && "border-red-700"
                }`}
                type="password"
                value={values?.password ?? ""}
                onChange={handleChange}
                placeholder={!values?.password ? "Password" : ""}
                name="password"
                id="password"
              />
            </div>
            <button
              onClick={handleSubmit}
              className="mx-auto block mt-4 py-2 px-5 bg-black text-white"
            >
              SUBMIT
            </button>
          </form>
        ) : (
          <div>
            <div className="w-[33%] mb-[2rem] mx-auto">
              <img
                src="/logo/soccerbx-white-logo-square-big.svg"
                alt="SoccerBX"
              />
            </div>
            <div className="text">
              <p
                onClick={() => setShowLoginForm(true)}
                className="cursor-pointer text-[1.8rem] text-center sm:text-[62px] font-[500] text-white"
              >
                KICKING OFF SOON
              </p>
            </div>
          </div>
        )}
      </div>
    </section>
  );
};

export default Index;
