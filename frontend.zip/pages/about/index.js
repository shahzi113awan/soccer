import React from "react";
import Head from "next/head";

const About = () => {
  return (
    <>
      <Head>
        <title>About Us | SoccerBx </title>
      </Head>
      <div className="lg:px-[0px] px-[15px] sm:px-[24px] mt-[48px] max-w-[600px] mx-auto">
        <div className="mb-[24px]">
          <h1 className="text-xl font-[500] uppercase">About Us</h1>
          <p className="text-md leading-6 mt-4">
            Welcome to{" "}
            <span className="text-blue-700">
              <a href="soccerbx.com">Soccerbx.com</a>
            </span>
            . We are a soccer company dedicated to serving the changing
            landscape of soccer in the USA and the way in which fans consume and
            engage with the game. It’s still the beautiful game but it’s a new
            Virtual, interactive, Gaming, and Web 3.0 world that will shape it.
            Our first offering focuses on the newly legalized USA Betting market
            which now allows fans in over 32 states to legally bet on soccer.
          </p>
          <h3 className="text-md leading-6 mt-3 md:mt-8">
            Welcome to{" "}
            <a
              className="text-[#000] font-[900] underline"
              href="https://soccerbet.io"
              target={"_blank"}
              rel="noreferrer">
              soccerbet.io
            </a>{" "}
          </h3>
          <p className="text-md leading-6 mt-4">
            Firstly we are{" "}
            <span className="font-bold underline text-sm">
              not a sportsbook
            </span>{" "}
            . We are a place you should come to learn about betting on soccer.
            We write about the key games in selected leagues and give you tips
            and insights about the likely outcome. We look at the current form,
            head-to-head history, and other relevant stats to help you decide
            what might be a smart bet. We also have a{" "}
            <a
              className="text-blue-700 underline "
              href="https://soccerbet.io"
              target={"_blank"}
              rel="noreferrer">
              soccerbet.io
            </a>{" "}
            academy page to assist and support you with information to help you
            bet knowledgeably and sensibly.
          </p>

          <p className="text-md leading-6 mt-4">
            We have also partnered with some of America’s leading Sportsbooks to
            provide you with a top-quality experience for any of your betting
            needs. They will help walk you through the “sign up” process (it’s
            simple and easy) and provide a legal, trustworthy, and easy platform
            to enjoy your betting experience. No one however can truly predict
            the outcome: and that’s why we love the game. Betting on the outcome
            of a game can enhance your interest and enjoyment but do it
            responsibly. Bet small and have fun.
          </p>
          <p className="text-md leading-6 mt-4">
            If you don’t want to bet that’s ok too. Just enjoy the content and
            insights delivered by people that know the game and have the
            experience and contacts to provide knowledgeable and authentic
            soccer-specific insights.
          </p>
          <p className="text-md leading-6 mt-4">
            Remember to bet on soccer in the USA you must be over 21 and in a
            state that has legalized sports betting. Check the{" "}
            <a
              className="text-blue-700 underline "
              href="https://soccerbet.io"
              target={"_blank"}
              rel="noreferrer">
              soccerbet.io
            </a>{" "}
            .academy page for more info. (Also the sign-up process for the
            Sportsbook will automatically tell you if you are allowed or not)
          </p>
          <p className="text-md leading-6 mt-4">
            The folks behind Soccerbx and soccerbet.io are all soccer fans with
            decades of involvement with the game in the USA and worldwide. Enjoy
            and have fun.
          </p>
          <h5 className="uppercase text-md mb-2 mt-5">Contact:</h5>
          <p className="font-bold text-sm leading-6">
            CEO <br />
            Gary Hopkins <br />
            <a
              className="text-blue-700 font-normal underline"
              href="mailto:gary.hopkins@soccerbx.com">
              gary.hopkins@soccerbx.com
            </a>{" "}
            <br />
            <br />
            Chairman <br />
            Gary Otto <br />
            <a
              className="text-blue-700 font-normal underline"
              href="mailto:gary.otto@soccerbx.com">
              gary.otto@soccerbx.com
            </a>{" "}
            <br />
            <br />
          </p>
          <h5 className="uppercase text-md mb-2">Address:</h5>
          <p className="text-md ">
            Soccerbx , LLC <br />
            132 West 31st Street <br />
            9th Floor <br />
            New York <br />
            NY 10001
          </p>
          <br />

          <h5 className="uppercase text-md mb-2">For General inquiries</h5>
          <p className="mb-10">
            <a
              className="text-blue-700 font-normal underline"
              href="mailto:contact@soccerbx.com">
              contact@soccerbx.com
            </a>
          </p>
        </div>
      </div>
    </>
  );
};

export default About;
