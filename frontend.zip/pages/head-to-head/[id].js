import { useEffect, useState } from "react";
import { getSinglePreview } from "../../Services/previews/previews.service";
import { FaFacebookF, FaInstagram, FaTwitter, FaShare } from "react-icons/fa";
import parse from "html-react-parser";

import Link from "next/link";
import { MdOutlineChatBubble } from "react-icons/md";
import { AiOutlineArrowRight } from "react-icons/ai";
import { useRouter } from "next/router";
import Skeleton from "react-loading-skeleton";
import "react-loading-skeleton/dist/skeleton.css";
import { FacebookShareButton } from "react-share";
import { getAdImage } from "../../Services/News/news.service";
import TitleTable from "../../components/commonComponents/TitleTable/TitleTable";
import Head from "next/head";
const monthNames = [
  "",
  "January",
  "February",
  "March",
  "April",
  "May",
  "June",
  "July",
  "August",
  "September",
  "October",
  "November",
  "December",
];
const SinglePreview = ({ data, previewData }) => {
  const [dataToShow, setDataToShow] = useState({});
  const [loading, setLoading] = useState(true);
  const [nextArticle, setNextArticle] = useState({});
  const [sidebarAds, setSidebarAds] = useState([]);
  const [metaTitle, setMetaTitle] = useState("");
  const [metaDescription, setMetaDescription] = useState("");
  const [metaKeyword, setMetaKeyword] = useState("");
  const [altText, setAltText] = useState("");

  const router = useRouter();
  const {
    query: { slug, id },
  } = router;

  const handleNextPreview = (article) => {
    const { _id: id, slug } = article?.next;
    if (id) {
      router.push("/priewes/[id]", `/priewes/${slug}`, {
        shallow: true,
      });
      getNextArticle(id);
    }
  };
  const getNextArticle = async (id) => {
    const res = await getSinglePreview(id);
    setNextArticle(res?.data);
  };
  const resolvePromise = async (id) => {
    const data = await getAdImage(id);
    return data?.data;
  };
  const getSidebarAds = async (ids) => {
    const res = await Promise.all(
      ids?.split(",")?.map(async (id) => {
        return await resolvePromise(id);
      })
    );
    setSidebarAds(res.filter((x) => x));
  };
  useEffect(() => {
    if (data?._id) {
      setDataToShow(data);
      setLoading(false);
      getNextArticle(data?._id);
      if (data?.sidebarAds?.length > 0) {
        getSidebarAds(data?.sidebarAds);
      }
    }
  }, []);

  useEffect(() => {
    // iife
    (async () => {
      setLoading(true);
      const res = await getSinglePreview(id);
      const anchors = res;
      let metaTitle = res?.data?.meta_title ?? "";
      let metaDescription = res?.data?.meta_des ?? "";
      let metaKeyword = res?.data?.meta_keyword ?? "";
      let altText = res?.data?.altText ?? "";

      anchors = document.getElementsByTagName("a");
      Array.from(anchors).forEach(function (anchor) {
        if (anchor.href.includes("youtube.com/watch")) {
          const videoId = anchor.href.split("v=")[1].split("&")[0];
          const iframe = document.createElement("iframe");
          iframe.src = `https://www.youtube.com/embed/${videoId}`;
          iframe.frameBorder = "0";
          iframe.width = "100%";
          iframe.height = "270";
          iframe.allow =
            "accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture";
          iframe.allowFullscreen = true;
          anchor.parentNode.replaceChild(iframe, anchor);
        }
      });
      setAltText(altText);
      setMetaTitle(metaTitle);
      setMetaDescription(metaDescription);
      setMetaKeyword(metaKeyword);
      setDataToShow(res?.data);
      setLoading(false);
    })();
  }, [id, data, slug]);

  const createdAt = () => {
    const d = new Date(dataToShow?.createdAt);

    return `${d?.getDate()} ${
      monthNames[d.getMonth() + 1]
    } ${d?.getFullYear()}`;
  };

  const updateTime = (date) => {
    const time = new Date(date);
    const today = new Date();
    // converting time to usa timeZone.
    const americanTime = new Date(
      time?.toLocaleString("en-US", {
        timeZone: "America/New_York",
      })
    );

    if (
      time?.getMonth() === today?.getMonth() &&
      time?.getDate() === today.getDate()
    ) {
      return `${americanTime.getHours()}:${
        americanTime.getMinutes() < 9
          ? "0" + americanTime.getMinutes()
          : americanTime.getMinutes()
      }`;
    }
    return `${time?.getDate()} ${
      monthNames[time.getMonth() + 1]
    } ${time?.getFullYear()}`;
  };
  return (
    <div>
      <Head>
        <meta charset="utf-8" />
        <meta name="author" content={dataToShow?.author?.name ?? ""} />
        {/* <meta name="title" content={dataToShow?.title ?? ""} /> */}
        <meta name="title" content={metaTitle ?? ""} />

        {/* <meta name="description" content={dataToShow?.excerpt} /> */}
        <meta name="description" content={metaDescription ?? ""} />
        {/* <!-- Mobile Stuff --> */}
        <meta httpEquiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <meta name="msapplication-tap-highlight" content="no" />

        {/* Chrome on Android */}
        <meta name="mobile-web-app-capable" content="yes" />
        <meta name="application-name" content="SoccerBx" />

        {/* <!-- Safari on iOS --> */}
        <meta name="apple-mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-status-bar-style" content="black" />
        <meta name="apple-mobile-web-app-title" content="CHANGE-ME" />

        {/* <!-- Windows 8 --> */}
        <meta
          name="msapplication-TileImage"
          content={dataToShow?.featuredImage}
        />
        <meta name="msapplication-TileColor" content="#FFFFFF" />

        <meta name="theme-color" content="#000000" />

        {!loading && <title>{dataToShow?.title}</title>}
      </Head>
      {loading ? (
        <div className="flex">
          <div className="border-r border-black sm:h-[500px] w-[50%] h-[200px]">
            <Skeleton height="100%" width="100%" />
          </div>
          <div className="sm:h-[500px] w-[50%] h-[200px]">
            <Skeleton height="100%" width="100%" />
          </div>
        </div>
      ) : !dataToShow?._id ? (
        <h1 className="text-center my-4">No Data Found :(</h1>
      ) : (
        <>
          <div className="flex mx-auto sm:mt-5 max-w-[806px]">
            <div className="flex-1 flex w-full items-center justify-center bg-black max-w-[50%]">
              <div className="flex-1 max-w-[155px] sm:max-w-[280px] max-h-[280px] sm:h-[280px]">
                <TitleTable title={dataToShow?.title} />
              </div>
            </div>
            <div className="flex-1 bg-black">
              {loading ? (
                <Skeleton height={300} width="100%" />
              ) : (
                <img
                  src={dataToShow?.featuredImage}
                  alt={altText ?? ""}
                  width="100%"
                  className={`relative w-[185px] h-[187px] sm:h-[300px] sm:w-[300px] md:h-[403px] md:w-[403px] object-cover ${
                    Boolean(!dataToShow?.featuredImage) && "no-image_img"
                  }`}
                />
              )}
            </div>
          </div>

          <div className="sm:px-10 px-3">
            <div className="mx-auto md:grid grid-cols-12 flex items-start justify-between hidden lg:mt-[36px]">
              <div className="md:col-span-2 mt-2 hidden sm:block text-[12px]"></div>
              <div className="md:col-span-9 flex justify-between items-top">
                <div className="text-left text-[24px] font-[500] leading-[28px]  uppercase">
                  <h2 className="max-w-[600px] font-[500] text-[48px] leading-[48px] mb-[8px]">
                    {dataToShow?.subTitle || ""}
                  </h2>
                  <div className="">
                    <h4 className="text-black font-[500] text-[24px] leading-[28px]">
                      <div>
                        {dataToShow?.venueLocation ?? ""}
                        {dataToShow?.venueDateAndTime &&
                          ` - ${new Date(
                            dataToShow?.venueDateAndTime
                          )?.getHours()}.${
                            new Date(
                              dataToShow?.venueDateAndTime
                            )?.getMinutes() <= 9
                              ? "0" +
                                new Date(
                                  dataToShow?.venueDateAndTime
                                )?.getMinutes()
                              : new Date(
                                  dataToShow?.venueDateAndTime
                                )?.getMinutes()
                          }
                 EST`}
                      </div>
                      <div>
                        {dataToShow?.venueDateAndTime &&
                          new Date(
                            dataToShow?.venueDateAndTime
                          )?.toDateString()}
                      </div>
                    </h4>
                  </div>
                </div>
              </div>
            </div>
            <div className="mx-auto grid grid-cols-12">
              <div className="md:col-span-2 col-span-12 border-b-2 mr-4 md:border-b-0 sm:pb-3 sm:mb-6 mobile-linear-border pb-3">
                <div className="flex sm:flex-col flex-row-reverse w-full justify-between sm:items-initial items-start mt-[20px] sm:mt-[105px]">
                  <div className="flex py-1 pb-[8px] sm-linear-border items-center md:w-full">
                    <span className="mr-2">
                      <FaShare />
                    </span>

                    {/* <FacebookShareButton
                      url={
                        typeof window !== "undefined" && window?.location?.href
                      }
                      quote={"This is a testing quote"}
                      hashtag={"#soccerBx"}
                      description={"Thsi is a testing description"}
                      title={dataToShow?.title ?? "hello World"}>
                      <div className="h-[24px] w-[24px] flex items-center justify-center bg-black rounded-full ml-2">
                        <FaFacebookF className="fill-white" />
                      </div>
                    </FacebookShareButton> */}
                    <FacebookShareButton
                      url={
                        // typeof window !== "undefined" && window?.location?.href
                        "http://51.104.192.62:3002/head-to-head/ful-v-che"
                      }
                      quote={"This is a testing quote"}
                      hashtag={"#soccerBx"}
                      description={"This is a testing description"}
                      title={"Hello World"}
                      meta={{
                        title: "Hello World",
                        description: "This is a testing description",
                      }}>
                      <div className="h-[24px] w-[24px] flex items-center justify-center bg-black rounded-full ml-2">
                        <FaFacebookF className="fill-white" />
                      </div>
                    </FacebookShareButton>
                    <Link href="instagram.com">
                      <a
                        target="_blank"
                        className="h-[24px] w-[24px] flex items-center justify-center bg-black rounded-full ml-2">
                        <FaInstagram className="fill-white" />
                      </a>
                    </Link>

                    <a
                      target="_blank"
                      className="h-[24px] w-[24px] flex items-center justify-center bg-black rounded-full ml-2"
                      href={`https://twitter.com/intent/tweet?text=${
                        typeof window !== "undefined" && window?.location?.href
                      }`}
                      rel="noreferrer">
                      <FaTwitter className="fill-white" />
                    </a>
                  </div>
                  <div>
                    {/* <strong>By {dataToShow?.author?.name ?? "Unknown"}</strong> */}
                    <strong>By Soccerbx Team</strong>

                    {<div>{createdAt(dataToShow?.createdAt)}</div>}
                    {dataToShow?.lastUpdate && (
                      <div>
                        Updated {updateTime(dataToShow?.lastUpdate)} EST
                      </div>
                    )}
                  </div>
                </div>
                {/* <div className="flex items-center py-[8px]">
                  <MdOutlineChatBubble />
                  <span className="text-[12px] pl-[5px]">
                    {dataToShow?.comments?.length ?? 0}
                  </span>
                </div> */}
              </div>
              <div className="newsMain-content_f_ads col-span-12 md:col-span-7 md:pr-10 pb-[32px] mb-[32px] border-b">
                {/* next and preview */}
                {/* {nextArticle?.next?._id && (
                  <div className="text-right mb-3">
                    <button
                      className={
                        !nextArticle?._id ? "text-gray-400" : "cursor-pointer"
                      }
                      disabled={!nextArticle?._id}
                      onClick={() => handleNextPreview(nextArticle)}
                    >
                      {" "}
                      <AiOutlineArrowRight />
                    </button>
                  </div>
                )} */}
                <h2 className="md:hidden block text-[32px] leading-[36px] md:text-[48px] md:leading-[48px] uppercase font-[500] my-4">
                  {dataToShow?.subTitle || ""}
                </h2>
                <div className="text-[20px] font-[500] leading-[24px] sm:hidden">
                  {dataToShow?.venueLocation ?? ""}
                  {dataToShow?.venueDateAndTime &&
                    ` - ${new Date(dataToShow?.venueDateAndTime)?.getHours()}.${
                      new Date(dataToShow?.venueDateAndTime)?.getMinutes() <= 9
                        ? "0" +
                          new Date(dataToShow?.venueDateAndTime)?.getMinutes()
                        : new Date(dataToShow?.venueDateAndTime)?.getMinutes()
                    }
                 EST`}
                </div>
                <div className="text-[20px] font-[500] leading-[24px] sm:hidden">
                  {dataToShow?.venueDateAndTime &&
                    new Date(dataToShow?.venueDateAndTime)?.toDateString()}
                </div>
                <hr className="h-[1px] bg-black my-3" />
                <div className="editorContent break-words overflow-hidden">
                  {parse(previewData)}
                </div>
              </div>
              <div className="md:col-span-3 col-span-12 border-b-2 md:border-b-0 sm:pb-3 sm:mb-6  sm:block hidden pt-[102px]">
                <div className="flex flex-col justify-between  h-full">
                  {sidebarAds?.length > 0 &&
                    sidebarAds?.map((ad, i) => (
                      <div key={i} className="my-4">
                        <a
                          rel="noreferrer"
                          target="_blank"
                          href={`//${ad?.linkTo}`}
                          style={{ padding: "12px 0", display: "block" }}
                          className={`${ad?.name
                            .split(" ")
                            .join("")
                            .toUpperCase()} addFor-${ad?.adPosition} Ad_Link`}>
                          {ad?.type === "image" ? (
                            <img width="100%" src={ad?.url} alt="CHANGE_ME" />
                          ) : (
                            <video muted loop autoPlay width="100%">
                              <source src={ad?.url} type="video/mp4" />
                              Your browser does not support HTML video.
                            </video>
                          )}
                        </a>
                      </div>
                    ))}
                </div>
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  );
};

export default SinglePreview;

const getImageAndReplaceWithHtml = async (id) => {
  const data = await getAdImage(id);

  if (data?.data?.url) {
    if (data?.data?.type === "image") {
      return `<a style="padding: 12px 0;" class='block ${data?.data?.name
        .split(" ")
        .join("")
        .toUpperCase()} addFor-${
        data?.data?.adPosition
      } Ad_Link' href='//${data?.data?.linkTo.trim()}' target="_blank"><img src=${
        data?.data?.url
      } alt="CHANGE_ME" width="100%" /></a>`;
    }
    if (data?.data?.type === "video") {
      return `<a style="padding: 12px 0;" class='block ${data?.data?.name
        .split(" ")
        .join("")
        .toUpperCase()} addFor-${
        data?.data?.adPosition
      } Ad_Link' href='//${data?.data?.linkTo.trim()}' target="_blank">
      <video loop muted autoPlay playsinline src="${
        data?.data?.url
      }" width="100%">
  
  Your browser does not support HTML video.</video>
      </a>`;
    }
  }

  return "";
};

const replaceShortCodesWithAds = async (html) => {
  const tempArr = html?.split("~[SC~");
  const ids = [];
  tempArr?.forEach((f, i) => (i % 2 !== 0 ? ids.push(f.trim()) : f));

  if (ids?.length) {
    const updateHtml = await Promise.all(
      tempArr?.map(async (t) => {
        return ids?.includes(t.trim())
          ? await getImageAndReplaceWithHtml(t?.trim())
          : t?.replace(/\r?\n|\r/g, "");
      })
    );
    return updateHtml?.join("");
  }
  return html?.replace(/\r?\n|\r/g, "");
};

export async function getServerSideProps(context) {
  const { id } = context?.params;
  const data = await getSinglePreview(id);
  let previewData = "";

  if (data?.data) {
    // ads for small screens and main-content
    previewData = await replaceShortCodesWithAds(data?.data?.content);

    const paragraphs = previewData.match(/<p>(.*?)<\/p>/g);

    paragraphs?.forEach(function (p) {
      if (p.includes("youtube.com/watch?v=")) {
        const videoId = p.split("v=")[1].split("&")[0];
        const iframe = `<iframe src="https://www.youtube.com/embed/${videoId}" frameBorder="0" width="100%" height="315" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowFullscreen></iframe>`;
        previewData = previewData.replace(p, iframe);
      }
      if (p.includes("youtu.be/")) {
        const videoId = p.split("be/")[1].split(" ")[0];
        const iframe = `<iframe src="https://www.youtube.com/embed/${videoId}" frameBorder="0" width="100%" height="315" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowFullscreen></iframe>`;
        previewData = previewData.replace(p, iframe);
      }
    });
  }

  return {
    props: {
      data: data?.data || null,
      previewData: previewData?.replace(/&nbsp;/g, " ") || "",
    },
  };
}
