import React, { useState, useEffect } from "react";
import AdBanner from "../../components/single/home/AdBanner";
import { calls } from "../../Services/PromiseHandler/PromiseHandler";
import Hero from "../../components/pagesComponents/Previews/Hero/Hero";
import PreviewCard from "../../components/pagesComponents/Previews/Card/Card";
import { useSelector } from "react-redux";
import Skeleton from "react-loading-skeleton";
import Head from "next/head";

const Previews = () => {
  const [pastMatches, setPastMatches] = useState([]);
  const [upcomingMatches, setUpcomingMatches] = useState([]);
  const [currentMatch, setCurrentMatch] = useState([]);
  const [loading, setLoading] = useState(true);

  const fetchDate = async () => {
    const res = await calls("previews", "get", null);

    const dataSet = [...res?.data];

    const usaTime = new Date().toLocaleString("en-US", {
      timeZone: "America/New_York",
    });

    const sortedArray = dataSet.sort((a, b) => {
      return (
        new Date(a.venueDateAndTime).getTime() -
        new Date(b.venueDateAndTime).getTime()
      );
    });

    const pastMatches = sortedArray?.filter((x) => {
      return (
        new Date(x.venueDateAndTime).getTime() <= new Date(usaTime).getTime()
      );
    });

    setPastMatches(pastMatches);

    const upcomingMatches = sortedArray?.filter((x) => {
      return (
        new Date(x.venueDateAndTime).getTime() >= new Date(usaTime).getTime()
      );
    });

    if (
      new Date(upcomingMatches[0]?.venueDateAndTime).getTime() - 3600000 <=
      new Date(usaTime).getTime()
    ) {
      pastMatches.push(upcomingMatches[0]);
      upcomingMatches.shift(1, 1);
    } else {
      if (
        new Date(
          pastMatches[pastMatches.length - 1]?.venueDateAndTime
        ).getTime() +
          7200000 <=
        new Date(usaTime).getTime()
      ) {
        if (upcomingMatches.length <= 0) {
          pastMatches.push(upcomingMatches[0]);
        }

        upcomingMatches.shift(1, 1);
      }
    }

    setUpcomingMatches(upcomingMatches);

    let currentMatch = pastMatches[pastMatches?.length - 1];

    setCurrentMatch(currentMatch);

    pastMatches.pop();
  };

  useEffect(() => {
    setLoading(false);
    fetchDate();
  }, []);

  return (
    <>
      <Head>
        <title>Head to Head | SoccerBx </title>
      </Head>
      <div className="grid grid-cols-5">
        <div className="md:col-span-12 col-span-12">
          {loading ? (
            <div className="flex">
              <div className="border-r border-black sm:h-[500px] w-[50%] h-[200px]">
                <Skeleton height="100%" width="100%" />
              </div>
              <div className="sm:h-[500px] w-[50%] h-[200px]">
                <Skeleton height="100%" width="100%" />
              </div>
            </div>
          ) : (
            <Hero item={currentMatch} />
          )}
        </div>
      </div>
      <div className="grid grid-cols-12 gap-[15px] sm:px-3 xl:px-6 px-[16px] sm:mt-0 mt-2">
        {/* getting the first element and putting it on 5th index */}
        {upcomingMatches
          ?.filter((item) => item.isActive)
          ?.map((item) => (
            <div
              key={item?._id}
              className="my-[10px] sm:my-[30px] mx-auto sm:col-span-6  lg:col-span-3 col-span-12 w-full">
              <PreviewCard item={item} />
            </div>
          ))}
        {pastMatches
          ?.filter((item) => item.status === "published")
          ?.map((item) => (
            <div
              key={item?._id}
              className="my-[10px] sm:my-[30px] mx-auto sm:col-span-6  lg:col-span-3 col-span-12 w-full">
              <PreviewCard item={item} />
            </div>
          ))}
        {/* <div className="col-span-12">
          <AdBanner />
        </div> */}
        {/* {(featuredExist ? [...data?.slice(5), data?.[0]] : data?.slice(5))?.map((item) => (
          <div
            key={item?._id}
            className="my-[10px] sm:my-[30px] mx-auto sm:col-span-6  lg:col-span-3 col-span-12 w-full"
          >
            <PreviewCard item={item} />
          </div>
        ))} */}
      </div>
    </>
  );
};

export default Previews;
