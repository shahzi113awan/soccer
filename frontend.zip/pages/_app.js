import React, { useState } from "react";
import { Toaster } from "react-hot-toast";
import { Provider } from "react-redux";
import interceptor from "../Services/Interceptor/Interceptor";
import "../styles/globals.css";
import "../styles/style.css";
import "react-loading-skeleton/dist/skeleton.css";
import Layout from "./Layout";
import { store } from "../redux/store/store";
import RouteChangeLoader from "../components/commonComponents/RouteChangeLoader/RouteChangeLoader";
import { useRouter } from "next/router";
interceptor.setupInterceptors(store);

function MyApp({ Component, pageProps }) {
  // const isAuth =
  //   typeof window !== "undefined" && document.cookie.indexOf("isAuth") > 0;
  // const router = useRouter();

  // React.useEffect(() => {
  //   if (!isAuth) {
  //     router?.push("/login");
  //   }
  // }, [isAuth, router.asPath]);

  return (
    <Provider store={store}>
      <Layout>
        <RouteChangeLoader />
        <Component {...pageProps} />
        <Toaster
          toastOptions={{
            duration: 3000,
          }}
          duration="100"
          position="bottom-center"
        />
      </Layout>
    </Provider>
  );
}

export default MyApp;
