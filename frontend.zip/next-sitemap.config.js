const siteUrl = "https://soccerbx.com";

module.exports = {
  siteUrl,
  generateRobotsTxt: true,
  exclude: ["/404"],
};
