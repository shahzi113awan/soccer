import Link from "next/link";
import React from "react";
import Image from "next/image";

const SoccerBet = ({ fanduelHeading, fanduelLink, fanduelImage }) => {
  return (
    <div
      style={{
        borderTopWidth: "8px",
        borderBottomWidth: "8px",
      }}
      className="my-7 bg-black linear-border border-t p-6 pr-7">
      <div className="flex items-center md:flex-row gap-6 md:gap-1 flex-col w-full justify-between">
        <div className="">
          <div className="flex justify-center md:justify-start ">
            <img
              className="mx-auto md:mx-0 w-24 md:w-28 lg:w-36 h-24 md:h-28 lg:h-36"
              src="/images/soccer-bet-logo.svg"
              alt=""
            />
          </div>

          <div>
            <h1 className="mt-8 max-w-[539px] font-bold text-lg md:text-2xl lg:3xl text-white flex justify-center ">
              {fanduelHeading}
              {/* Visit Fanduel for the latest promotional offer and start{" "}
            <div>placing your bets</div> */}
            </h1>
          </div>
          <div className="flex justify-center md:block">
            <button className="px-4 py-3 text-xs xl:text-sm font-normal uppercase text-[#01A4FF] flex items-center justify-center bg-white  cursor-pointer mt-3 md:mt-20">
              <Link href={fanduelLink}>
                <a className="text-black pr-5">Join Us</a>
              </Link>
              <img
                src="/images/arrow-right.svg"
                alt="arrow right"
                height="100%"
                width={12}

              />
            </button>
          </div>
        </div>
        {/* bg-[#0F52BA] */}

        <div className="h-[205px] w-[300px] md:h-[260px] md:w-[400px] lg:h-[300px] lg:w-[477px] relative ">
          <Image
            src={fanduelImage}
            layout="fill"
            objectFit="cover"
            objectPosition="center"
            alt="CHANGE_ME"
          />

          {/* <img
            className="sm:w-[477px] sm:h-[309px]"
            // src="/images/Fandual-logo.png"
            src={fanduelImage}
            alt=""
          /> */}
        </div>
      </div>
    </div>
  );
};

export default SoccerBet;
