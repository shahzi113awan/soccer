import React, { useState, useEffect } from "react";
import Skeleton from "react-loading-skeleton";
import "react-loading-skeleton/dist/skeleton.css";
import { getSingleSoccerPodData } from "../../../../Services/News/news.service";
import parse from "html-react-parser";
import { AiOutlineArrowRight } from "react-icons/ai";

const closeBtnStyle = {
  position: "absolute",
  right: "10px",
  zIndex: 1,
  top: "10px",
};

export default function SoccerPodPopup({ handleClosePopup, showPopup, slug }) {
  const [nextArticle, setNextArticle] = useState({});
  const [title, setTitle] = useState();
  const [videoID, setVideoID] = useState();
  const [content, setContent] = useState();
  const [tempSlug, setTempSlug] = useState(slug);
  const [currentSlug, setCurrentSlug] = useState(slug);

  const fetchSoccerPodData = async () => {
    // console.log(currentSlug,slug)
    const data = await getSingleSoccerPodData(currentSlug);
    const soccerPodData = data?.data;
    setTitle(soccerPodData?.title);
    setTempSlug(soccerPodData?.nextPod?.slug);
    setVideoID(
      soccerPodData?.mediaLink?.split("&")[0]?.replace("watch?v=", "embed/")
    );

    setContent(soccerPodData?.content);
  };
  useEffect(() => {
    fetchSoccerPodData();
  }, [currentSlug, slug]);
  useEffect(() => {
    setTempSlug(slug);
    setCurrentSlug(slug);
  }, [slug]);

  // const handleNextNews = (article) => {
  //   alert(1);
  //   const { _id: id } = article?.next;

  //   getNextArticle(id);
  // };
  // const getNextArticle = async (id) => {
  //   const res = await getSingleSoccerPodData(id);
  //   setNextArticle(res?.data);
  // };
  const handelNextPod = () => {
    if (!tempSlug) setCurrentSlug(null);
    else {
      setCurrentSlug(tempSlug);
    }
  };
  return (
    <>
      {showPopup ? (
        <>
          <div
            className="justify-center items-center flex overflow-x-hidden overflow-y-auto fixed inset-0 z-50 outline-none focus:outline-none"
            style={{ background: "rgba(0, 0, 0, 0.9)" }}>
            <button
              type="button"
              style={closeBtnStyle}
              onClick={handleClosePopup}>
              <span className="text-white text-3xl ">x</span>
            </button>
            <div className=" relative mx-auto sm:w-none md:w-[80vw] ">
              <div className="bg-black shadow-lg relative flex flex-col w-full outline-none focus:outline-none">
                <div className="soccerpod-background pt-2 pb-1">
                  <div className="bg-black grid sm:h-[90vh] md:h-[70vh] grid-cols-12 gap-4 ">
                    <div className="bg-black col-span-12 md:col-span-12 lg:col-span-8">
                      <picture>
                        <iframe
                          width="100%"
                          height="100%"
                          src={
                            videoID ||
                            "https://www.youtube.com/embed/0Z9VW4Y8X1I"
                          }
                          title="YouTube video player"
                          frameBorder="0"
                          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                          allowFullScreen
                        />
                      </picture>
                    </div>

                    <div className="col-span-12 md:col-span-12 lg:col-span-4 sm:p-1 md:p-4 mx-2 flex flex-col justify-between">
                      <div className="">
                        <svg
                          width="130"
                          height="40"
                          viewBox="0 0 1116 108"
                          fill="none"
                          xmlns="http://www.w3.org/2000/svg">
                          <path
                            d="M53.8192 107.59C81.5293 107.59 99.3639 94.3243 99.3639 72.6574V72.3626C99.3639 51.5801 81.6767 43.9156 55.2931 39.0516C44.386 36.9881 41.5855 35.2194 41.5855 32.4189V32.1241C41.5855 29.6184 43.9438 27.8497 49.1026 27.8497C58.6832 27.8497 70.3273 30.9449 80.0553 38.0198L96.8582 14.7316C84.9193 5.29838 70.1799 0.581771 50.2817 0.581771C21.8347 0.581771 6.50575 15.7634 6.50575 35.3667V35.6615C6.50575 57.4758 26.8461 64.1086 49.987 68.8252C61.0415 71.0361 64.2842 72.6574 64.2842 75.6053V75.9001C64.2842 78.7006 61.6311 80.3219 55.4405 80.3219C43.3542 80.3219 30.531 76.7844 19.329 68.2356L0.904785 90.1973C14.0228 101.694 32.8893 107.59 53.8192 107.59Z"
                            fill="white"
                          />
                          <path
                            d="M161.131 107.885C192.968 107.885 217.583 84.0067 217.583 54.0858V53.791C217.583 23.87 193.263 0.286987 161.426 0.286987C129.589 0.286987 104.974 24.1648 104.974 54.0858V54.3806C104.974 84.3015 129.294 107.885 161.131 107.885ZM161.426 77.374C148.161 77.374 139.759 66.3195 139.759 54.0858V53.791C139.759 41.7047 148.013 30.7975 161.131 30.7975C174.397 30.7975 182.798 41.8521 182.798 54.0858V54.3806C182.798 66.4669 174.544 77.374 161.426 77.374Z"
                            fill="white"
                          />
                          <path
                            d="M278.092 107.885C303.738 107.885 318.183 95.3561 326.879 80.0271L298.432 63.9612C294.158 71.6257 288.704 76.9318 278.976 76.9318C267.627 76.9318 259.667 67.4986 259.667 54.0858V53.791C259.667 41.4099 267.332 31.2397 278.976 31.2397C288.409 31.2397 293.863 36.3985 297.695 43.7682L326.142 27.1127C317.446 11.3415 302.117 0.286987 279.418 0.286987C248.613 0.286987 224.588 23.2804 224.588 54.0858V54.3806C224.588 86.365 249.497 107.885 278.092 107.885Z"
                            fill="white"
                          />
                          <path
                            d="M381.728 107.885C407.375 107.885 421.819 95.3561 430.515 80.0271L402.068 63.9612C397.794 71.6257 392.34 76.9318 382.612 76.9318C371.263 76.9318 363.304 67.4986 363.304 54.0858V53.791C363.304 41.4099 370.968 31.2397 382.612 31.2397C392.046 31.2397 397.499 36.3985 401.331 43.7682L429.778 27.1127C421.082 11.3415 405.753 0.286987 383.055 0.286987C352.249 0.286987 328.224 23.2804 328.224 54.0858V54.3806C328.224 86.365 353.134 107.885 381.728 107.885Z"
                            fill="white"
                          />
                          <path
                            d="M437.097 105.674H525.829V77.374H470.998V66.1721H521.407V41.2625H470.998V30.7975H525.092V2.49789H437.097V105.674Z"
                            fill="white"
                          />
                          <path
                            d="M535.12 105.674H569.61V76.1949H576.98L596.436 105.674H635.79L611.765 70.5939C624.294 64.5507 632.105 54.0858 632.105 39.0516V38.7568C632.105 28.1444 628.863 20.48 622.672 14.2894C615.45 7.06711 603.806 2.49789 585.529 2.49789H535.12V105.674ZM569.61 51.5801V31.3871H584.645C592.604 31.3871 597.763 34.6298 597.763 41.2625V41.5573C597.763 47.8952 592.751 51.5801 584.497 51.5801H569.61Z"
                            fill="white"
                          />
                          <path
                            d="M640.484 105.674H697.673C723.761 105.674 737.322 93.5873 737.322 77.0792V76.7844C737.322 62.6346 728.773 55.5597 715.507 51.7275C726.562 47.8952 733.932 40.3781 733.932 28.1444V27.8497C733.932 20.7747 731.278 15.4686 727.594 11.7837C721.55 5.74056 712.559 2.49789 698.262 2.49789H640.484V105.674ZM674.09 43.0312V28.5866H688.976C696.346 28.5866 700.031 31.0923 700.031 35.6615V35.9563C700.031 40.5255 696.494 43.0312 689.124 43.0312H674.09ZM674.09 79.5849V64.256H691.482C698.999 64.256 702.684 67.3512 702.684 71.773V72.0678C702.684 76.4897 698.852 79.5849 691.335 79.5849H674.09Z"
                            fill="white"
                          />
                          <path
                            d="M744.84 105.674H833.571V77.374H778.74V66.1721H829.149V41.2625H778.74V30.7975H832.834V2.49789H744.84V105.674Z"
                            fill="white"
                          />
                          <path
                            d="M869.246 105.674H903.736V31.6819H934.099V2.49789H838.883V31.6819H869.246V105.674Z"
                            fill="white"
                          />
                          <path
                            d="M958.729 105.674H993.219V2.49789H958.729V105.674Z"
                            fill="white"
                          />
                          <path
                            d="M1059.16 107.885C1090.99 107.885 1115.61 84.0067 1115.61 54.0858V53.791C1115.61 23.87 1091.29 0.286987 1059.45 0.286987C1027.62 0.286987 1003 24.1648 1003 54.0858V54.3806C1003 84.3015 1027.32 107.885 1059.16 107.885ZM1059.45 77.374C1046.19 77.374 1037.79 66.3195 1037.79 54.0858V53.791C1037.79 41.7047 1046.04 30.7975 1059.16 30.7975C1072.42 30.7975 1080.82 41.8521 1080.82 54.0858V54.3806C1080.82 66.4669 1072.57 77.374 1059.45 77.374Z"
                            fill="white"
                          />
                          <circle
                            cx="932.749"
                            cy="86.5123"
                            r="19.1612"
                            fill="white"
                          />
                        </svg>
                        <h1 className="text-white uppercase">{title ?? ""}</h1>
                        <h1 className="text-white font-light text-sm mt-2">
                          {parse(content ?? "")}
                        </h1>
                      </div>
                      {tempSlug && (
                        <div className="text-right text-white mt-5">
                          <button
                            className="inline-flex text-sm cursor-pointer"
                            title={nextArticle?.nextPod?.title ?? ""}
                            onClick={() => handelNextPod()}>
                            Play next Podcast
                            <span className="ml-3 mt-1 mb-5">
                              <AiOutlineArrowRight />
                            </span>
                          </button>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
                {tempSlug && (
                  <button
                    type="button"
                    style={closeBtnStyle}
                    onClick={handelNextPod}>
                    <span className="text-white text-3xl ">Next</span>
                  </button>
                )}
              </div>
            </div>
          </div>
          <div className="opacity-25 fixed inset-0 z-40 bg-black"></div>
        </>
      ) : null}
    </>
  );
}
