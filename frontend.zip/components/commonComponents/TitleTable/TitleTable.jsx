import React from "react";

const TitleTable = ({
  title,
  // pb = 2,
  // pt = 2,
  // pl = 2,
  // pr = 2,
  // gap = 2,
  fontSizes = "md:text-7xl text-4xl",
}) => {
  const rowOneText = title?.split(" ")?.[0]?.split("");
  const rowTwoText = title?.split(" ")?.[1];
  const rowThreeText = title?.split(" ")?.[2]?.split("");
  return title?.length ? (
    <div
      className="flex flex-col w-full h-full bg-white gap-1 p-1"
      // style={{
      //   gap: `${gap}px`,
      //   paddingBottom: `${pb}px`,
      //   paddingTop: `${pt}px`,
      //   paddingLeft: `${pl}px`,
      //   paddingRight: `${pr}px`,
      // }}
    >
      <div
        // style={{ gap: `${gap}px` }}
        className="leading-[22px] grid grid-cols-3 flex-1 gap-1">
        {rowOneText?.map((r1, i) => (
          <div
            key={r1 + i}
            className={`text-white flex items-center bg-black justify-center ${fontSizes} font-extrabold`}>
            {r1?.toUpperCase()}
          </div>
        ))}
      </div>
      <div
        // style={{ gap: `${gap}px` }}
        className="leading-[22px] grid grid-cols-3 flex-1 gap-1">
        <div
          className={`text-white flex items-center bg-black justify-center ${fontSizes} font-extrabold`}></div>
        <div
          className={`text-white flex items-center bg-black justify-center ${fontSizes} font-extrabold`}>
          {rowTwoText?.toUpperCase()}
        </div>
        <div
          className={`text-white flex items-center bg-black justify-center ${fontSizes} font-extrabold`}></div>
      </div>
      <div
        // style={{ gap: `${gap}px` }}
        className="leading-[22px] grid grid-cols-3 flex-1 gap-1">
        {rowThreeText?.map((r2, i) => (
          <div
            key={`__rowThreeText${i}`}
            className={`text-white flex items-center bg-black justify-center ${fontSizes} font-extrabold`}>
            {r2?.toUpperCase()}
          </div>
        ))}
      </div>
    </div>
  ) : (
    <></>
  );
};

export default TitleTable;
