import React from "react";
import TitleTable from "../commonComponents/TitleTable/TitleTable";
export default function PreviewsVTeams({
  teamOne,
  teamTwo,
  className,
  innerClassName,
  midTitle,
  title,
}) {
  let team = [...teamOne, "", "V", "", ...teamTwo];
  return (
    <div className={"bg-black " + className}>
      <TitleTable
        fontSizes="text-[58px] leading-[22px] lg:text-[52px]"
        gap={3}
        pl={0}
        pt={0}
        pr={0}
        title={title}
      />
      {/* <div className="flex">
        {team.slice(0, 3).map((t, i) => (
          <div
            className={
              "text-white border border-white flex justify-center items-center font-medium " +
              innerClassName
            }
            key={i}
          >
            {t?.toUpperCase()}
          </div>
        ))}
      </div>
      <div className="flex">
        <div
          className={
            "text-white border border-white flex justify-center items-center font-medium " +
            innerClassName
          }
        ></div>
        <div
          className={
            "text-white border border-white flex justify-center items-center font-medium " +
            innerClassName
          }
        >
          {midTitle?.toUpperCase()}
        </div>
        <div
          className={
            "text-white border border-white flex justify-center items-center font-medium " +
            innerClassName
          }
        ></div>
      </div>
      <div className="flex">
        {team.slice(6, 9).map((t, i) => (
          <div
            className={
              "text-white border border-white flex justify-center items-center font-medium " +
              innerClassName
            }
            key={100 * i}
          >
            {t?.toUpperCase()}
          </div>
        ))}
      </div> */}
    </div>
  );
}

PreviewsVTeams.defaultProps = {
  teamOne: "LIV",
  teamTwo: "MUN",
  className: "w-[128px] xl:w-[155px]",
  innerClassName:
    "h-[42px] w-[42px] xl:w-[52px] xl:h-[52px] text-[46px] xl:text-[56px]",
};
