import React from "react";
import { MdOutlineChatBubble } from "react-icons/md";
import PropTypes from "prop-types";
import Link from "next/link";
import Image from "next/image";

export default function FeaturedArticle({
  title = "",
  innerClassName = "",
  className = "",
  content = "",
  headingClass = "",
  heading = "",
  author = "",
  image = "",
  imageClass = "",
  slug = "",
  isCard = true,
  smCard = false,
  leagueTag,
  leagueId,
}) {
  return (
    <React.Fragment>
      <div className={`${className} cursor-pointer `}>
        <h3 className="text-[20px]">{title}</h3>
        <Link href={slug}>
          <div>
            <div className={innerClassName}>
              <div className="mt-4 min-w-[50%]">
                <img
                  src={image}
                  alt={title}
                  className={`relative min-h-[300px] ${
                    !Boolean(image) && "no-image_img"
                  } ${
                    isCard ? "sm:max-h-[330px]" : ""
                  } w-full h-full object-cover ${
                    !smCard ? "max-h-[330px]" : "max-h-[115px]"
                  } ${imageClass}
                    `}
                />
              </div>

              {/* <div className="mt-4">
                <div
                  className={`relative w-[300px] h-[250px] sm:w-[393px] sm:h-[300px] md:w-[184px] md:h-[300px] lg:w-[279px] lg:h-[300px] xl:w-[383px] xl:h-[300px]  ${
                    !Boolean(image) && "no-image_img"
                  } ${
                    isCard ? "sm:max-h-[330px]" : ""
                  } w-full h-full object-cover ${
                    !smCard ? "max-h-[330px]" : "max-h-[115px]"
                  } ${imageClass}
                    `}>
                  <Image
                    src={image}
                    layout="fill"
                    objectFit="cover"
                    objectPosition="center"
                    alt={title}
                  />
                </div>
              </div> */}

              <div className="min-w-[50%] mt-2">
                {leagueTag && (
                  // <Link href={`/${leagueTag ?? ""}`}>
                  <Link href={`/news#${leagueId}`}>
                    <a className="text-xs font-medium mr-1 cursor-pointer ">
                      <span className="bg-zinc-300 p-1 rounded-sm uppercase">
                        {leagueTag}
                      </span>
                    </a>
                  </Link>
                )}
                <h1
                  className={
                    "uppercase mt-2 text-[22px] sm:text-[32px] leading-[30px]   pb-3 " +
                    headingClass
                  }>
                  {heading}
                </h1>

                <h3 className="text-[16px] font-light leading-[24px] h-[24px] overflow-hidden">
                  {content}
                </h3>

                <div className="flex items-center gap-3 mt-3">
                  {/* <p className="text-[12px]">{author}</p> */}
                  <p className="text-[12px]">Soccerbx Team</p>

                  {/* <MdOutlineChatBubble />
                  <span className="text-[12px]">123</span> */}
                </div>
              </div>
            </div>
          </div>
        </Link>
      </div>
    </React.Fragment>
  );
}

FeaturedArticle.propTypes = {
  title: PropTypes.string,
  innerClassName: PropTypes.string,
  className: PropTypes.string,
  headingClass: PropTypes.string,
  heading: PropTypes.string,
  author: PropTypes.string,
  image: PropTypes.string,
};
