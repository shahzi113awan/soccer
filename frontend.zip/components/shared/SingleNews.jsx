import React from "react";
import { MdOutlineChatBubble } from "react-icons/md";
import { PropTypes } from "prop-types";
import Link from "next/link";
import Image from "next/image";

export default function SingleNews({
  className,
  type,
  heading,
  author,
  image,
  slug = "",
  isFirstSec = true,
  idx,
  lastIdx = -1,
  leagueTag,
  leagueId,
}) {
  return (
    <Link href={slug}>
      <div
        className={`flex cursor-pointer ${isFirstSec ? "my-2" : ""} ${
          idx === 0 ? "sm:mt-0" : ""
        }`}>
        <div
          className={`flex flex-col w-full md:flex-row gap-2 md:gap-4 sm:items-start items-center ${
            idx !== 0 && "md:pt-[16px]"
          } sm:p-0 ${isFirstSec ? "sm:border-l-0 border-l" : ""} ${className}`}>
          <div
            className={
              type === "news"
                ? `relative w-[164px] h-[164px] md:w-[8vw] md:h-[8vw] lg:w-[86px] lg:h-[86px] object-cover ${
                    !Boolean(image) && "no-image_img"
                  }`
                : `relative w-[164px] h-[115px] md:w-[12vw] md:h-[12vw] lg:w-[188px] lg:h-[132px] object-cover ${
                    !Boolean(image) && "no-image_img"
                  }`
            }>
            <Image
              src={image}
              layout="fill"
              objectFit="cover"
              objectPosition="center"
              alt="news image"
            />
            {/* <img
              src={image}
              alt=""
              className={
                type === "news"
                  ? `relative w-[164px] h-[164px] md:w-[8vw] md:h-[8vw] lg:w-[86px] lg:h-[86px] object-cover ${
                      !Boolean(image) && "no-image_img"
                    }`
                  : `relative w-[164px] h-[115px] md:w-[12vw] md:h-[12vw] lg:w-[188px] lg:h-[132px] object-cover ${
                      !Boolean(image) && "no-image_img"
                    }`
              }
            /> */}
          </div>
          {/* <div className="flex flex-row items-center justify-between">
            <h4 className="mr-4 mb-3 text-lg font-extrabold uppercase leading-6 sm:leading-7">
              {title}
            </h4>
            <p className="text-xs font-medium  bg-zinc-300 p-1 mr-1">
             
            </p>
          </div> */}
          <div className="flex-1 mr-auto">
            {leagueTag && (
              <Link href={`/news#${leagueId}`}>
                <h3 className="text-xs font-medium cursor-pointer mb-1">
                  <span className="bg-zinc-300 p-1 rounded-sm uppercase">
                    {leagueTag}
                  </span>
                </h3>
              </Link>
            )}
            <h1 className="uppercase text-[18px] pb-2 leading-[22px]">
              {heading}
            </h1>
            <div className="flex items-center gap-1">
              {/* <p className="text-[12px]">{author}</p> */}
              <p className="text-[12px]">Soccerbx Team</p>

              {/* <MdOutlineChatBubble /> */}
              {/* <span className="text-[12px]">123</span> */}
            </div>
          </div>
        </div>
      </div>
    </Link>
  );
}

SingleNews.defaultProps = {
  type: "module",
};

SingleNews.propTypes = {
  className: PropTypes.string,
  type: PropTypes.string,
  heading: PropTypes.string,
  author: PropTypes.string,
  image: PropTypes.string,
};
