import React from "react";
import Link from "next/link";

import PreviewsVTeams from "./PreviewsVTeams";
import { MdOutlineChatBubble } from "react-icons/md";
import TitleTable from "../commonComponents/TitleTable/TitleTable";

export default function PreviewsSingleArticle({
  teamOne,
  teamTwo,
  midTitle,
  image,
  author,
  title,
  slug,
  tempTitle,
}) {
  return (
    <Link href={`/${slug}`}>
      <a className="flex items-start gap-4 border-b py-3 ">
        <div className="flex items-start  ">
          <div className="w-[82px] h-[82px] md:w-[98px] md:h-[98px]">
            <TitleTable
              fontSizes="text-[22px] leading-[22px] lg:text-[26px]"
              gap={1}
              pt={0}
              pb={0}
              pr={0}
              pl={0}
              title={tempTitle}
            />
          </div>
          <div className="ml-[1px] w-[82px] h-[82px] md:w-[98px] md:h-[98px] flex">
            <img
              src={image}
              alt={title ?? ""}
              className={`relative object-cover w-full max-[96px] ${
                !Boolean(image) && "no-image_img"
              }`}
            />
          </div>
        </div>
        <div>
          <h1
            style={{ lineHeight: "22px" }}
            className={"uppercase sm:text-lg text-base"}>
            {title}
          </h1>
          <div className="flex items-center gap-1 mt-1">
            {/* <p className="text-[12px]">{author}</p> */}
            <p className="text-[12px]">Soccerbx Team</p>

            {/* <MdOutlineChatBubble />
            <span className="text-[12px]">123</span> */}
          </div>
        </div>
      </a>
    </Link>
  );
}
