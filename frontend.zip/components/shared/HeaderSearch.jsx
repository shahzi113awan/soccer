import React, { useEffect, useRef, useState } from "react";
import { IconContext } from "react-icons";
import { AiOutlineSearch } from "react-icons/ai";
import PropTypes from "prop-types";

export default function HeaderSearch({ screen }) {
  const [searchActive, setSearchActive] = useState(false);
  const searchInputRef = useRef(null);
  const handleOpenSearch = () => {
    setSearchActive(!searchActive);
  };

  useEffect(() => {
    if (searchActive) {
      searchInputRef?.current?.focus();
    }
  }, [searchActive]);

  // if (screen === "mobile") {
  //   return (
  //     <div className="sm:px-6 mx-4 sm:mx-0 mb-4 relative">
  //       <input
  //         ref={searchInputRef}
  //         type="search"
  //         className="border-b-2 px-4 py-1 bg-transparent w-full text-white focus:outline-none focus:border-b-2 focus:border-[#01A4FF] text-lg "
  //       />
  //       <div className="absolute left-0 top-0">
  //         <IconContext.Provider value={{ className: "fill-white" }}>
  //           {" "}
  //           <AiOutlineSearch />
  //         </IconContext.Provider>
  //       </div>
  //     </div>
  //   );
  // }

  return (
    <div className="hidden md:block">
      <button onClick={handleOpenSearch} className="bg-transparent border-none">
        <IconContext.Provider value={{ className: "fill-white w-6 h-6" }}>
          {" "}
          <AiOutlineSearch />
        </IconContext.Provider>
      </button>
      {searchActive && (
        <input
          autoFocus
          type="search"
          placeholder="Search"
          className="border-b-2 px-3 py-1 w-96 bg-transparent text-white focus:outline-none focus:border-b-2 focus:border-[#01A4FF]"
        />
      )}
    </div>
  );
}
HeaderSearch.defaultProps = {
  screen: "mobile",
};

HeaderSearch.propTypes = {
  screen: PropTypes.string,
};
