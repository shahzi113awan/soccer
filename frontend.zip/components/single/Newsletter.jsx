import React from 'react'
import { IconContext } from 'react-icons/lib'
import { MdSend } from "react-icons/md"
import NewsletterLogic from './NewsletterLogic'

export default function Newsletter() {
  const { newsletterSubmit, error, success, email, handleChange } = NewsletterLogic()
  
  return (
    <div>
      <form className='flex' onSubmit={newsletterSubmit}>
        <input type="email" name="newsletter" required id="newsletter" value={email} onChange={handleChange} className='bg-transparent py-1 px-2 border-b text-white focus:outline-none focus:border-blue-500 text-sm' placeholder='Newsletter Subscription' />
        <button className='bg-blue-600 px-2 hover:bg-blue-500'>
          <IconContext.Provider value={{ className: "invert" }}>
            <MdSend />
          </IconContext.Provider>
        </button>
      </form>
      {error && <p className='text-red-500 text-sm max-w-[200px]'>{error}</p>}
      {success && <p className='text-sm text-green-500 max-w-[200px]'>{success}</p>}
    </div>
  )
}
