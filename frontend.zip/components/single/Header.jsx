import Link from "next/link";
import React, { useState, useEffect, useRef } from "react";
import HamburgerButton from "../base/HamburgerButton";
import HeaderSearch from "../shared/HeaderSearch";
import { BsInstagram, BsTwitter } from "react-icons/bs";
import { FaDiscord, FaTiktok } from "react-icons/fa";
import SubscribePopup from "../commonComponents/Popups/Subscribe/SubscribePopup";
import { useRouter } from "next/router";
import { calls } from "../../Services/PromiseHandler/PromiseHandler";
// import { getLeagues } from "../../Services/leagues/leagues.services";
// import Image from "next/image";

const firstMenuItems = [
  {
    name: "Home",
    link: "",
    id: 2,
    routes: [""],
  },
  {
    name: "News",
    link: "news",
    id: 2,
    routes: ["news"],
  },
  // {
  //   name: "Head to Head",
  //   link: "head-to-head",
  //   id: 3,
  //   routes: ["head-to-head"],
  // },
  // {
  //   name: "Soccerpod",
  //   link: "soccerpod",
  //   id: 3,
  //   // routes: ["soccerpod"],
  // },
];
const menuItems = [
  {
    name: "Team USA",
    link: "team-usa",
    id: 4,
    routes: ["team-usa"],
  },
  {
    name: "Soccerbet Academy",
    link: "soccerbet-academy",
    id: 6,
    routes: ["soccerbet-academy"],
  },
  {
    name: "About Us",
    routes: ["about"],
    link: "about",
    id: 1,
  },
  // {
  //   name: "Soccerbet",
  //   link: "soccerbet",
  //   id: 5,
  //   routes: ["soccerbet", "soccerbet-academy"],
  //   children: [
  //     {
  //       name: "Soccerbet Academy",
  //       link: "soccerbet-academy",
  //       id: 6,
  //       routes: ["soccerbet-academy"],
  //     },
  //   ],
  // },

  // {
  //   name: "Gaming",
  //   link: "gaming",
  //   id: 5,
  // },

  // {
  //   name: "Betting",
  //   link: "betting",
  //   id: 6,
  // },
  // {
  //   name: "Podcast",
  //   link: "podcast",
  //   id: 7,
  // },
];
export default function Header({ data }) {
  const [active, setActive] = useState(false);
  const [showSubscribePopup, setShowSubscribePopup] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const [logoPadding, setLogoPadding] = useState(0);
  const [parentLeagues, setParentLeagues] = useState([]);
  const mbMenu = useRef(null);

  useEffect(() => {
    if (typeof window !== "undefined") {
      window.addEventListener("scroll", checkScroll, false);
      return () => {
        window.removeEventListener("scroll", checkScroll);
      };
    }
  }, []);
  useEffect(() => {
    const fetchData = async () => {
      const res = await calls("league", "get");
      const allLeagues = res.data;
      setParentLeagues(allLeagues ?? []);
    };
    fetchData();
  }, []);

  function checkScroll() {
    if (window?.scrollY === 0) {
      setIsScrolled(false);
    }
    const padding = Math.round(window?.scrollY);

    setLogoPadding(padding);
    if (window.scrollY > 50 && window.scrollY >= 100) {
      setIsScrolled(window.scrollY > 50 && window.scrollY >= 100);
    }
  }

  const router = useRouter();
  return (
    <header className="sticky top-0 z-50" id="header">
      <div className={"px-4 bg-black linear-border pb-5 md:pb-0 "}>
        <div className={"flex justify-between"}>
          <div
            className={
              "w-[3.75rem] pt-7 " + (isScrolled ? "flex items-center" : "")
            }>
            <HamburgerButton active={active} setActive={setActive} />
            {/* <HeaderSearch screen="desktop" /> */}
          </div>

          <strong className="inline-block overflow-hidden min-h-[50px]">
            <Link href="/">
              <a className="inline-block">
                {router?.pathname === "/" ? (
                  <>
                    {/* <div
                      className={`relative logo max-w-[185px] w-[calc(100%_-_1rem)] mx-auto max-h-[45px] md:w-full md:mx-0 ${
                        isScrolled ? "showLandscapeLogo" : "hideLandscapeLogo"
                      }`}>
                      <Image
                        src="/logo/soccerbx-logo-logo-landscape.svg"
                        alt="SoccerBX"
                        // layout="fixed"
                        width="100%"
                        height="100%"
                        objectFit="cover"
                        objectPosition="center"
                      />
                    </div> */}
                    <img
                      width="100%"
                      height="100%"
                      className={`logo max-w-[185px]  w-[calc(100%_-_1rem)] mx-auto max-h-[45px] md:w-full md:mx-0 ${
                        isScrolled ? "showLandscapeLogo" : "hideLandscapeLogo"
                      }`}
                      src="/logo/soccerbx-logo-logo-landscape.svg"
                      alt="SoccerBX"
                    />

                    {/* <div
                      className={`logo relative ${
                        !isScrolled ? "showSquareLogo" : "hideSquareLogo"
                      } max-h-[103px] `}>
                      <Image
                        src="/logo/soccerbx-logo-square.svg"
                        alt="SoccerBX"
                        // layout="fill"
                        objectFit="cover"
                        objectPosition="center"
                        width="100%"
                        height="100%"
                      />
                    </div> */}
                    <img
                      width="100%"
                      height="100%"
                      className={`logo ${
                        !isScrolled ? "showSquareLogo" : "hideSquareLogo"
                      } max-h-[103px]`}
                      src="/logo/soccerbx-logo-square.svg"
                      alt="SoccerBX"
                    />
                  </>
                ) : (
                  // <div className="relative mt-[32px] logo max-w-[185px]  w-[calc(100%_-_1rem)] mx-auto max-h-[45px] md:w-full md:mx-0 ">
                  //   <Image
                  //     src="/logo/soccerbx-logo-logo-landscape.svg"
                  //     alt="SoccerBX"
                  //     // layout="fill"
                  //     objectFit="cover"
                  //     objectPosition="center"
                  //     width="100%"
                  //     height="100%"
                  //   />
                  // </div>
                  <div>
                    <img
                      className="mt-[32px] logo max-w-[185px]  w-[calc(100%_-_1rem)] mx-auto max-h-[45px] md:w-full md:mx-0 "
                      src="/logo/soccerbx-logo-logo-landscape.svg"
                      alt="SoccerBX"
                      width="100%"
                      height="100%"
                    />
                  </div>
                )}
              </a>
            </Link>
          </strong>

          <SubscribePopup
            showCloseBtn={false}
            handleClosePopup={() => setShowSubscribePopup(false)}
            showPopup={showSubscribePopup}
          />
          <div
            onClick={() => setShowSubscribePopup(true)}
            className="pt-6 text-xs h-min font-normal uppercase text-[#01A4FF] xl:text-sm cursor-pointer">
            Join Us
          </div>
        </div>

        <div className="hidden md:flex md:justify-between mt-1 lg:ml-12 sm:flex-wrap mb-[-1px]">
          <ul className="flex md:justify-center lg:justify-start items-center">
            {firstMenuItems?.map((item, i) => (
              <li
                tabIndex={-1}
                className="hover:bg-[#1D71B3] cursor-pointer relative menu-item "
                key={`__firstmenuItems${i}`}>
                <Link href={`/${item?.link}`} shallow={true}>
                  <a
                    className={
                      "py-[7px] px-[10px] inline-block text-white ailgn-middle font-normal text-sm 2xl:text-base " +
                      (item?.routes?.includes(
                        router?.pathname?.split("/")?.[1]
                      ) ||
                      (item.name === "Home" && router.pathname === "/")
                        ? "bg-soccer-red hover:bg-[#1D71B3]"
                        : "hover:bg-[#1D71B3]")
                    }>
                    {item?.name}
                  </a>
                </Link>
                {/* submenu */}
                {/* {item?.children?.length > 0 &&
                  item?.children?.map((child) => (
                    <div
                      className="whitespace-nowrap bg-transparent pt-[1px] cursor-pointer menu-sub-item absolute"
                      key={child?.id}>
                      <Link href={`/${child?.link}`} shallow={true}>
                        <a
                          className={
                            "py-[7px] px-[10px] inline-block text-white ailgn-middle font-normal text-sm 2xl:text-base " +
                            (child?.routes?.includes(
                              router?.pathname?.split("/")?.[1]
                            )
                              ? "bg-soccer-red hover:bg-[#1D71B3]"
                              : "hover:bg-[#1D71B3]") +
                            (router?.pathname === "/soccerbet-academy" &&
                              " bg-soccer-red-must")
                          }>
                          {child.name}
                        </a>
                      </Link>
                    </div>
                  ))} */}
              </li>
            ))}
            {parentLeagues
              ?.filter((item) => item.status === "published")
              ?.map((item, i) => (
                <li
                  tabIndex={-1}
                  className="hover:bg-[#1D71B3] cursor-pointer relative menu-item capitalize"
                  key={`parentLeagues${i}`}>
                  <Link href={`/${item?.slug}`} shallow={true}>
                    <a
                      className={
                        "py-[7px] px-[10px] inline-block text-white ailgn-middle font-normal text-sm 2xl:text-base " +
                        (item?.slug == router?.query.slug
                          ? "bg-soccer-red hover:bg-[#1D71B3]"
                          : "hover:bg-[#1D71B3]")
                      }>
                      {item?.title}
                    </a>
                  </Link>
                </li>
              ))}
            {menuItems?.map((item, i) => (
              <li
                tabIndex={-1}
                className="hover:bg-[#1D71B3] cursor-pointer relative menu-item capitalize "
                key={`__menuItems${i}`}>
                <Link href={`/${item?.link}`} shallow={true}>
                  <a
                    className={
                      "py-[7px] px-[10px] inline-block text-white ailgn-middle font-normal text-sm 2xl:text-base " +
                      (item?.routes?.includes(router?.pathname?.split("/")?.[1])
                        ? "bg-soccer-red hover:bg-[#1D71B3]"
                        : "hover:bg-[#1D71B3]")
                    }>
                    {item?.name}
                  </a>
                </Link>
                {/* submenu */}
                {/* {item?.children?.length > 0 &&
                  item?.children?.map((child) => (
                    <div
                      className="whitespace-nowrap bg-transparent pt-[1px] cursor-pointer menu-sub-item absolute"
                      key={child?.id}>
                      <Link href={`/${child?.link}`} shallow={true}>
                        <a
                          className={
                            "py-[7px] px-[10px] inline-block text-white ailgn-middle font-normal text-sm 2xl:text-base " +
                            (child?.routes?.includes(
                              router?.pathname?.split("/")?.[1]
                            )
                              ? "bg-soccer-red hover:bg-[#1D71B3]"
                              : "hover:bg-[#1D71B3]") +
                            (router?.pathname === "/soccerbet-academy" &&
                              " bg-soccer-red-must")
                          }>
                          {child.name}
                        </a>
                      </Link>
                    </div>
                  ))} */}
              </li>
            ))}
          </ul>
          {/* <ul className="flex items-center gap-[5px]">
            <li className="text-white text-[15px]">
              <a
                target="_blank"
                rel="noreferrer"
                href="https://www.instagram.com/soccerbet.io/"
              >
                <BsInstagram />
              </a>
            </li>
            <li className="text-white text-[16px]">
              <a
                target="_blank"
                rel="noreferrer"
                href="https://www.tiktok.com/@soccerbx.com"
              >
                <FaTiktok />
              </a>
            </li>
            <li className="text-white text-[18px]">
              <a
                target="_blank"
                rel="noreferrer"
                href="https://twitter.com/Soccerbx"
              >
                <BsTwitter />
              </a>
            </li>
            <li className="text-white text-[21px]">
              <a
                target="_blank"
                rel="noreferrer"
                href="https://discord.gg/zM9d4bcGBJ"
              >
                <FaDiscord />
              </a>
            </li>
          </ul> */}
        </div>
      </div>
      <div className="relative md:hidden">
        <ul
          className={
            "absolute w-full bg-black top-0 overflow-hidden transition-[height_200ms_ease-in] " +
            (active ? "py-4" : "")
          }
          style={active ? { height: 900 } : { height: 0 }}
          ref={mbMenu}>
          {firstMenuItems?.map((item, i) => (
            <div key={i++}>
              {i === 0 && (
                <li className="md:hidden">
                  <HeaderSearch screen="mobile" />
                </li>
              )}
              <li
                className={`block pl-4 sm-menu ${
                  item?.children?.length ? "item__border_mbl" : ""
                }`}
                key={item?.id}>
                <Link href={`/${item?.link}`} shallow={true}>
                  <a
                    onClick={() => setActive(false)}
                    className={
                      "py-[7px] px-[10px] inline-block text-white ailgn-middle font-normal text-sm 2xl:text-base capitalize " +
                      (item?.routes?.[0] === router?.pathname?.split("/")?.[1]
                        ? "bg-soccer-red _selected-mbl-li"
                        : "")
                    }>
                    {" "}
                    {item?.name}
                  </a>
                </Link>

                {/* submenu */}
                {/* {item?.children?.length > 0 &&
                  item?.children?.map((child) => (
                    <div
                      className="block sm-sub-menu sub-item__border_mbl"
                      tabIndex={-2}
                      key={child?.id}>
                      <Link href={`/${child?.link}`} shallow={true}>
                        <a
                          onClick={() => setActive(false)}
                          className={
                            "p-2 border-t border-[#575757] ml-[25px] text-white block font-normal text-xl hover:text-red-200 " +
                            (child?.routes?.includes(
                              router?.pathname?.split("/")?.[1]
                            )
                              ? "bg-soccer-red _selected-mbl-li"
                              : "")
                          }>
                          {child?.name}
                        </a>
                      </Link>
                    </div>
                  ))} */}
              </li>
            </div>
          ))}
          {parentLeagues
            ?.filter((item) => item.status === "published")
            ?.map((item, i) => (
              <div key={i++}>
                {i === 0 && (
                  <li className="md:hidden">
                    <HeaderSearch screen="mobile" />
                  </li>
                )}
                <li
                  className={`block pl-4 sm-menu ${
                    item?.children?.length ? "item__border_mbl" : ""
                  }`}
                  key={item?.id}>
                  <Link href={`/${item?.slug}`} shallow={true}>
                    <a
                      onClick={() => setActive(false)}
                      className={
                        "py-[7px] px-[10px] inline-block text-white ailgn-middle font-normal text-sm 2xl:text-base capitalize" +
                        (item?.routes?.includes(
                          router?.pathname?.split("/")?.[1]
                        )
                          ? "bg-soccer-red hover:bg-[#1D71B3]"
                          : "hover:bg-[#1D71B3]")
                      }>
                      {item?.title}
                    </a>
                  </Link>
                </li>
              </div>
            ))}
          {menuItems?.map((item, i) => (
            <div key={i++}>
              {i === 0 && (
                <li className="md:hidden">
                  <HeaderSearch screen="mobile" />
                </li>
              )}
              <li
                className={`block pl-4 sm-menu ${
                  item?.children?.length ? "item__border_mbl" : ""
                }`}
                key={item?.id}>
                <Link href={`/${item?.link}`} shallow={true}>
                  <a
                    onClick={() => setActive(false)}
                    className={
                      "py-[7px] px-[10px] inline-block text-white ailgn-middle font-normal text-sm 2xl:text-base capitalize" +
                      (item?.routes?.[0] === router?.pathname?.split("/")?.[1]
                        ? "bg-soccer-red _selected-mbl-li"
                        : "")
                    }>
                    {" "}
                    {item?.name}
                  </a>
                </Link>

                {/* submenu */}
                {/* {item?.children?.length > 0 &&
                  item?.children?.map((child) => (
                    <div
                      className="block sm-sub-menu sub-item__border_mbl"
                      tabIndex={-2}
                      key={child?.id}>
                      <Link href={`/${child?.link}`} shallow={true}>
                        <a
                          onClick={() => setActive(false)}
                          className={
                            "p-2 border-t border-[#575757] ml-[25px] text-white block font-normal text-xl hover:text-red-200 " +
                            (child?.routes?.includes(
                              router?.pathname?.split("/")?.[1]
                            )
                              ? "bg-soccer-red _selected-mbl-li"
                              : "")
                          }>
                          {child?.name}
                        </a>
                      </Link>
                    </div>
                  ))} */}
              </li>
            </div>
          ))}

          {/* <ul className="flex mt-4 pl-4 items-center gap-[8px]">
            <li className="text-white text-[22px]">
              <a
                target="_blank"
                rel="noreferrer"
                href="https://www.instagram.com/soccerbet.io/"
              >
                <BsInstagram />
              </a>
            </li>
            <li className="text-white text-[22px]">
              <a
                target="_blank"
                rel="noreferrer"
                href="https://www.tiktok.com/@soccerbx.com"
              >
                <FaTiktok />
              </a>
            </li>
            <li className="text-white text-[23px]">
              <a
                target="_blank"
                rel="noreferrer"
                href="https://twitter.com/Soccerbx"
              >
                <BsTwitter />
              </a>
            </li>
            <li className="text-white text-[28px]">
              <a
                target="_blank"
                rel="noreferrer"
                href="https://discord.gg/zM9d4bcGBJ"
              >
                <FaDiscord />
              </a>
            </li>
          </ul> */}
        </ul>
      </div>
    </header>
  );
}
// export async function getStaticProps() {
//   const res = await calls("league", "get");

//   const allLeagues = res ?? [];

//   const data = {
//     allLeagues,
//   };

//   return {
//     props: {
//       data,
//     },
//     revalidate: 10,
//   };
// }
