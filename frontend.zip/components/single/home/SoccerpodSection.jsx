import React from "react";
import { AiOutlineArrowRight } from "react-icons/ai";
import { GrPlayFill } from "react-icons/gr";
import { IconContext } from "react-icons/lib";
import Link from "next/link";
import Image from "next/image";

export default function SoccerpodSection(soccerHeading) {
  const heading = soccerHeading?.soccerHeading;
  const description = soccerHeading?.soccerPodDescription;
  const image = soccerHeading?.soccerPodImage;
  const link = soccerHeading.soccerPodLink;

  return (
    <section className="soccerpod-background mt-5 ">
      <div className="max-w-[1280px] mx-auto py-6 px-4 md:p-10 grid grid-cols-1 md:grid-cols-2 md:gap-8">
        <div className="flex flex-col justify-between text-center md:text-left">
          <div>
            <svg
              xmlns="http://www.w3.org/2000/svg"
              className="mx-auto lg:mr-auto lg:ml-0 w-[103px] sm:w-[135px] h-[135px]"
              width="103"
              height="108"
              viewBox="0 0 103 108"
              fill="none">
              <path
                d="M16.5604 33.582C25.2326 33.582 30.8143 29.4304 30.8143 22.6494V22.5571C30.8143 16.0529 25.2788 13.6542 17.0217 12.132C13.6081 11.4862 12.7316 10.9326 12.7316 10.0562V9.96389C12.7316 9.1797 13.4697 8.62615 15.0842 8.62615C18.0826 8.62615 21.7268 9.59486 24.7713 11.8091L30.0301 4.52066C26.2936 1.56839 21.6807 0.0922571 15.4533 0.0922571C6.55034 0.0922571 1.75291 4.84356 1.75291 10.9787V11.071C1.75291 17.8981 8.11873 19.9739 15.361 21.4501C18.8207 22.142 19.8355 22.6494 19.8355 23.572V23.6642C19.8355 24.5407 19.0052 25.0481 17.0678 25.0481C13.2852 25.0481 9.27196 23.941 5.76614 21.2655L0 28.1388C4.10549 31.7368 10.01 33.582 16.5604 33.582Z"
                fill="white"
              />
              <path
                d="M50.1453 33.6743C60.1091 33.6743 67.8127 26.2014 67.8127 16.8371V16.7449C67.8127 7.38066 60.2014 0 50.2375 0C40.2736 0 32.5701 7.47292 32.5701 16.8371V16.9294C32.5701 26.2936 40.1814 33.6743 50.1453 33.6743ZM50.2375 24.1255C46.0859 24.1255 43.4565 20.6659 43.4565 16.8371V16.7449C43.4565 12.9623 46.0398 9.54873 50.1453 9.54873C54.2969 9.54873 56.9262 13.0084 56.9262 16.8371V16.9294C56.9262 20.712 54.343 24.1255 50.2375 24.1255Z"
                fill="white"
              />
              <path
                d="M86.7498 33.6743C94.7763 33.6743 99.2969 29.7533 102.019 24.9559L93.1156 19.9278C91.7779 22.3265 90.0711 23.9872 87.0266 23.9872C83.4746 23.9872 80.9837 21.0349 80.9837 16.8371V16.7449C80.9837 12.87 83.3824 9.68712 87.0266 9.68712C89.9788 9.68712 91.6856 11.3016 92.885 13.6081L101.788 8.3955C99.0663 3.45968 94.2689 0 87.165 0C77.524 0 70.0049 7.19615 70.0049 16.8371V16.9294C70.0049 26.9394 77.8008 33.6743 86.7498 33.6743Z"
                fill="white"
              />
              <path
                d="M17.7213 71.1542C25.7477 71.1542 30.2684 67.2332 32.99 62.4358L24.0871 57.4077C22.7494 59.8064 21.0426 61.4671 17.9981 61.4671C14.4461 61.4671 11.9551 58.5148 11.9551 54.3171V54.2248C11.9551 50.3499 14.3539 47.167 17.9981 47.167C20.9503 47.167 22.6571 48.7816 23.8565 51.088L32.7594 45.8754C30.0378 40.9396 25.2403 37.4799 18.1364 37.4799C8.49545 37.4799 0.9764 44.6761 0.9764 54.3171V54.4093C0.9764 64.4193 8.77222 71.1542 17.7213 71.1542Z"
                fill="white"
              />
              <path
                d="M36.011 70.4623H63.7807V61.6055H46.6207V58.0996H62.3969V50.3038H46.6207V47.0287H63.5501V38.1719H36.011V70.4623Z"
                fill="white"
              />
              <path
                d="M71.4938 70.4623H82.288V61.2364H84.5945L90.6835 70.4623H103L95.4809 59.4835C99.4019 57.5922 101.847 54.3171 101.847 49.6119V49.5196C101.847 46.1983 100.832 43.7996 98.8945 41.8622C96.6342 39.6019 92.99 38.1719 87.27 38.1719H71.4938V70.4623ZM82.288 53.5329V47.2132H86.9932C89.4842 47.2132 91.0987 48.228 91.0987 50.3038V50.3961C91.0987 52.3796 89.5303 53.5329 86.9471 53.5329H82.288Z"
                fill="white"
              />
              <path
                d="M2.67549 106.981H13.4697V98.2166H16.9755C25.6939 98.2166 31.6446 94.065 31.6446 86.2692V86.1769C31.6446 78.5195 25.7862 74.6908 17.2062 74.6908H2.67549V106.981ZM13.4697 90.5131V83.3169H16.422C19.282 83.3169 20.9888 84.5163 20.9888 86.8689V86.9611C20.9888 89.2676 19.1436 90.5131 16.3758 90.5131H13.4697Z"
                fill="white"
              />
              <path
                d="M50.7759 107.673C60.7398 107.673 68.4434 100.2 68.4434 90.836V90.7437C68.4434 81.3795 60.8321 73.9988 50.8682 73.9988C40.9043 73.9988 33.2007 81.4717 33.2007 90.836V90.9282C33.2007 100.292 40.812 107.673 50.7759 107.673ZM50.8682 98.1244C46.7166 98.1244 44.0872 94.6647 44.0872 90.836V90.7437C44.0872 86.9611 46.6704 83.5476 50.7759 83.5476C54.9276 83.5476 57.5569 87.0072 57.5569 90.836V90.9282C57.5569 94.7108 54.9737 98.1244 50.8682 98.1244Z"
                fill="white"
              />
              <path
                d="M71.3737 106.981H83.3672C96.4218 106.981 102.972 100.2 102.972 90.6514V90.5592C102.972 81.0105 96.5602 74.6908 83.7363 74.6908H71.3737V106.981ZM83.9669 84.1011C88.9027 84.1011 92.0856 86.1308 92.0856 90.7898V90.8821C92.0856 95.5411 88.9027 97.5708 83.9669 97.5708H82.1679V84.1011H83.9669Z"
                fill="white"
              />
            </svg>
          </div>
          <h1 className="text-md md:text-xl lg:text-3xl font-medium text-white mt-6  md:max-w-[540px] uppercase ">
            {/* Listen to the latest edition for more tips ahead of the game */}
            {heading}
          </h1>
          <h3 className="text-white font-light mt-[15px]">
            {/* Lorem ipsum dolor sit amet, consectetur adipiscing elit */}
            {description}
          </h3>

          <Link href="/soccerpod">
            <a className="hidden items-center gap-2 w-max ml-0 mt-4 text-white  md:flex">
              <span>See All Podcasts</span>
              <span>{<AiOutlineArrowRight />}</span>
            </a>
          </Link>
        </div>
        <div className="relative flex-1 justify-center lg:min-w-[50%]">
          <div className="w-full relative h-[240px] md:h-[300px] lg:h-[400px] lg:max-w-[646px] lg:ml-auto">
            <div className="">
              <Image
                src={image}
                layout="fill"
                objectFit="cover"
                objectPosition="center"
                alt="CHANGE_ME"
              />
            </div>
            {/* <img
              src={image ?? "/images/homepage/soccerpod.jpg"}
              alt=""
              className="mt-8 md:mt-0 w-full h-full"
            /> */}
            <Link href={link}>
              <button className="flex items-center gap-3 py-2 px-2 md:px-4 md:py-3 bg-red-700 absolute bottom-4 left-4">
                <span className="text-white font-normal text-sm md:text-lg">
                  Listen Now
                </span>
                <span className="text-sm md:text-lg">
                  <IconContext.Provider value={{ className: "invert" }}>
                    <GrPlayFill />
                  </IconContext.Provider>
                </span>
              </button>
            </Link>
          </div>
        </div>

        <div className="w-full flex justify-end text-right ">
          <Link href="/soccerpod">
            <a className=" flex md:hidden items-center gap-2 w-max ml-0 mt-4 text-white">
              <span>See All Podcasts</span>
              <span>{<AiOutlineArrowRight />}</span>
            </a>
          </Link>
        </div>
      </div>
    </section>
  );
}
