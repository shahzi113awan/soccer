import React from "react";
import { MdOutlineChatBubble } from "react-icons/md";
import PropTypes from "prop-types";
import Link from "next/link";
export default function FeaturedArticle({
  title = "",
  innerClassName = "",
  className = "",
  content = "",
  author = "",
  image = "",
  slug = "",
}) {
  return (
    <React.Fragment>
      <div className={`${className} m-1`}>
        <Link href={`/news/${slug}`}>
          <a>
            <div className={innerClassName}>
              <div className="mt-3 h-[76px] sm:h-[238px] flex ">
                <img src={image} alt={title} className=" object-cover w-full" />
              </div>
              <div>
                <h3 className="sm:text-lg text-[20px] leading-[22px]">
                  {title}
                </h3>
                <div className="h-[24px] overflow-hidden"> {content}</div>

                <div className="flex items-center gap-3 mt-3">
                  {/* <p className="text-xs">{author}</p> */}
                  <p className="text-xs">Soccerbx Team</p>

                  {/* <MdOutlineChatBubble />
                  <span className="text-sm">123</span> */}
                </div>
              </div>
            </div>
          </a>
        </Link>
      </div>
    </React.Fragment>
  );
}

FeaturedArticle.defaultProps = {
  headingClass: "sm:text-xl",
};

FeaturedArticle.propTypes = {
  title: PropTypes.string,
  innerClassName: PropTypes.string,
  className: PropTypes.string,
  headingClass: PropTypes.string,
  heading: PropTypes.string,
  author: PropTypes.string,
  image: PropTypes.string,
};
