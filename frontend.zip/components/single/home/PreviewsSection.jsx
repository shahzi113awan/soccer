import React, { useEffect, useState } from "react";
import PreviewsSingleArticle from "../../shared/PreviewsSingleArticle";
// import { useSelector, useDispatch } from "react-redux";
// import PreviewsVTeams from "../../shared/PreviewsVTeams";
import Link from "next/link";
import { AiOutlineArrowRight } from "react-icons/ai";
// import { calls } from "../../../Services/PromiseHandler/PromiseHandler";
// import {
//   getPreviewsFail,
//   getPreviewsSuccess,
// } from "../../../redux/reducers/previewsReducer/previewsReducer";
import TitleTable from "../../commonComponents/TitleTable/TitleTable";

export default function PreviewsSection({
  leagueMatches,
  LeagueTitile,
  leagueSlug,
}) {
  // const dispatch = useDispatch();
  // const fetchData = async () => {
  //   const res = await leagueMatches;
  //   if (res?.data) {
  //     dispatch(getPreviewsSuccess(res?.data));
  //   } else {
  //     dispatch(getPreviewsFail(res));
  //   }
  // };
  // const reduxState = useSelector((state) => state);
  // const {
  //   previews: { data },
  // } = reduxState;

  // let mounted = false;

  // useEffect(() => {
  //   if (!mounted) {
  //     if (data?.length <= 0) {
  //       fetchData();
  //     }
  //   }
  //   mounted = true;
  // }, []);

  const dataSet = [...leagueMatches];

  const usaTime = new Date().toLocaleString("en-US", {
    timeZone: "America/New_York",
  });

  const sortedArray = dataSet?.sort((a, b) => {
    return (
      new Date(a.venueDateAndTime).getTime() -
      new Date(b.venueDateAndTime).getTime()
    );
  });

  const pastMatches = sortedArray?.filter((x) => {
    return (
      new Date(x.venueDateAndTime).getTime() <= new Date(usaTime).getTime() &&
      x?.status === "published"
    );
  });

  const upcomingMatches = sortedArray?.filter((x) => {
    return (
      new Date(x.venueDateAndTime).getTime() >= new Date(usaTime).getTime() &&
      x?.status === "published"
    );
  });

  if (
    new Date(upcomingMatches[0]?.venueDateAndTime).getTime() - 3600000 <=
    new Date(usaTime).getTime()
  ) {
    pastMatches.push(upcomingMatches[0]);
    upcomingMatches.shift(1, 1);
  } else {
    if (
      new Date(
        pastMatches[pastMatches.length - 1]?.venueDateAndTime
      ).getTime() +
        7200000 <=
      new Date(usaTime).getTime()
    ) {
      if (!upcomingMatches.length <= 0) {
        pastMatches.push(upcomingMatches[0]);
      }
      upcomingMatches.shift(1, 1);
    }
  }

  // console.log("pastMatches---->>", pastMatches);
  let currentMatch = pastMatches[pastMatches.length - 1];
  pastMatches.pop();

  if (!currentMatch) {
    currentMatch = upcomingMatches[0] ?? "";
    upcomingMatches.shift();
  }

  // console.log("currentMatch------->>", currentMatch);
  // if (!currentMatch) {
  //   currentMatch = upcomingMatches[0];
  //   upcomingMatches.shift();
  //   console.log("not a currentMatch--------->>", currentMatch);
  // }
  // console.log("currentMatch------->>", currentMatch);

  // if (!currentMatch) {
  //   currentMatch = upcomingMatches[0];
  //   upcomingMatches.pop();
  // }
  // const currentMatch = upcomingMatches?.length
  //   ? upcomingMatches.shift()
  //   : pastMatches?.pop();
  // pastMatches.pop();
  // console.log("upcomingMatches------->>", upcomingMatches);

  // const _data = upcomingMatches;

  return (
    <section className="lg:p-0 sm:px-3">
      <div className="grid grid-cols-1 md:grid-cols-[1fr_370px] lg:grid-cols-[1fr_400px] xl:grid-cols-[1fr_440px]">
        <div className="py-4 lg:p-4 border-r">
          <h1 className="text-[20px] mb-1 sm:px-0 px-2">{LeagueTitile}</h1>
          <Link href={`/${leagueSlug}/${currentMatch?.slug}`}>
            <div className="bg-black flex justify-between">
              <div className="xl:w-6/12 flex-1">
                <div className="cursor-pointer lg:max-w-[340px] h-full flex flex-col md:pl-[1rem] lg:pt-[1rem]">
                  <div className="hidden lg:block max-w-[164px] h-[164px]">
                    <TitleTable
                      fontSizes="text-[58px] leading-[22px] lg:text-[46px]"
                      gap={1}
                      pb={1}
                      pt={1}
                      pl={1}
                      pr={1}
                      title={currentMatch?.title}
                    />
                  </div>
                  <div className="grid grid-cols-2 border-b lg:hidden">
                    <div className="flex items-center mx-[auto]">
                      <div className="max-w-[132px] w-[132px] h-[132px]">
                        <TitleTable
                          fontSizes="text-[35px] sm:text-[45px] leading-[22px] lg:text-[52px]"
                          gap={1}
                          title={currentMatch?.title}
                        />
                      </div>
                    </div>
                    <img
                      src={currentMatch?.featuredImage}
                      alt=""
                      className={`relative border-l md:h-[300px] min-h-[187px] object-cover`}
                    />
                  </div>
                  <div className="p-4 md:p-0">
                    <h2 className="uppercase text-white font-medium mt-4 md:text-2xl lg:mt-4 lg:text-lg xl:text-2xl xl:mt-8 text-left">
                      {currentMatch?.subTitle}
                    </h2>
                    <h3 className="text-white lg:text-xs mt-3 xl:text-base overflow-hidden max-h-[100px] text-left font-semibold">
                      {currentMatch?.excerpt}
                    </h3>
                  </div>
                </div>
              </div>
              <div className="hidden cursor-pointer flex-1 items-center lg:block ">
                <img
                  src={currentMatch?.featuredImage}
                  alt="CHANGE_ME"
                  className={`relative h-[391px] flex flex-1 items-center justify-center object-cover`}
                  width="100%"
                />
              </div>
            </div>
          </Link>
        </div>
        <div className="px-4 md:pt-10">
          {upcomingMatches
            ?.filter((item) => item?.status === "published")
            ?.slice(0, 3)
            ?.map((item) => (
              <div key={item?._id}>
                <PreviewsSingleArticle
                  slug={`${leagueSlug}/${item?.slug}`}
                  image={item?.featuredImage}
                  teamOne={item?.title?.split(" ")?.[0]}
                  teamTwo={item?.title?.split(" ")?.[2]}
                  midTitle={item?.title?.split(" ")?.[1]}
                  title={item?.subTitle}
                  tempTitle={item?.title}
                  author={item?.author?.name ?? ""}
                  className={"hidden lg:block w-[128px] xl:w-[155px]"}
                />
              </div>
            ))}
          <div className="mt-3">
            <Link href={`${leagueSlug}`}>
              <a className="flex items-center gap-2 w-max ml-auto">
                {" "}
                <span>See All</span> <span>{<AiOutlineArrowRight />}</span>{" "}
              </a>
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
}
