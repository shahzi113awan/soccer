import React, { useState, useEffect } from "react";
import Image from "next/image";
import Skeleton from "react-loading-skeleton";
import "react-loading-skeleton/dist/skeleton.css";

export default function HeroSection({ bigScreenImage, bannerHeading }) {
  const [loading, setLoading] = useState(true);
  const [bannerImage, setBannerImage] = useState();
  const getBannerData = () => {
    setLoading(true);
    setBannerImage(bigScreenImage);
    setLoading(false);
  };
  useEffect(() => {
    getBannerData();
  }, [bigScreenImage]);
  const getTodayDate = () => {
    const date = new Date();

    const newYorkDay = date.toLocaleString("en-US", {
      timeZone: "America/New_York",
      weekday: "short",
    });

    const newYorkDayDigit = date.toLocaleString("en-US", {
      timeZone: "America/New_York",
      day: "2-digit",
    });

    const newYorkMonth = date.toLocaleString("en-US", {
      timeZone: "America/New_York",
      month: "short",
    });

    const newYorkYear = date.toLocaleString("en-US", {
      timeZone: "America/New_York",
      year: "numeric",
    });

    return `${newYorkDay}, ${newYorkDayDigit} ${newYorkMonth} ${newYorkYear}`;
  };

  return (
    <React.Fragment>
      {loading ? (
        <>
          {["sk1"].map((x) => (
            <div
              className="sm:col-span-12 md:col-span-12 col-span-12 my-3"
              key={x}>
              <Skeleton height={500} width="100%" />
            </div>
          ))}
        </>
      ) : (
        <>
          <section className="h-60 md:h-[598px]">
            <div className="relative h-full">
              {/* <picture> */}
              {/* <source media="(min-width: 768px)" srcSet={bigScreenImage} />
         <source media="(max-width: 450px)" srcSet={bigScreenImage} /> */}

              <div className="w-full h-[240px] md:h-[598px]  ">
                <Image
                  src={bannerImage}
                  layout="fill"
                  objectFit="cover"
                  objectPosition="center"
                  alt="CHANGE_ME"
                />
              </div>

              {/* <img
         src={bigScreenImage}
         alt="CHANGE_ME"
         className="w-full h-full object-cover xl:object-contain bg-black"
       /> */}
              {/* </picture> */}
              <div className="absolute bottom-0 w-full">
                <div className="linear-background h-16 md:h-[110px]"></div>
                <h1 className="uppercase text-2xl md:text-[60px] lg:text-[78px] xl:text-[96px] text-white absolute h-full w-full top-0 flex text-center items-center justify-center">
                  {bannerHeading}
                </h1>
              </div>
            </div>
          </section>
          <div className="linear-background mix-blend-normal">
            <p className="font-light text-white py-3 pl-5 md:border-r md:border-white md:w-max md:pr-12 md:pl-8">
              {getTodayDate()}
            </p>
          </div>
        </>
      )}
    </React.Fragment>
  );
}
