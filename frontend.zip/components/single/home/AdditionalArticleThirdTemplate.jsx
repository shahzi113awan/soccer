import React from "react";
import FeaturedArticle from "../../shared/FeaturedArticle";
import { news } from "../../../assets/fakedata/news";

export default function AdditionalArticleThirdTemplate() {
  return (
    <div className=" px-4 mt-6 lg:px-8 max-w-[1280px] mx-auto">
      <h3 className="text-[20px]">Module Title</h3>
      <div className={"grid grid-cols-1 md:grid-cols-2 gap-4"}>
        {/* Featured Article takes 4 props title, content, className, headingClass and innerClassName. innerClassName goes to internal div */}
        {/* <FeaturedArticle headingClass='lg:text-2xl xl:text-3xl' className='border-b pb-4' content="Aenean placerat. In vulputate urna eu arcu. Aliquam erat volutpat. Suspendisse potenti. Morbi mattis felis at nunc Aenean placerat." /> */}
        {news.slice(0, 2).map((n) => (
          <FeaturedArticle
            headingClass="lg:text-2xl xl:text-3xl"
            author={n.author.name}
            className="border-b pb-4"
            content={n.excerpt}
            key={n._id}
            heading={n.title}
            image={n.featuredImage}
            imageClass="md:h-[400px]"
            leagueTag={n?.league?.slug}
          />
        ))}
      </div>
    </div>
  );
}
