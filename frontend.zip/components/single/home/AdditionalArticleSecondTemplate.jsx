import React from 'react'
import FeaturedArticle from '../../shared/FeaturedArticle'
import { news } from '../../../assets/fakedata/news'

export default function AdditionalArticleSecondTemplate({innerClassName}) {
  return (
    <div className=" px-4 mt-6 lg:px-8 max-w-[1280px] mx-auto">
      <h3 className="text-[20px]">Module Title</h3>
      <div className={innerClassName}>
        {/* Featured Article takes 4 props title, content, className and innerClassName. innerClassName goes to internal div */}
        {news.slice(0, 3).map((n) => (
          <FeaturedArticle
            className="border-b pb-4"
            key={n._id}
            author={n.author.name}
            heading={n.title}
            image={n.featuredImage}
            content={n.excerpt}
            imageClass="md:h-[262px]"
          />
        ))}
      </div>
    </div>
  );
}

AdditionalArticleSecondTemplate.defaultProps = {
  innerClassName: 'grid grid-cols-1 md:grid-cols-3 gap-4'
}