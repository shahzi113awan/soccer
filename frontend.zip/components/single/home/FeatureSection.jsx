import React, { useEffect } from "react";
import { useSelector, useDispatch } from "react-redux";
import FeaturedArticle from "../../shared/FeaturedArticle";
import { calls } from "../../../Services/PromiseHandler/PromiseHandler";
import SingleNews from "../../shared/SingleNews";
import { getFeaturesSuccess } from "../../../redux/reducers/featuresReducer/featuresReducers";

export default function FeatureSection({ className }) {
  const dispatch = useDispatch();
  const getFeatures = async () => {
    const res = await calls("features", "get");

    dispatch(getFeaturesSuccess(res?.data ?? []));
  };

  const features = useSelector((state) => state.features?.data);

  useEffect(() => {
    if (features?.length <= 0) {
      getFeatures();
    }
  }, []);

  return (
    <div className={className}>
      <div className="grid grid-cols-1 md:grid-cols-[1fr_350px] lg:grid-cols-[1fr_400px] xl:grid-cols-[1fr_440px] mb-4 md:mb-0">
        <div className="border-b md:border-r mx-4 md:mx-0">
          <div className="py-4 md:px-6 lg:pl-8 lg:pr-[32px] md:flex md:gap-2 lg:gap-6 pb-3">
            {features
              ?.filter((item) => item.isActive)
              .slice(0, 1)
              .map((n) => (
                <FeaturedArticle
                  key={n._id}
                  author={n?.author?.name}
                  heading={n.title}
                  headingClass={"lg:text-2xl"}
                  title="Team USA"
                  slug={`/team-usa/${n.slug}`}
                  image={n.featuredImage}
                  innerClassName=" md:flex md:gap-2 lg:gap-6"
                  content={n.excerpt}
                  leagueTag={n?.league?.slug}
                />
              ))}
          </div>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-1 gap-4  px-4 md:px-0 md:pt-8 mt-4">
          {/* Single News takes two props (not necessary), className and type. News type prints smaller images, module type prints big images. Has both default props */}
          {features
            ?.filter((item) => item.isActive)
            .slice(1, 3)
            .map((n) => (
              <SingleNews
                isFirstSec={false}
                key={n._id}
                slug={`/team-usa/${n.slug}`}
                heading={n.title}
                image={n.featuredImage}
                author={n?.author?.name}
                className="px-0 border-b pb-2 md:p-4 lg:pr-8"
                leagueTag={n?.league?.slug}
              />
            ))}
        </div>
      </div>
    </div>
  );
}
