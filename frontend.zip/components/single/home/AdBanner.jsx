import React from 'react'

export default function AdBanner() {
  return (
    <div className="bg-[#ECECEC] py-1 md:py-6 mt-4">
      <div className='my-8 w-7/12 mx-auto h-[132px] bg-[rgba(196,196,196,1)] flex items-center flex-col justify-center'>
        <p>Banner</p><br />
        <p>Size ? X ?</p>
      </div>
    </div>
  )
}
