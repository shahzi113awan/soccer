import React from "react";
import { AiOutlineArrowRight } from "react-icons/ai";
import SingleNews from "../../shared/SingleNews";
import Link from "next/link";
// import { useSelector } from "react-redux";
import FeaturedArticle from "../../shared/FeaturedArticle";
// import { news } from "../../../assets/fakedata/news";
const NewsSection = ({ allLeagueNews }) => {
  // const { data: newsData } = useSelector((state) => state.news);
  return (
    <section>
      {allLeagueNews?.length > 0 && (
        <div className="grid grid-cols-1 md:grid-cols-[1fr_250px_200px] lg:grid-cols-[1fr_300px_300px] xl:grid-cols-[auto_395px_340px]  ">
          <div className="p-4 md:pl-6 md:border-b lg:pl-8">
            {allLeagueNews?.filter((n) => n.isFeatured)?.length
              ? allLeagueNews
                  ?.filter(
                    (n) =>
                      n.isFeatured &&
                      n.status === "published" &&
                      n?.league?.status === "published" &&
                      !n.isScheduled
                  )
                  .slice(0, 1)
                  .map((n) => (
                    <FeaturedArticle
                      key={n._id}
                      title={"News"}
                      slug={`/news/${n?.league?.slug}/${n?.slug}`}
                      heading={n.title}
                      isCard={false}
                      content={n.excerpt}
                      author={n?.author?.name}
                      image={n.featuredImage}
                      leagueTag={n?.league?.slug}
                      leagueId={n?.league?.slug}
                    />
                  ))
              : ""}
          </div>
          <div className="grid sm:mt-[62px] grid-cols-2 md:grid-cols-1 mx-auto px-2 md:px-[16px] md:border-l md:border-r md:border-b border-y-2 sm:border-0 content-start">
            {/* Single News takes two props (not necessary), className and type. News type prints smaller images, module type prints big images. Has both default props */}
            {allLeagueNews?.filter((n) => n.isFeatured)?.length
              ? allLeagueNews
                  ?.filter(
                    (n) =>
                      n.isFeatured &&
                      n.status === "published" &&
                      n?.league?.status === "published" &&
                      !n.isScheduled
                  )
                  .slice(1, 5)
                  .map((n, idx) => (
                    <SingleNews
                      idx={idx}
                      className={
                        idx === 0
                          ? "sm:border-t-0"
                          : "md:px-0 sm:border sm:border-l-0 sm:border-r-0 sm:border-b-0"
                      }
                      key={n._id}
                      heading={n.title}
                      author={n?.author?.name}
                      slug={`/news/${n?.league?.slug}/${n?.slug}`}
                      image={n.featuredImage}
                      type="news"
                      leagueTag={n?.league?.slug}
                      leagueId={n?.league?.slug}
                    />
                  ))
              : ""}
          </div>
          {allLeagueNews?.filter((n) => n.isFeatured)?.length ? (
            <div className="p-4 pt-0 sm:mt-[56px] border-b md:pr-8">
              <h3 className="uppercase text-[18px] mt-[15px] sm:mt-0 leading-[22px]">
                Headlines
              </h3>
              <ul className="mt-4">
                {allLeagueNews?.filter((n) => n.isFeatured)?.length
                  ? allLeagueNews
                      ?.filter(
                        (n) =>
                          n.isFeatured &&
                          n.status === "published" &&
                          n?.league?.status === "published" &&
                          !n.isScheduled
                      )
                      .slice(1, 10)
                      ?.map((n) => (
                        <Link
                          key={n._id}
                          href={`/news/${n?.league?.slug}/${n?.slug}`}>
                          <li
                            className="my-5 sm:my-2 cursor-pointer headlines-text"
                            title={n?.excerpt}>
                            <p className="text-sm text-black leading-[18px]">
                              <span>{n.excerpt ?? ""}</span>
                            </p>
                          </li>
                        </Link>
                      ))
                  : ""}
              </ul>
              <div className="mt-3">
                <Link href="/news">
                  <a className="flex items-center gap-2 w-max ml-auto">
                    <span>See All</span> <span>{<AiOutlineArrowRight />}</span>{" "}
                  </a>
                </Link>
              </div>
            </div>
          ) : (
            ""
          )}
        </div>
      )}
    </section>
  );
};

export default React.memo(NewsSection);
