import React, { useState, useEffect } from "react";
import parse from "html-react-parser";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import Slider from "react-slick";
import { news } from "../../../assets/fakedata/news";
import SliderCard from "./SliderCard/SliderCard";
function SamplePrevArrow(props) {
  const { className, style, onClick } = props;
  return (
    <div
      className={`${className} home_bArrowLeft`}
      style={{ ...style, display: "block", background: "red" }}
      onClick={onClick}
    />
  );
}

function SampleNextArrow(props) {
  const { className, style, onClick } = props;
  return (
    <div
      className={`${className} home_bArrowRight`}
      style={{ ...style }}
      onClick={onClick}
    />
  );
}

export default function ArticleSlider() {
  // const [mounted, setMounted] = useState(false);
  // useEffect(() => {
  //     setMounted(true)
  // }, [mounted])
  const settings = {
    arrows: true,
    infinite: true,
    speed: 500,
    dots: true,
    centerMode: true,
    slidesToShow: 3.1,
    slidesToScroll: 1,
    nextArrow: <SampleNextArrow />,
    prevArrow: <SamplePrevArrow />,
    customPaging: function (i) {
      return <div className="pag_slide"></div>;
    },
    responsive: [
      {
        breakpoint: 1024,
        settings: {
          slidesToShow: 3.5,
          slidesToScroll: 1,
          infinite: true,
          dots: true,
        },
      },
      {
        breakpoint: 600,
        settings: {
          slidesToShow: 2,
          slidesToScroll: 1,
          initialSlide: 2,
        },
      },
      {
        breakpoint: 480,
        settings: {
          slidesToShow: 1.22,
          slidesToScroll: 1,
        },
      },
    ],
  };
  return (
    <div className="p-4 md:px-6 lg:px-8 max-w-[1280px] mx-auto">
      <h3 className="text-[20px]">Module Title</h3>
      <div className="">
        <Slider {...settings}>
          {news?.map((n) => (
            <SliderCard
              title={n?.title}
              key={n?._id}
              content={parse(n?.content)}
              author={n?.author?.name}
              image={n?.featuredImage}
              slug={n?.slug}
            />
          ))}
        </Slider>
      </div>
    </div>
  );
}
