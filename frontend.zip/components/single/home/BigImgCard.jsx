import React from "react";
import { MdOutlineChatBubble } from "react-icons/md";
import PropTypes from "prop-types";
import Link from "next/link";
export default function BigImgCard({ news }) {
  return (
    <div className=" px-4 mt-6 lg:px-8 max-w-[1280px] mx-auto">
      <h3 className="text-[20px]">Module Title</h3>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Featured Article takes 4 props title, content, className and innerClassName. innerClassName goes to internal div */}
        {news.slice(0, 3).map((item) => (
          <div key={item._id} className=" border-b pb-4 m-1">
            <Link href={`/news/${item?.slug}`}>
              <a>
                <div>
                  <div className="mt-3 ">
                    <img
                      src={item?.featuredImage}
                      alt={item?.title}
                      width="100%"
                      className="h-[397px] object-cover"
                    />
                  </div>
                  <div>
                    <h2 className="uppercase mt-2 lg:mt-4 text-[22px] sm:text-[24px] leading-[22px]   pb-3">
                      {item?.title}
                    </h2>

                    <div className="two-lines-text leading-[16px]">
                      {" "}
                      {item?.excerpt}
                    </div>

                    <div className="flex items-center gap-3 mt-3">
                      {/* <p className="text-xs">{item?.author.name}</p> */}
                      <p className="text-xs">Soccerbx Team</p>

                      {/* <MdOutlineChatBubble />
                      <span className="text-sm">123</span> */}
                    </div>
                  </div>
                </div>
              </a>
            </Link>
          </div>
        ))}
      </div>
    </div>
  );
}

BigImgCard.propTypes = {
  title: PropTypes.string,
  innerClassName: PropTypes.string,
  className: PropTypes.string,
  headingClass: PropTypes.string,
  heading: PropTypes.string,
  author: PropTypes.string,
  image: PropTypes.string,
};
