import Link from "next/link";
import React from "react";
import Image from "next/image";

export default function GoalFest(
  goalFestHeading,
  goalFestDescription,
  goalFestImage
) {
  const heading = goalFestHeading?.goalFestHeading;
  const description = goalFestHeading?.goalFestDescription;
  const image = goalFestHeading?.goalFestImage;
  return (
    <div className="bg-black mt-5">
      <Link href="/team-usa">
        <div className="cursor-pointer max-w-[1280px] mx-auto flex flex-col md:flex-row md:items-center">
          <div className="md:w-6/12 ">
            <div className="p-2">
              {/* <p className="text-white text-xs mt-2">14 May | Tag</p> */}
              <h1 className="text-white text-center font-medium text-xl md:text-2xl mt-2">
                {heading}
              </h1>
            </div>
            <div className="p-2">
              <p className="text-white text-center font-normal text-md md:text-xl mt-1">
                {description}
              </p>
            </div>
          </div>
          <div className="md:w-6/12 order ">
            <div className="w-full relative h-[240px] md:h-[300px] lg:h-[400px] ">
              <Image
                src={image}
                layout="fill"
                objectFit="cover"
                objectPosition="center"
                alt="CHANGE_ME"
              />
            </div>
            {/* <img src={image} alt="" className=" w-full h-full object-cover" /> */}
          </div>
        </div>
      </Link>
    </div>
  );
}

{
  /* <p className="text-white mt-4">
               {description}
              </p>
              <div className="flex items-center gap-4 mt-4">
                <span className="">
                  <img
                    src="/images/homepage/goalfestWriter.png"
                    alt=""
                    className="bg-slate-200 w-8 h-8 object-cover rounded-full"
                  />
                </span>
                <span className="text-xs font-normal text-white">
                  By Soccerbx Team
                </span>
              </div> */
}
