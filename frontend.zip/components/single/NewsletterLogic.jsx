import { useState } from 'react'
import { newsLetterPost } from "../../Services/newsLetter/newsLetter.service"

export default function NewsletterLogic() {
    const [email, setEmail] = useState('')
    const [error, setError] = useState(null)
    const [success, setSuccess] = useState('')

    async function newsletterSubmit(e) {
        e.preventDefault();
        const error = ValidateEmail(email);
        if (error) {
            setError(error)
            return;
        }
        try {
            const res = await newsLetterPost(email)
            if (res.status == 200) {
                setSuccess('Thank you for subscribing for the newsletter.')
                setEmail('')
                setTimeout(() => {
                    setSuccess('')
                }, 2000);
            }
        } catch (err) {
            console.log(err)
        }
    }
    function handleChange(e) {
        setEmail(e.target.value)
        setError('')
    }
    function ValidateEmail(mail) {
        if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(mail)) {
            return (null)
        }
        return ("Invalid email address")
    }

    return { newsletterSubmit, error, success, email, handleChange };
}
