import React from 'react'
import PropTypes from 'prop-types'
import MenuItem from '../base/MenuItem'
import Link from 'next/link'
import HeaderSearch from '../shared/HeaderSearch'

export default function NavMenu({ active, mbMenu }) {
  let mbLinkClasses = "text-white font-normal text-xl hover:text-[#01A4FF]";

  return (
    <ul
      className={
        "absolute w-full bg-black top-0 overflow-hidden transition-[height_200ms_ease-in] " +
        (active ? "py-4" : "")
      }
      style={active ? { height: 472 } : { height: 0 }}
      ref={mbMenu}
    >
      <li className="md:hidden">
        <HeaderSearch />
      </li>
      <MenuItem
        listClass="px-6 py-1"
        linkClass={mbLinkClasses}
        label="About Us"
        link="#"
      />
      <MenuItem
        listClass="px-6 py-1"
        linkClass={mbLinkClasses}
        label="News"
        link="/news"
      />
      <MenuItem
        listClass="px-6 py-1"
        linkClass={mbLinkClasses}
        label="Previews"
        link="#"
      />
      <MenuItem
        listClass="px-6 py-1"
        linkClass={mbLinkClasses}
        label="Features"
        link="#"
      />
      <MenuItem
        listClass="px-6 py-1"
        linkClass={mbLinkClasses}
        label="Gaming"
        link="#"
      />
      <MenuItem
        listClass="px-6 py-1"
        linkClass={mbLinkClasses}
        label="Betting"
        link="#"
      />
      <MenuItem
        listClass="px-6 py-1"
        linkClass={mbLinkClasses}
        label="Podcast"
        link="#"
      />
      <li className="mt-4 md:hidden">
        <div className="py-4 px-6 border-t">
          <Link href="#">
            <a className="text-[#01A4FF] text-xl font-normal"> Subscribe </a>
          </Link>
        </div>
      </li>
      <li className="md:hidden">
        <div className="py-4 px-6 border-t">
          <Link href="#">
            <a className="text-xl text-white hover:text-[#01A4FF] font-normal">
              {" "}
              Contact Us{" "}
            </a>
          </Link>
        </div>
      </li>
    </ul>
  );
}

 