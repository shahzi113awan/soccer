import React from 'react'

export default function HamburgerButton({ active, setActive }) {
    return (
        <button className={'md:hidden ' + (active ? 'open' : "close")} onClick={() => setActive(!active)}>
            <div className='w-[27px] h-[3px] mb-[3px] bg-white'></div>
            <div className='w-[27px] h-[3px] mb-[3px] bg-white'></div>
            <div className='w-[27px] h-[3px] bg-white'></div>
        </button>
    )
}
