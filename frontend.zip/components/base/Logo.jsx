import Link from "next/link";
import React, { useEffect, useState } from "react";

export default function Logo({ isScrolled }) {
  return (
    <Link href="/">
      <a>
        {" "}
        <div
          className={
            "flex flex-wrap transition-[width_100ms_ease-in-out] pb-3 sm:pb-0 " +
            (isScrolled ? "w-[12.5rem] md:w-64" : " mt-3 w-24 md:w-28")
          }
        >
          <img
            src="/logo/logo-s.svg"
            alt=""
            className={isScrolled ? "w-5 md:w-7" : "w-7 md:w-9"}
          />
          <img
            src="/logo/logo-o.svg"
            alt=""
            className={isScrolled ? "w-5 md:w-7" : "w-7 md:w-9"}
          />
          <img
            src="/logo/logo-c.svg"
            alt=""
            className={isScrolled ? "w-5 md:w-7" : "w-7 md:w-9"}
          />
          <img
            src="/logo/logo-c.svg"
            alt=""
            className={isScrolled ? "w-5 md:w-7" : "w-7 md:w-9"}
          />
          <img
            src="/logo/logo-e.svg"
            alt=""
            className={isScrolled ? "w-5 md:w-7" : "w-7 md:w-9"}
          />
          <img
            src="/logo/logo-r.svg"
            alt=""
            className={isScrolled ? "w-5 md:w-7" : "w-7 md:w-9"}
          />
          <img
            src="/logo/logo-b.svg"
            alt=""
            className={isScrolled ? "w-5 md:w-7" : "w-7 md:w-9"}
          />
          <img
            src="/logo/logo-x.svg"
            alt=""
            className={isScrolled ? "w-5 md:w-7" : "w-7 md:w-9"}
          />
          <img
            src="/logo/logo-com.svg"
            alt=""
            className={isScrolled ? "w-5 md:w-7" : "w-7 md:w-9"}
          />
        </div>
      </a>
    </Link>
  );
}
