import React from 'react'
import Link from 'next/link'
import PropTypes from 'prop-types'

export default function MenuItem({ link, label, listClass, linkClass }) {
    return (
        <li className={listClass}><Link href={link}><a className={linkClass}> {label} </a></Link></li>
    )
}

MenuItem.defaultProps = {
    link: "#"
}

MenuItem.propTypes = {
    link: PropTypes.string,
    label: PropTypes.string.isRequired,
    listClass: PropTypes.string,
    linkClass: PropTypes.string
}