import Link from "next/link";
import React from "react";
import TitleTable from "../../commonComponents/TitleTable/TitleTable";

const LeagueMatchHero = ({ item, leagueSlug }) => {
  return (
    <div>
      <Link href={`${leagueSlug}/${item?.slug ?? item?._id}`}>
        <a className="py-3">
          <div className="flex justify-between bg-black sm:border-0 border-b border-white">
            <div className="flex-1 flex flex-col items-center justify-center sm:pt-5">
              <div className="m-auto sm:w-[300px] w-[90%] h-[90%] flex flex-col justify-center">
                <div className="sm:h-[300px] sm:w-auto h-[133px] w-[133px] sm:mx-0 mx-auto">
                  <TitleTable
                    fontSizes="text-[35px] sm:text-[45] md:text-[58px] leading-[22px] lg:text-[80px] font-extrabold"
                    title={item?.title}
                    gap={1}
                    pb={1}
                    pt={1}
                    pr={1}
                    pl={1}
                  />
                </div>{" "}
                <h2 className="mt-5 lg:text-2xl text-xl text-white lg:block hidden">
                  {item?.subTitle?.toUpperCase() ?? ""}
                </h2>
                <h4 className="hidden sm:block text-white text-[16px]">
                  <div>
                    {item?.venueLocation ?? ""}
                    {item?.venueDateAndTime &&
                      ` - ${new Date(item?.venueDateAndTime)?.getHours()}.${
                        new Date(item?.venueDateAndTime)?.getMinutes() <= 9
                          ? "0" + new Date(item?.venueDateAndTime)?.getMinutes()
                          : new Date(item?.venueDateAndTime)?.getMinutes()
                      }
                 EST`}
                  </div>
                  <div>
                    {item?.venueDateAndTime &&
                      new Date(item?.venueDateAndTime)?.toDateString()}
                  </div>
                </h4>
              </div>
              <div className="my-4 p-4 lg:block hidden">
                <h4 className="lg:text-base text-white">
                  {item?.excerpt ?? ""}
                </h4>
              </div>
            </div>

            <div className="flex-1">
              <img
                src={item?.featuredImage}
                alt={item?.title}
                className={`md:max-h-[650px] h-full lg:h-[639px] object-cover min-w-[170px] min-h-[187px] ${
                  !Boolean(item?.featuredImage) && "no-image_img"
                }`}
                width="100%"
              />
            </div>
          </div>
          <div className="p-4 lg:hidden bg-black">
            <h2 className="mt-5 text-2xl leading-none text-white">
              {item?.subTitle?.toUpperCase() ?? ""}
            </h2>
            <h4 className="block sm:hidden my-5 text-white text-[16px]">
              <div>
                {item?.venueLocation ?? ""}

                {item?.venueDateAndTime &&
                  ` - ${new Date(item?.venueDateAndTime)?.getHours()} . ${
                    new Date(item?.venueDateAndTime)?.getMinutes() <= 9
                      ? "0" + new Date(item?.venueDateAndTime)?.getMinutes()
                      : new Date(item?.venueDateAndTime)?.getMinutes()
                  }
                 EST`}
              </div>
              <div>
                {item?.venueDateAndTime &&
                  new Date(item?.venueDateAndTime)?.toDateString()}
              </div>
            </h4>
            <h4 className="lg:text-base text-white">{item?.excerpt ?? ""}</h4>
          </div>
        </a>
      </Link>
    </div>
  );
};

export default LeagueMatchHero;
