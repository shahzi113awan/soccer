import React from "react";
import Skeleton from "react-loading-skeleton";

const Loaders = () => {
  return (
    <>
      <div className="flex">
        <div className="border-r border-[#b7b7b7] sm:h-[500px] w-[50%] h-[200px]">
          <Skeleton height="100%" width="100%" />
        </div>
        <div className="sm:h-[500px] w-[50%] h-[200px]">
          <Skeleton height="100%" width="100%" />
        </div>
      </div>
      <div className="grid grid-cols-12">
        {[1, 2, 3, 4]?.map((item) => (
          <div
            key={item}
            className="md:col-span-3  col-span-12 mx-3 mt-6 border-b py-3"
          >
            <Skeleton height={300} width="100%" />
          </div>
        ))}
        <div className="md:col-span-8  col-span-12 mx-3 mt-6 border-b py-3">
          <Skeleton height={300} width="100%" />
        </div>
        <div className="md:col-span-4  col-span-12 mx-3 mt-6 border-b py-3">
          <Skeleton height={300} width="100%" />
        </div>

        {[1, 2, 3, 4]?.map((item) => (
          <div
            key={item}
            className="md:col-span-3  col-span-12 mx-3 mt-6 border-b py-3"
          >
            <Skeleton height={300} width="100%" />
          </div>
        ))}
      </div>
    </>
  );
};

export default Loaders;
