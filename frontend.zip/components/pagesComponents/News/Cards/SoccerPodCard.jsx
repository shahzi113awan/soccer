import Link from "next/link";
import React, { useState } from "react";
import { GrPlayFill } from "react-icons/gr";
import { IconContext } from "react-icons/lib";
import SoccerPodPopup from "../../../commonComponents/Popups/SoccerPod/SoccerPodPopup";
import parse from "html-react-parser";

const MAX_LENGTH = 100;
const SoccerPodCard = ({
  id,
  slug,
  title,
  flexDirection = "col",
  smCol,
  mediaLink,
  content,
  thumbnail,
  midCard = false,
  fifthCard = false,
}) => {
  const [showSoccerpodPopup, setShowSoccerpodPopup] = useState(false);
  const [showMore, setShowMore] = useState(false);

  const toggleShowMore = () => {
    setShowMore((prevShowMore) => !prevShowMore);
  };

  const hasMore = content?.trim().length > MAX_LENGTH;
  const truncated = showMore ? content : content?.substring(0, MAX_LENGTH);

  const videoID = mediaLink.split("&")[0].replace("watch?v=", "embed/");

  return (
    // <Link href={slug}>
    <div
      className={`cursor-default flex flex-${flexDirection} ${
        smCol && "sm:flex-row flex-col"
      }`}>
      <div className="mb-3 pt-2 soccerpod-background">
        <div
          className={`overflow-hidden ${
            !midCard
              ? fifthCard
                ? "sm:min-h-[251px] sm:w-[376px] min-h-[241px]"
                : "min-h-[206px] max-h-[241px] sm:h-auto h-[241px] flex overflow-hidden sm:max-h-[206px]"
              : "h-[115px] max-w-[164px] md:max-w-[189px] md:h-[132px]"
          }`}>
          <img
            src={thumbnail}
            className={`object-cover min-h-[130px] ${
              !midCard && "min-h-[206px]"
            } ${!Boolean(thumbnail) && "no-image_img"}`}
            alt={title ?? ""}
            width="100%"
          />
        </div>
      </div>
      {/* <div className="mb-3 soccerpod-background">
        <div className="overflow-hidden mt-2 h-full ">
          <iframe
            width="100%"
            height=""
            src={videoID || "https://www.youtube.com/embed/0Z9VW4Y8X1I"}
            title="YouTube video player"
            frameBorder="0"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
            allowFullScreen
          />
        </div>
      </div> */}
      <div className={`flex-1 ${flexDirection === "row" && "pl-3"}`}>
        <h1 className="mr-4 mb-3 text-lg font-extrabold truncate uppercase leading-6 sm:leading-7 text-white">
          {title}
        </h1>

        {showMore ? (
          <h3 className="font-light text-sm overflow-hidden h-2 text-white">
            {parse(content)}
          </h3>
        ) : (
          <h3 className="font-light text-sm overflow-hidden h-20 text-white">
            {hasMore ? (
              <div>
                {parse(content?.substring(0, MAX_LENGTH) + "...")}{" "}
                <button
                  className="text-red-500 underline"
                  onClick={() => setShowSoccerpodPopup(true)}>
                  Read more
                </button>
              </div>
            ) : (
              parse(content?.substring(0, MAX_LENGTH))
            )}
          </h3>
        )}
      </div>
      <div>
        <div className=" flex ">
          <button
            className="flex mt-3 items-center gap-3 px-4 py-1 rounded-sm bg-red-700 "
            onClick={() => setShowSoccerpodPopup(true)}>
            <span className="text-white font-bold text-sm ">Listen Now</span>
            <span className="flex ml-1 text-sm">
              <IconContext.Provider value={{ className: "invert" }}>
                <GrPlayFill />
              </IconContext.Provider>
            </span>
          </button>
        </div>
        <SoccerPodPopup
          id={id}
          slug={slug}
          showCloseBtn={false}
          handleClosePopup={() => setShowSoccerpodPopup(false)}
          showPopup={showSoccerpodPopup}
          videoID={videoID}
          content={content}
          title={title}
        />
      </div>
    </div>
  );
};

export default SoccerPodCard;
