import React from "react";
import { MdOutlineChatBubble } from "react-icons/md";
import Link from "next/link";
const SmallCard = ({
  slug = "",
  img,
  title,
  author,
  commentsLength,
  excerpt,
  showExcerpt = true,
  flexDirection = "col",
  midCard = true,
  leagueTag,
}) => {
  return (
    <Link href={slug}>
      <a className={`flex  flex-${flexDirection}`}>
        <div
          className={`${
            !midCard
              ? "max-h-[87px] h-[87px] max-w-[87px]"
              : "min-h-[132px] max-w-[187px]"
          } flex flex-1 mb-3`}>
          <img
            src={img}
            className={`object-cover ${!Boolean(img) && "no-image_img"}`}
            alt={title ?? ""}
            width="100%"
          />
        </div>
        <div className={`flex-1 ${flexDirection === "row" && "pl-3"}`}>
          {leagueTag && (
            <p className="text-xs font-medium ">
              <span className="bg-zinc-300 p-1 uppercase">{leagueTag}</span>
            </p>
          )}
          <h4 className="mb-3 text-lg font-extrabold uppercase leading-[22px]">
            {title}
          </h4>
          {showExcerpt && <p className="h-[75px] overflow-hidden">{excerpt}</p>}

          <div className="flex text-xs mt-2">
            {/* <span>{author}</span> */}
            <span>Soccerbx Team</span>
            {/* <span className="ml-3 flex items-center">
              <MdOutlineChatBubble /> {commentsLength}
            </span> */}
          </div>
        </div>
      </a>
    </Link>
  );
};

export default SmallCard;
