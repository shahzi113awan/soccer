import React from "react";
import { MdOutlineChatBubble } from "react-icons/md";
import Link from "next/link";
import Image from "next/image";

const BigCard = ({
  slug,
  img,
  title,
  author,
  commentsLength,
  excerpt,
  showExcerpt = true,
  flexDirection = "col",
  midCard = false,
  smCol,
  fifthCard = false,
  leagueTag,
  leagueId,
}) => {
  return (
    <Link href={slug}>
      <div
        className={`cursor-pointer flex flex-${flexDirection} ${
          smCol && "sm:flex-row flex-col"
        }`}>
        <div className="mb-3">
          <div
            className={`overflow-hidden ${
              !midCard
                ? fifthCard
                  ? "sm:min-h-[251px] sm:w-[376px] min-h-[241px]"
                  : "min-h-[206px] max-h-[241px] sm:h-auto h-[241px] flex overflow-hidden sm:max-h-[206px]"
                : "h-[115px] max-w-[164px] md:max-w-[189px] md:h-[132px]"
            }`}>
            <div className="relative">
              <div>
                <div
                  className={`object-cover w-[278px] h-[241px] sm:w-[384px] sm:h-[241px] md:w-[175px] md:h-[206px] lg:w-[239px] lg:h-[206px] xl:w-[303px] xl:h-[206px] min-h-[130px] ${
                    !midCard && "min-h-[206px]"
                  } ${!Boolean(img) && "no-image_img"}`}>
                  <Image
                    src={img}
                    layout="fill"
                    objectFit="cover"
                    objectPosition="center"
                    alt={title ?? ""}
                  />
                </div>
              </div>
            </div>
            {/* <img
              src={img}
              className={`object-cover min-h-[130px] ${
                !midCard && "min-h-[206px]"
              } ${!Boolean(img) && "no-image_img"}`}
              alt={title ?? ""}
              width="100%"
            /> */}
          </div>
        </div>
        <div className={`flex-1 ${flexDirection === "row" && "pl-3"}`}>
          {leagueTag && (
            // <Link href={`/${leagueTag ?? ""}`}>
            <Link href={`/${leagueTag}`}>
              <h3 className="text-xs font-medium mr-1">
                <span className="bg-zinc-300 p-1 rounded-sm uppercase">
                  {leagueTag}
                </span>
              </h3>
            </Link>
          )}
          <h1 className="mr-4 mb-3 text-lg font-extrabold uppercase leading-6 sm:leading-7">
            {title}
          </h1>

          {showExcerpt && (
            <h3 className="font-light overflow-hidden">{excerpt}</h3>
          )}

          <div className="flex text-xs mt-2">
            {/* <span>{author}</span> */}
            <span>Soccerbx Team</span>

            <span className="ml-3 flex items-center">
              {/* <MdOutlineChatBubble />{" "}
              <span className="pl-[3px]"> {commentsLength}</span> */}
            </span>
          </div>
        </div>
      </div>
    </Link>
  );
};

export default BigCard;
