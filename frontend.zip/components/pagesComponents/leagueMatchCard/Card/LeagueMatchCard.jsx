import React from "react";
import Link from "next/link";
import { MdOutlineChatBubble } from "react-icons/md";

import TitleTable from "../../../commonComponents/TitleTable/TitleTable";

export default function LeagueMatchCard({ leagueSlug, item }) {
  return (
    <Link href={`${leagueSlug}/${item?.slug ?? item?._id}`}>
      <a className="block sm:max-w-[340px] max-w-[400px] mx-auto">
        <div className="flex">
          <div className="flex-1 flex-col justify-between h-[171px] w-[171px] sm:min-w-[100px] lg:h-[144px] lg:w-[144px] flex lg:max-w-[144px] lg:max-h-[144px]">
            <TitleTable
              fontSizes="text-[48px] sm:text-[45px] leading-[22px] lg:text-[41px]"
              gap={1}
              pl={0}
              pt={0}
              pr={0}
              pb={1}
              title={item?.title}
            />
          </div>
          <div className="flex-1 h-[171px] w-[171px] sm:min-w-[100px] lg:h-[144px] lg:w-[144px] flex lg:max-w-[144px] lg:max-h-[144px]">
            <img
              src={item?.featuredImage}
              alt={item?.title}
              className={`border-l object-cover py-1 ${
                !Boolean(item?.featuredImage) && "no-image_img"
              }`}
              width="100%"
            />
          </div>
        </div>
        <div className="py-2 pb-4 bg-white max-w-[290px]">
          <h2 className="text-[18px] leading-none text-black font-semibold tracking-[-1px] mb-3 mt-1">
            {item?.subTitle?.toUpperCase() ?? ""}
          </h2>
          <h3 className="lg:text-base font-light text-lack">
            {item?.excerpt ?? ""}
          </h3>
        </div>
        <div className="flex items-center">
          {/* <span className="text-[12px]">{item?.author?.name} </span> */}
          <span className="text-[12px]">Soccerbx Team</span>
          {/* <div className="ml-1 flex items-center">
            <MdOutlineChatBubble />
            {item?.commentsCount ?? 0}
          </div> */}
        </div>
      </a>
    </Link>
  );
}
