import Link from "next/link";
import React from "react";
import { MdOutlineChatBubble } from "react-icons/md";

const Post = ({ post }) => {
  return (
    <div key={post?.key} className="mb-4">
      <Link href={`/feature/${post?.slug ?? post?.id}`}>
        <a className="md:flex py-4">
          <div className="pb-3 flex-1" style={{ maxHeight: 400 }}>
            <img
              src={post?.featuredImage || "/images/no-image-500x500.png"}
              width="100%"
              alt={post?.title ?? ""}
              className="h-[19rem] object-cover"
            />
          </div>

          <div className="flex-1 md:pl-6">
            <h4 className="text-lg">{post?.title ?? ""}</h4>
            <div>{post?.excerpt}</div>
            <div className="flex justify-between mt-4">
              {/* <div className="text-xs">{post?.author?.name ?? ""}</div> */}
              <div className="text-xs">Soccerbx Team</div>

              <div className="flex items-center">
                {post?.comments?.length || 0}
                <MdOutlineChatBubble />
              </div>
            </div>
          </div>
        </a>
      </Link>
    </div>
  );
};

export default Post;
