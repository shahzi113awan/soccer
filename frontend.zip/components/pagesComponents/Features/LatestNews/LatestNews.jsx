import React from "react";
import Link from "next/link";
import { MdOutlineChatBubble } from "react-icons/md";

const LatestNews = ({ slug, image, author, heading, commentsCount }) => {
  return (
    <Link href={`/${slug ?? ""}`}>
      <a className="flex sn-home-border">
        <div className="flex w-full flex-row gap-2">
          <div>
            <img
              src={image}
              alt={heading ?? ""}
              className={`w-[86px] h-[86px] object-cover ${
                !Boolean(image) && "no-image_img"
              }`}
            />
          </div>
          <div className="flex-1">
            <h1 className="uppercase text-medium text-sm lg:text-lg mt-2 leading-none">
              {heading}
            </h1>
            <div className="flex items-center gap-1">
              {/* <p className="text-[12px]">{author}</p> */}
              <p className="text-[12px]">Soccerbx Team</p>

              {/* <MdOutlineChatBubble />
              <span className="text-[12px]">{commentsCount}</span> */}
            </div>
          </div>
        </div>
      </a>
    </Link>
  );
};

export default LatestNews;
